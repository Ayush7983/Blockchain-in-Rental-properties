# DecentRental dApp

A decentralized rental application built with React, Solidity, Hardhat and Cloudinary for property image storage.

## Features

- Smart contract-based rental management system
- User registration as landlords or tenants
- Property listing and browsing
- Rental request creation and management
- Rental approval/rejection by landlords
- Rent payment handling via blockchain transactions
- Cloudinary for property image uploads
- Responsive UI with Tailwind CSS

## Prerequisites

- Node.js (v16+)
- MetaMask browser extension
- Cloudinary account

## Setup Instructions

Set Up Environment Variables

Copy the sample environment variables file and fill in your credentials:

```bash
cp server/.env.sample server/.env
```

Edit `server/.env` with your MongoDB and Cloudinary credentials.

Start Local Blockchain

```bash
npx hardhat node
```

This will start a local Hardhat blockchain node at http://127.0.0.1:8545/

Deploy Smart Contract

In a new terminal:

```bash
npm run deploy
```

This will deploy the RentalContract to your local Hardhat blockchain and save the contract address to `src/contractAddress.json`.


Start the Frontend

In another terminal:

```bash
npm run dev
```

Access the application at http://localhost:5173



**Connect MetaMask**:
   - Configure MetaMask to connect to the local Hardhat network (RPC URL: http://127.0.0.1:8545/, Chain ID: 31337)
   - Import test accounts using the private keys from the Hardhat node output



In Simple Terms:
in terminal 1:
cd project
npm install
npx hardhat node

in terminal 2:
after npx hardhat node,
npx hardhat run scripts/deploy.js --network localhost

( it will give an address , make sure to add that address in src/contractAddress and update the .env file REACT_APP_CONTRACT_ADDRESS= )

in separate terminal 3 :
npm run dev
