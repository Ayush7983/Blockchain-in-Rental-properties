import { useState, useEffect } from 'react';
import { Navigate, Link, useLocation, Outlet } from 'react-router-dom';
import { useWeb3 } from '../hooks/useWeb3';
import { Home, Building2, Settings, List, CalendarClock, PlusCircle } from 'lucide-react';
import Button from '../components/common/Button';

// Dashboard components - now only need these two for the main dashboard view
import LandlordDashboard from '../components/dashboard/LandlordDashboard';
import TenantDashboard from '../components/dashboard/TenantDashboard';

const DashboardPage = () => {
  const { isConnected, isLandlord, isTenant } = useWeb3();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    document.title = 'Dashboard - DecentRental';
    // Close mobile menu when route changes
    setMobileMenuOpen(false);
  }, [location.pathname]);

  // If not connected, redirect to connect wallet page
  if (!isConnected) {
    return <Navigate to="/register" replace />;
  }

  // If not registered as either, redirect to register page
  if (!isLandlord && !isTenant) {
    return <Navigate to="/register\" replace />;
  }

  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 py-8">
          {/* Sidebar */}
          <div className="lg:col-span-3 xl:col-span-2">
            <div className="bg-white rounded-xl shadow-sm p-6 sticky top-24">
              <div className="mb-6">
                <h2 className="text-xl font-semibold text-gray-800">Dashboard</h2>
                <p className="text-gray-500 text-sm">
                  {isLandlord ? 'Landlord' : 'Tenant'} Account
                </p>
              </div>
              
              {/* Desktop Menu */}
              <div className="hidden lg:block">
                <nav className="space-y-1">
                  <Link 
                    to="/dashboard" 
                    className={`flex items-center px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50 ${
                      location.pathname === '/dashboard' ? 'bg-primary-50 text-primary-700' : ''
                    }`}
                  >
                    <Home className="h-5 w-5 mr-3" />
                    <span>Overview</span>
                  </Link>
                  
                  {isLandlord && (
                    <>
                      <Link 
                        to="/dashboard/properties" 
                        className={`flex items-center px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50 ${
                          location.pathname === '/dashboard/properties' ? 'bg-primary-50 text-primary-700' : ''
                        }`}
                      >
                        <Building2 className="h-5 w-5 mr-3" />
                        <span>My Properties</span>
                      </Link>
                      
                      <Link 
                        to="/dashboard/add-property" 
                        className={`flex items-center px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50 ${
                          location.pathname === '/dashboard/add-property' ? 'bg-primary-50 text-primary-700' : ''
                        }`}
                      >
                        <PlusCircle className="h-5 w-5 mr-3" />
                        <span>Add Property</span>
                      </Link>
                      
                      <Link 
                        to="/dashboard/requests" 
                        className={`flex items-center px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50 ${
                          location.pathname === '/dashboard/requests' ? 'bg-primary-50 text-primary-700' : ''
                        }`}
                      >
                        <List className="h-5 w-5 mr-3" />
                        <span>Rental Requests</span>
                      </Link>
                    </>
                  )}
                  
                  {isTenant && (
                    <Link 
                      to="/dashboard/rentals" 
                      className={`flex items-center px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50 ${
                        location.pathname === '/dashboard/rentals' ? 'bg-primary-50 text-primary-700' : ''
                      }`}
                    >
                      <CalendarClock className="h-5 w-5 mr-3" />
                      <span>My Rentals</span>
                    </Link>
                  )}
                  
                  <Link 
                    to="/dashboard/settings" 
                    className={`flex items-center px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50 ${
                      location.pathname === '/dashboard/settings' ? 'bg-primary-50 text-primary-700' : ''
                    }`}
                  >
                    <Settings className="h-5 w-5 mr-3" />
                    <span>Settings</span>
                  </Link>
                </nav>
              </div>
              
              {/* Mobile Menu Toggle */}
              <div className="lg:hidden">
                <Button 
                  variant="outline" 
                  fullWidth
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                >
                  {mobileMenuOpen ? 'Hide Menu' : 'Show Menu'}
                </Button>
                
                {mobileMenuOpen && (
                  <nav className="mt-4 space-y-1 animate-fade-in">
                    <Link 
                      to="/dashboard" 
                      className={`flex items-center px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50 ${
                        location.pathname === '/dashboard' ? 'bg-primary-50 text-primary-700' : ''
                      }`}
                    >
                      <Home className="h-5 w-5 mr-3" />
                      <span>Overview</span>
                    </Link>
                    
                    {isLandlord && (
                      <>
                        <Link 
                          to="/dashboard/properties" 
                          className={`flex items-center px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50 ${
                            location.pathname === '/dashboard/properties' ? 'bg-primary-50 text-primary-700' : ''
                          }`}
                        >
                          <Building2 className="h-5 w-5 mr-3" />
                          <span>My Properties</span>
                        </Link>
                        
                        <Link 
                          to="/dashboard/add-property" 
                          className={`flex items-center px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50 ${
                            location.pathname === '/dashboard/add-property' ? 'bg-primary-50 text-primary-700' : ''
                          }`}
                        >
                          <PlusCircle className="h-5 w-5 mr-3" />
                          <span>Add Property</span>
                        </Link>
                        
                        <Link 
                          to="/dashboard/requests" 
                          className={`flex items-center px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50 ${
                            location.pathname === '/dashboard/requests' ? 'bg-primary-50 text-primary-700' : ''
                          }`}
                        >
                          <List className="h-5 w-5 mr-3" />
                          <span>Rental Requests</span>
                        </Link>
                      </>
                    )}
                    
                    {isTenant && (
                      <Link 
                        to="/dashboard/rentals" 
                        className={`flex items-center px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50 ${
                          location.pathname === '/dashboard/rentals' ? 'bg-primary-50 text-primary-700' : ''
                        }`}
                      >
                        <CalendarClock className="h-5 w-5 mr-3" />
                        <span>My Rentals</span>
                      </Link>
                    )}
                    
                    <Link 
                      to="/dashboard/settings" 
                      className={`flex items-center px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50 ${
                        location.pathname === '/dashboard/settings' ? 'bg-primary-50 text-primary-700' : ''
                      }`}
                    >
                      <Settings className="h-5 w-5 mr-3" />
                      <span>Settings</span>
                    </Link>
                  </nav>
                )}
              </div>
            </div>
          </div>
          
          {/* Main Content */}
          <main className="lg:col-span-9 xl:col-span-10 w-full">
            {/* This will render either the dashboard index or child routes */}
            {location.pathname === '/dashboard/' || location.pathname === '/dashboard' ? (
              // Main dashboard content
              isLandlord ? <LandlordDashboard /> : <TenantDashboard />
            ) : (
              // Nested route content
              <Outlet />
            )}
          </main>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;