import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search, ChevronRight, Building2, Shield, Wallet, Users } from 'lucide-react';
import Button from '../components/common/Button';
import PropertyCard from '../components/property/PropertyCard';

// Sample properties for demo
const FEATURED_PROPERTIES = [
  {
    id: 1,
    title: 'Modern Apartment in Downtown',
    location: 'New York, NY',
    price: 0.5,
    image: 'https://images.pexels.com/photos/1918291/pexels-photo-1918291.jpeg',
    bedrooms: 2,
    bathrooms: 2,
    area: 85,
    isAvailable: true,
  },
  {
    id: 2,
    title: 'Luxury Penthouse with City View',
    location: 'Miami, FL',
    price: 1.2,
    image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',
    bedrooms: 3,
    bathrooms: 3,
    area: 150,
    isAvailable: true,
  },
  {
    id: 3,
    title: 'Cozy Studio Near University',
    location: 'Boston, MA',
    price: 0.3,
    image: 'https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg',
    bedrooms: 1,
    bathrooms: 1,
    area: 45,
    isAvailable: true,
  },
];

const HomePage = () => {
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    // Set page title
    document.title = 'DecentRental - Blockchain Property Rentals';
  }, []);

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary-900 to-primary-700 text-white pt-20 pb-32">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg')] bg-cover opacity-10"></div>
        </div>
        <div className="container-custom relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 animate-fade-in">
              Rent Properties with <span className="text-accent-300">Blockchain</span> Security
            </h1>
            <p className="text-lg md:text-xl text-gray-200 mb-10 animate-slide-up">
              A decentralized platform connecting landlords and tenants directly
              with transparent smart contracts and no intermediaries.
            </p>
            
            {/* Search Box */}
            <div className="bg-white rounded-lg p-2 shadow-lg flex items-center animate-slide-up">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search for a city or location..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-lg focus:outline-none text-gray-700"
                />
              </div>
              <Link to="/properties">
                <Button variant="primary" size="lg" className="ml-2">
                  Find Properties
                </Button>
              </Link>
            </div>
            
            {/* Stats */}
            <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="flex flex-col items-center">
                <div className="text-3xl font-bold mb-2">500+</div>
                <div className="text-gray-300">Properties Available</div>
              </div>
              <div className="flex flex-col items-center">
                <div className="text-3xl font-bold mb-2">1000+</div>
                <div className="text-gray-300">Happy Users</div>
              </div>
              <div className="flex flex-col items-center">
                <div className="text-3xl font-bold mb-2">0%</div>
                <div className="text-gray-300">Commission Fees</div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Wave SVG */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 160">
            <path 
              fill="#f9fafb" 
              fillOpacity="1" 
              d="M0,128L60,117.3C120,107,240,85,360,90.7C480,96,600,128,720,138.7C840,149,960,139,1080,122.7C1200,107,1320,85,1380,74.7L1440,64L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z">
            </path>
          </svg>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-bold text-gray-800">Featured Properties</h2>
            <Link to="/properties" className="flex items-center text-primary-600 hover:text-primary-700 font-medium">
              View all properties
              <ChevronRight className="ml-1 h-5 w-5" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {FEATURED_PROPERTIES.map(property => (
              <PropertyCard key={property.id} {...property} />
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">How It Works</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our blockchain-based platform simplifies the rental process while providing 
              security and transparency for both landlords and tenants.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="flex flex-col items-center text-center p-6 rounded-xl bg-gray-50 hover:shadow-lg transition-all duration-300">
              <div className="bg-primary-100 p-4 rounded-full mb-6">
                <Wallet className="h-8 w-8 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Connect Your Wallet</h3>
              <p className="text-gray-600">
                Link your Ethereum wallet to our platform to securely authenticate and manage your rental transactions.
              </p>
            </div>
            
            {/* Step 2 */}
            <div className="flex flex-col items-center text-center p-6 rounded-xl bg-gray-50 hover:shadow-lg transition-all duration-300">
              <div className="bg-primary-100 p-4 rounded-full mb-6">
                <Building2 className="h-8 w-8 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Browse or List Properties</h3>
              <p className="text-gray-600">
                Search for available properties or list your own with detailed information and verified ownership.
              </p>
            </div>
            
            {/* Step 3 */}
            <div className="flex flex-col items-center text-center p-6 rounded-xl bg-gray-50 hover:shadow-lg transition-all duration-300">
              <div className="bg-primary-100 p-4 rounded-full mb-6">
                <Shield className="h-8 w-8 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Secure Smart Contracts</h3>
              <p className="text-gray-600">
                All rental agreements are handled through secure, transparent smart contracts with no intermediaries.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary-800 text-white">
        <div className="container-custom">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="md:w-3/5 mb-8 md:mb-0">
              <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
              <p className="text-gray-300 max-w-xl">
                Join our growing community of landlords and tenants who are embracing the future of property rentals with blockchain technology.
              </p>
            </div>
            <div>
              <Link to="/register">
                <Button 
                  variant="accent" 
                  size="lg"
                  icon={<Users className="h-5 w-5" />}
                >
                  Register Now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;