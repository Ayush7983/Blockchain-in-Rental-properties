import { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { useWeb3 } from '../hooks/useWeb3';
import { Building2, User, AlertCircle } from 'lucide-react';
import Button from '../components/common/Button';

const RegisterPage = () => {
  const { isConnected, isLandlord, isTenant, account, connectWallet, registerAsLandlord, registerAsTenant } = useWeb3();
  const [isRegistering, setIsRegistering] = useState(false);
  const [registerType, setRegisterType] = useState<'landlord' | 'tenant' | null>(null);

  useEffect(() => {
    document.title = 'Register - DecentRental';
  }, []);

  // If user is already registered, redirect to dashboard
  if (isLandlord || isTenant) {
    return <Navigate to="/dashboard\" replace />;
  }

  const handleRegister = async () => {
    if (!registerType) return;
    
    setIsRegistering(true);
    
    try {
      if (registerType === 'landlord') {
        await registerAsLandlord();
      } else {
        await registerAsTenant();
      }
      
      // Registration successful, the Web3Context will update the user state
    } catch (error) {
      console.error('Registration error:', error);
      alert('Failed to register. Please try again.');
    } finally {
      setIsRegistering(false);
    }
  };

  return (
    <div className="pt-24 pb-16 min-h-screen">
      <div className="container-custom max-w-2xl">
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-primary-600 to-primary-800 py-8 px-6 text-white text-center">
            <h1 className="text-3xl font-bold mb-2">Join DecentRental</h1>
            <p className="text-primary-100">
              Register as a landlord or tenant to start using the platform
            </p>
          </div>
          
          <div className="p-8">
            {!isConnected ? (
              <div className="text-center py-6">
                <AlertCircle className="h-16 w-16 text-primary-500 mx-auto mb-4" />
                <h2 className="text-2xl font-semibold mb-3">Connect Your Wallet</h2>
                <p className="text-gray-600 mb-6">
                  Please connect your Ethereum wallet to register on DecentRental.
                </p>
                <Button 
                  variant="primary" 
                  size="lg"
                  onClick={connectWallet}
                >
                  Connect Wallet
                </Button>
              </div>
            ) : (
              <div>
                <div className="mb-6">
                  <h2 className="text-xl font-semibold mb-2">Connected Wallet</h2>
                  <div className="bg-gray-50 p-4 rounded-lg flex items-center">
                    <div className="bg-primary-100 p-2 rounded-full mr-3">
                      <User className="h-5 w-5 text-primary-600" />
                    </div>
                    <div>
                      <div className="font-medium">{account}</div>
                      <div className="text-sm text-gray-500">Ready to register</div>
                    </div>
                  </div>
                </div>
                
                <h2 className="text-xl font-semibold mb-4">Choose Registration Type</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                  {/* Landlord Option */}
                  <div
                    className={`border-2 rounded-xl p-6 cursor-pointer transition-all ${
                      registerType === 'landlord' 
                        ? 'border-primary-500 bg-primary-50' 
                        : 'border-gray-200 hover:border-primary-300'
                    }`}
                    onClick={() => setRegisterType('landlord')}
                  >
                    <div className="flex items-center mb-3">
                      <div className={`w-5 h-5 rounded-full border-2 mr-3 flex items-center justify-center ${
                        registerType === 'landlord' ? 'border-primary-500' : 'border-gray-300'
                      }`}>
                        {registerType === 'landlord' && (
                          <div className="w-3 h-3 rounded-full bg-primary-500"></div>
                        )}
                      </div>
                      <h3 className="text-lg font-semibold">Landlord</h3>
                    </div>
                    
                    <p className="text-gray-600 mb-4">
                      Register as a landlord to list properties for rent on the platform.
                    </p>
                    
                    <div className="flex items-center text-primary-600">
                      <Building2 className="h-5 w-5 mr-2" />
                      <span className="font-medium">List and manage properties</span>
                    </div>
                  </div>
                  
                  {/* Tenant Option */}
                  <div
                    className={`border-2 rounded-xl p-6 cursor-pointer transition-all ${
                      registerType === 'tenant' 
                        ? 'border-primary-500 bg-primary-50' 
                        : 'border-gray-200 hover:border-primary-300'
                    }`}
                    onClick={() => setRegisterType('tenant')}
                  >
                    <div className="flex items-center mb-3">
                      <div className={`w-5 h-5 rounded-full border-2 mr-3 flex items-center justify-center ${
                        registerType === 'tenant' ? 'border-primary-500' : 'border-gray-300'
                      }`}>
                        {registerType === 'tenant' && (
                          <div className="w-3 h-3 rounded-full bg-primary-500"></div>
                        )}
                      </div>
                      <h3 className="text-lg font-semibold">Tenant</h3>
                    </div>
                    
                    <p className="text-gray-600 mb-4">
                      Register as a tenant to browse and request rentals on the platform.
                    </p>
                    
                    <div className="flex items-center text-primary-600">
                      <User className="h-5 w-5 mr-2" />
                      <span className="font-medium">Browse and rent properties</span>
                    </div>
                  </div>
                </div>
                
                <div className="text-center">
                  <Button 
                    variant="primary" 
                    size="lg"
                    disabled={!registerType}
                    isLoading={isRegistering}
                    onClick={handleRegister}
                  >
                    Register as {registerType ? (registerType === 'landlord' ? 'Landlord' : 'Tenant') : '...'}
                  </Button>
                  
                  <p className="mt-4 text-sm text-gray-500">
                    By registering, you agree to the terms and conditions of DecentRental.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;