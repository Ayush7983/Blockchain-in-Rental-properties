import { useState, useEffect } from 'react';
import { Search, Filter, MapPin } from 'lucide-react';
import PropertyCard from '../components/property/PropertyCard';
import Button from '../components/common/Button';

// Sample properties for demo
const SAMPLE_PROPERTIES = [
  {
    id: 1,
    title: 'Modern Apartment in Downtown',
    location: 'New York, NY',
    price: 0.5,
    image: 'https://images.pexels.com/photos/1918291/pexels-photo-1918291.jpeg',
    bedrooms: 2,
    bathrooms: 2,
    area: 85,
    isAvailable: true,
  },
  {
    id: 2,
    title: 'Luxury Penthouse with City View',
    location: 'Miami, FL',
    price: 1.2,
    image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',
    bedrooms: 3,
    bathrooms: 3,
    area: 150,
    isAvailable: true,
  },
  {
    id: 3,
    title: 'Cozy Studio Near University',
    location: 'Boston, MA',
    price: 0.3,
    image: 'https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg',
    bedrooms: 1,
    bathrooms: 1,
    area: 45,
    isAvailable: true,
  },
  {
    id: 4,
    title: 'Rustic Cottage with Garden',
    location: 'Portland, OR',
    price: 0.4,
    image: 'https://images.pexels.com/photos/2079234/pexels-photo-2079234.jpeg',
    bedrooms: 2,
    bathrooms: 1,
    area: 70,
    isAvailable: true,
  },
  {
    id: 5,
    title: 'Modern Loft in Art District',
    location: 'Los Angeles, CA',
    price: 0.7,
    image: 'https://images.pexels.com/photos/1974596/pexels-photo-1974596.jpeg',
    bedrooms: 1,
    bathrooms: 1,
    area: 60,
    isAvailable: false,
  },
  {
    id: 6,
    title: 'Beachfront Apartment',
    location: 'San Diego, CA',
    price: 0.8,
    image: 'https://images.pexels.com/photos/2119713/pexels-photo-2119713.jpeg',
    bedrooms: 2,
    bathrooms: 2,
    area: 90,
    isAvailable: true,
  },
];

const PropertiesPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(2);
  const [bedrooms, setBedrooms] = useState<number | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [properties, setProperties] = useState(SAMPLE_PROPERTIES);
  const [filteredProperties, setFilteredProperties] = useState(SAMPLE_PROPERTIES);

  useEffect(() => {
    // In a real app, we would fetch properties from the blockchain here
    document.title = 'Browse Properties - DecentRental';
    setProperties(SAMPLE_PROPERTIES);
  }, []);

  useEffect(() => {
    // Filter properties based on search and filters
    let results = properties;
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      results = results.filter(
        property => 
          property.title.toLowerCase().includes(query) || 
          property.location.toLowerCase().includes(query)
      );
    }
    
    results = results.filter(
      property => 
        property.price >= minPrice && 
        property.price <= maxPrice
    );
    
    if (bedrooms !== null) {
      results = results.filter(property => property.bedrooms === bedrooms);
    }
    
    setFilteredProperties(results);
  }, [searchQuery, minPrice, maxPrice, bedrooms, properties]);

  return (
    <div className="pt-24 pb-16">
      <div className="container-custom">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Browse Properties</h1>
            <p className="text-gray-600">
              Find your next home on the blockchain
            </p>
          </div>
          
          <div className="mt-4 md:mt-0">
            <Button 
              variant="outline"
              icon={<Filter className="h-4 w-4" />}
              onClick={() => setShowFilters(!showFilters)}
            >
              {showFilters ? 'Hide Filters' : 'Show Filters'}
            </Button>
          </div>
        </div>
        
        {/* Search and Filters */}
        <div className="mb-8">
          <div className="bg-white rounded-lg shadow-md p-4 mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search by location or property name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
            </div>
          </div>
          
          {/* Filters */}
          {showFilters && (
            <div className="bg-white rounded-lg shadow-md p-6 mb-6 animate-slide-down">
              <h3 className="text-lg font-semibold mb-4">Filters</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Price Range */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Price Range (ETH)
                  </label>
                  <div className="flex items-center space-x-4">
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">Min</label>
                      <input
                        type="number"
                        min="0"
                        step="0.1"
                        value={minPrice}
                        onChange={(e) => setMinPrice(parseFloat(e.target.value))}
                        className="w-full p-2 border border-gray-300 rounded"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">Max</label>
                      <input
                        type="number"
                        min="0"
                        step="0.1"
                        value={maxPrice}
                        onChange={(e) => setMaxPrice(parseFloat(e.target.value))}
                        className="w-full p-2 border border-gray-300 rounded"
                      />
                    </div>
                  </div>
                </div>
                
                {/* Bedrooms */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Bedrooms
                  </label>
                  <select
                    value={bedrooms === null ? '' : bedrooms}
                    onChange={(e) => setBedrooms(e.target.value ? parseInt(e.target.value) : null)}
                    className="w-full p-2 border border-gray-300 rounded"
                  >
                    <option value="">Any</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3+</option>
                  </select>
                </div>
                
                {/* Property Status */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Property Status
                  </label>
                  <select
                    className="w-full p-2 border border-gray-300 rounded"
                  >
                    <option value="all">All Properties</option>
                    <option value="available">Available Only</option>
                  </select>
                </div>
              </div>
            </div>
          )}
          
          {/* Results Info */}
          <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
            <div>
              Found {filteredProperties.length} properties
            </div>
            <div>
              <select className="p-1 border border-gray-300 rounded">
                <option>Sort by: Latest</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
              </select>
            </div>
          </div>
        </div>
        
        {/* Property Grid */}
        {filteredProperties.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProperties.map(property => (
              <PropertyCard key={property.id} {...property} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No properties found</h3>
            <p className="text-gray-500 mb-6">
              Try adjusting your search or filters to find what you're looking for.
            </p>
            <Button 
              variant="primary"
              onClick={() => {
                setSearchQuery('');
                setMinPrice(0);
                setMaxPrice(2);
                setBedrooms(null);
              }}
            >
              Reset Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PropertiesPage;