import { Link } from 'react-router-dom';
import { Home } from 'lucide-react';
import Button from '../components/common/Button';

const NotFoundPage = () => {
  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-16">
      <div className="max-w-md text-center">
        <div className="mb-8">
          <h1 className="text-9xl font-bold text-primary-600">404</h1>
          <div className="mt-4 text-3xl font-bold text-gray-900">Page Not Found</div>
          <p className="mt-4 text-lg text-gray-600">
            Sorry, the page you're looking for doesn't exist or has been moved.
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/">
            <Button 
              variant="primary" 
              size="lg"
              icon={<Home className="h-5 w-5" />}
            >
              Go Home
            </Button>
          </Link>
          <Link to="/properties">
            <Button variant="outline" size="lg">
              Browse Properties
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;