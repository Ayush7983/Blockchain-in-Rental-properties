import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MapPin, Calendar, Home, DollarSign, Clock, ChevronLeft, ChevronRight, User } from 'lucide-react';
import Button from '../components/common/Button';
import { useWeb3 } from '../hooks/useWeb3';

// Sample property data for demo
const SAMPLE_PROPERTIES = [
  {
    id: 1,
    title: 'Modern Apartment in Downtown',
    description: 'A beautifully renovated apartment in the heart of downtown. Features include hardwood floors, stainless steel appliances, and a spacious living area. The building has 24/7 security, a fitness center, and a rooftop lounge with panoramic city views.',
    location: 'New York, NY',
    price: 0.5,
    images: [
      'https://images.pexels.com/photos/1918291/pexels-photo-1918291.jpeg',
      'https://images.pexels.com/photos/275484/pexels-photo-275484.jpeg',
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',
    ],
    bedrooms: 2,
    bathrooms: 2,
    area: 85,
    isAvailable: true,
    amenities: ['Air Conditioning', 'Elevator', 'Gym', 'Rooftop', 'Dishwasher', 'In-unit Laundry'],
    owner: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e',
    ownerName: 'Alex Johnson',
    listedDate: '2023-08-15',
  },
];

const PropertyDetailsPage = () => {
  const { id } = useParams<{ id: string }>();
  const { isConnected, isTenant, account } = useWeb3();
  const [property, setProperty] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [rentalDuration, setRentalDuration] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    // In a real app, we would fetch property details from the blockchain here
    setLoading(true);
    
    setTimeout(() => {
      const foundProperty = SAMPLE_PROPERTIES.find(p => p.id === Number(id));
      setProperty(foundProperty || null);
      setLoading(false);
      
      if (foundProperty) {
        document.title = `${foundProperty.title} - DecentRental`;
      } else {
        document.title = 'Property Not Found - DecentRental';
      }
    }, 500);
  }, [id]);

  const nextImage = () => {
    if (!property) return;
    setCurrentImageIndex((prev) => 
      prev === property.images.length - 1 ? 0 : prev + 1
    );
  };

  const prevImage = () => {
    if (!property) return;
    setCurrentImageIndex((prev) => 
      prev === 0 ? property.images.length - 1 : prev - 1
    );
  };

  const handleRentalRequest = async () => {
    if (!isConnected || !isTenant) return;
    
    setIsSubmitting(true);
    
    // Simulate blockchain transaction delay
    setTimeout(() => {
      setIsSubmitting(false);
      alert('Rental request submitted successfully!');
    }, 2000);
  };

  if (loading) {
    return (
      <div className="pt-24 pb-16 flex justify-center items-center min-h-[60vh]">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-gray-200 border-t-primary-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading property details...</p>
        </div>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="pt-24 pb-16">
        <div className="container-custom">
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <Home className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-800 mb-4">Property Not Found</h1>
            <p className="text-gray-600 mb-6">
              The property you're looking for doesn't exist or has been removed.
            </p>
            <Link to="/properties">
              <Button variant="primary">Browse All Properties</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-16">
      <div className="container-custom">
        {/* Breadcrumbs */}
        <div className="flex items-center text-sm text-gray-500 mb-4">
          <Link to="/" className="hover:text-primary-600">Home</Link>
          <span className="mx-2">/</span>
          <Link to="/properties" className="hover:text-primary-600">Properties</Link>
          <span className="mx-2">/</span>
          <span className="text-gray-700">{property.title}</span>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Image Gallery */}
            <div className="relative mb-8 rounded-xl overflow-hidden shadow-md h-[400px]">
              <img 
                src={property.images[currentImageIndex]} 
                alt={property.title} 
                className="w-full h-full object-cover"
              />
              
              {/* Navigation Arrows */}
              <button 
                onClick={prevImage}
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white rounded-full p-2 shadow-md transition-all"
              >
                <ChevronLeft className="h-6 w-6 text-gray-800" />
              </button>
              
              <button 
                onClick={nextImage}
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white rounded-full p-2 shadow-md transition-all"
              >
                <ChevronRight className="h-6 w-6 text-gray-800" />
              </button>
              
              {/* Image Counter */}
              <div className="absolute bottom-4 right-4 bg-black/60 text-white px-3 py-1 rounded-full text-sm">
                {currentImageIndex + 1} / {property.images.length}
              </div>
            </div>
            
            {/* Property Details */}
            <div className="bg-white rounded-xl shadow-md p-6 mb-8">
              <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">{property.title}</h1>
              
              <div className="flex items-center text-gray-600 mb-4">
                <MapPin className="h-5 w-5 mr-2 text-primary-500" />
                <span>{property.location}</span>
              </div>
              
              <div className="flex flex-wrap gap-4 mb-6">
                <div className="bg-gray-100 rounded-lg px-4 py-2 flex items-center">
                  <Home className="h-5 w-5 mr-2 text-primary-500" />
                  <span>{property.bedrooms} {property.bedrooms === 1 ? 'Bedroom' : 'Bedrooms'}</span>
                </div>
                
                <div className="bg-gray-100 rounded-lg px-4 py-2 flex items-center">
                  <Home className="h-5 w-5 mr-2 text-primary-500" />
                  <span>{property.bathrooms} {property.bathrooms === 1 ? 'Bathroom' : 'Bathrooms'}</span>
                </div>
                
                <div className="bg-gray-100 rounded-lg px-4 py-2 flex items-center">
                  <Home className="h-5 w-5 mr-2 text-primary-500" />
                  <span>{property.area} m²</span>
                </div>
              </div>
              
              <div className="border-t border-gray-200 pt-6 mb-6">
                <h2 className="text-xl font-semibold mb-4">Description</h2>
                <p className="text-gray-600 leading-relaxed">{property.description}</p>
              </div>
              
              <div className="border-t border-gray-200 pt-6 mb-6">
                <h2 className="text-xl font-semibold mb-4">Amenities</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {property.amenities.map((amenity: string, index: number) => (
                    <div key={index} className="flex items-center">
                      <div className="h-2 w-2 rounded-full bg-primary-500 mr-2"></div>
                      <span className="text-gray-600">{amenity}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="border-t border-gray-200 pt-6">
                <h2 className="text-xl font-semibold mb-4">Owner Information</h2>
                <div className="flex items-center mb-3">
                  <User className="h-10 w-10 bg-gray-100 text-gray-600 rounded-full p-2 mr-3" />
                  <div>
                    <div className="font-medium">{property.ownerName}</div>
                    <div className="text-sm text-gray-500">{property.owner.substring(0, 8)}...{property.owner.substring(property.owner.length - 6)}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Pricing Card */}
            <div className="bg-white rounded-xl shadow-md p-6 mb-6 sticky top-24">
              <div className="flex items-center justify-between mb-6">
                <div className="text-2xl font-bold text-primary-600">{property.price} ETH <span className="text-gray-500 text-base font-normal">/ month</span></div>
                <div className={`${property.isAvailable ? 'bg-success-100 text-success-800' : 'bg-gray-100 text-gray-500'} px-3 py-1 rounded-full text-sm font-medium`}>
                  {property.isAvailable ? 'Available' : 'Unavailable'}
                </div>
              </div>
              
              <div className="space-y-4 mb-6">
                <div className="flex justify-between items-center text-gray-700">
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 mr-2 text-gray-500" />
                    <span>Listed</span>
                  </div>
                  <div>{property.listedDate}</div>
                </div>
                
                <div className="flex justify-between items-center text-gray-700">
                  <div className="flex items-center">
                    <DollarSign className="h-5 w-5 mr-2 text-gray-500" />
                    <span>Security Deposit</span>
                  </div>
                  <div>{property.price} ETH</div>
                </div>
                
                <div className="flex justify-between items-center text-gray-700">
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 mr-2 text-gray-500" />
                    <span>Min. Rental Period</span>
                  </div>
                  <div>1 Month</div>
                </div>
              </div>
              
              {property.isAvailable && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Rental Duration (months)
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="12"
                      value={rentalDuration}
                      onChange={(e) => setRentalDuration(parseInt(e.target.value))}
                      className="w-full p-2 border border-gray-300 rounded"
                    />
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-600">Monthly Rent</span>
                      <span className="font-medium">{property.price} ETH</span>
                    </div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-600">Duration</span>
                      <span className="font-medium">{rentalDuration} months</span>
                    </div>
                    <div className="flex justify-between items-center pt-2 border-t border-gray-200 mt-2">
                      <span className="font-medium">Total Cost</span>
                      <span className="font-bold text-primary-600">{(property.price * rentalDuration).toFixed(2)} ETH</span>
                    </div>
                  </div>
                  
                  {isConnected ? (
                    isTenant ? (
                      <Button 
                        variant="primary" 
                        fullWidth 
                        size="lg"
                        isLoading={isSubmitting}
                        onClick={handleRentalRequest}
                      >
                        Submit Rental Request
                      </Button>
                    ) : (
                      <div className="text-center">
                        <Button variant="outline" fullWidth disabled>
                          Register as Tenant First
                        </Button>
                        <div className="mt-2 text-sm text-gray-600">
                          <Link to="/register" className="text-primary-600 hover:underline">
                            Click here to register
                          </Link>
                        </div>
                      </div>
                    )
                  ) : (
                    <div className="text-center">
                      <Button variant="outline" fullWidth disabled>
                        Connect Wallet to Request
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyDetailsPage;