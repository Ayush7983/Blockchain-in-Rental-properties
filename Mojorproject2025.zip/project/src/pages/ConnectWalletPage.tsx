import { useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Web3Context } from '../contexts';

const ConnectWalletPage = () => {
  const [name, setName] = useState<string>('');
  const [role, setRole] = useState<string>('');
  const [isRegistering, setIsRegistering] = useState<boolean>(false);
  const [showRegistration, setShowRegistration] = useState<boolean>(false);

  const { account, isConnected, connectWallet, registerAsLandlord, registerAsTenant, isLandlord, isTenant } = useContext(Web3Context);
  
  const navigate = useNavigate();

  const handleConnect = async () => {
    try {
      await connectWallet();
    } catch (error) {
      console.error('Error connecting wallet:', error);
    }
  };
  
  // Check user registration status immediately when component loads or when wallet status changes
  useEffect(() => {
    console.log('🔍 Current user status:', { isConnected, isLandlord, isTenant });
    
    // If wallet is connected, immediately check registration status
    if (isConnected) {
      if (isLandlord || isTenant) {
        // User is already registered, navigate to dashboard immediately
        console.log('✅ User already registered, redirecting to dashboard');
        navigate('/dashboard');
      } else {
        // Only show registration form if user is definitely not registered
        console.log('⚠️ User not registered, showing registration form');
        setShowRegistration(true);
      }
    } else {
      // Reset registration form if wallet disconnected
      setShowRegistration(false);
    }
  }, [isConnected, isLandlord, isTenant, navigate]);

  const handleRegister = async () => {
    if (!name || !role) {
      alert('Please enter your name and select a role');
      return;
    }

    setIsRegistering(true);
    
    try {
      if (role === 'landlord') {
        await registerAsLandlord(name);
      } else {
        await registerAsTenant(name);
      }
      navigate('/dashboard');
    } catch (error) {
      console.error('Error registering:', error);
    } finally {
      setIsRegistering(false);
    }
  };

  return (
    <div className="pt-24 pb-16 min-h-screen bg-gray-50">
      <div className="container-custom max-w-lg mx-auto">
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="bg-gradient-to-r from-primary-600 to-primary-800 py-8 px-6 text-white text-center">
            <h1 className="text-3xl font-bold mb-1">Connect Your Wallet</h1>
            <p className="text-primary-100">
              Connect with MetaMask to access the DecentRental platform
            </p>
          </div>
          
          <div className="p-8">
            {!isConnected ? (
              <div className="text-center py-6">
                <div className="mx-auto w-20 h-20 mb-6 rounded-full bg-primary-50 flex items-center justify-center">
                  <img 
                    src="/images/metamask-fox.svg" 
                    alt="MetaMask" 
                    className="w-12 h-12" 
                  />
                </div>
                <h2 className="text-xl font-semibold mb-3">MetaMask Connection Required</h2>
                <p className="text-gray-600 mb-6">
                  Please connect your MetaMask wallet to continue using DecentRental
                </p>
                <button 
                  onClick={handleConnect}
                  disabled={isRegistering}
                  className="w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-md transition-colors"
                >
                  Connect MetaMask
                </button>
                <div className="mt-4 text-xs text-gray-500">
                  <p className="mt-1">Make sure you have MetaMask installed.</p>
                  <p className="mt-1">Connect to the Hardhat local network (http://127.0.0.1:8545/).</p>
                </div>
              </div>
            ) : isLandlord || isTenant ? (
              // Immediately redirect registered users and show loading
              <div className="text-center py-10">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500 mx-auto mb-4"></div>
                <p className="text-gray-600">Already registered! Redirecting to dashboard...</p>
              </div>
            ) : showRegistration ? (
              <div className="py-4">
                <h2 className="text-xl font-bold mb-4">Complete Registration</h2>
                <p className="text-gray-600 mb-6">
                  Please enter your name and choose your role on the platform
                </p>
                <div className="mb-6">
                  <label className="block mb-2 text-sm font-medium text-gray-700">Your Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter your name"
                  />
                </div>
                
                <div className="mb-6">
                  <label className="block mb-2 text-sm font-medium text-gray-700">I want to register as a:</label>
                  <div className="flex space-x-4">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="role"
                        value="tenant"
                        checked={role === 'tenant'}
                        onChange={() => setRole('tenant')}
                        className="mr-2"
                      />
                      Tenant
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="role"
                        value="landlord"
                        checked={role === 'landlord'}
                        onChange={() => setRole('landlord')}
                        className="mr-2"
                      />
                      Landlord
                    </label>
                  </div>
                </div>
                
                <button
                  onClick={handleRegister}
                  disabled={!name || !role || isRegistering}
                  className="w-full py-2 px-4 bg-green-600 hover:bg-green-700 text-white font-medium rounded-md transition-colors disabled:bg-green-300"
                >
                  {isRegistering ? 'Registering...' : 'Register'}
                </button>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConnectWalletPage;
