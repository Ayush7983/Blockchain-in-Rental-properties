import { ethers } from 'ethers';

// ABI (Application Binary Interface) for the rental contract
const contractABI = [
  // State variables
  "function isLandlord(address) external view returns (bool)",
  "function isTenant(address) external view returns (bool)",
  
  // Registration functions
  "function registerAsLandlord() external",
  "function registerAsTenant() external",
  
  // Property management
  "function addProperty(string memory _name, string memory _description, string memory _location, uint256 _pricePerMonth, string memory _imageURL) external",
  "function getMyProperties() external view returns (uint256[] memory)",
  "function properties(uint256) external view returns (string memory, string memory, string memory, uint256, string memory, address, bool)",
  
  // Rental requests
  "function createRentalRequest(uint256 _propertyId, uint256 _durationMonths) external",
  "function approveRentalRequest(uint256 _propertyId, uint256 _requestId) external",
  "function rejectRentalRequest(uint256 _propertyId, uint256 _requestId) external",
  "function getMyRentalRequests() external view returns (uint256[] memory)",
  "function getPropertyRequests(uint256 _propertyId) external view returns (uint256[] memory)",
  
  // View functions
  "function getAllProperties() external view returns (uint256[] memory)",
  "function getProperty(uint256 _propertyId) external view returns (string memory, string memory, string memory, uint256, address, bool)",
  "function getRentalRequest(uint256 _requestId) external view returns (uint256, address, uint256, uint256, bool)",
  
  // Events
  "event LandlordRegistered(address indexed landlord)",
  "event TenantRegistered(address indexed tenant)",
  "event PropertyAdded(uint256 indexed propertyId, address indexed landlord)",
  "event RentalRequestCreated(uint256 indexed requestId, uint256 indexed propertyId, address indexed tenant)",
  "event RentalRequestApproved(uint256 indexed requestId, uint256 indexed propertyId)",
  "event RentalRequestRejected(uint256 indexed requestId, uint256 indexed propertyId)"
];

// Factory function to create a contract instance
const RentalContract = (address: string, signer: ethers.JsonRpcSigner) => {
  return new ethers.Contract(address, contractABI, signer);
};

export default RentalContract;