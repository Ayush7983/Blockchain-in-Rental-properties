import { Routes, Route, Navigate } from 'react-router-dom';
import { useContext } from 'react';
import { Web3Context } from './contexts/Web3Context';

// Components
import NavBar from './components/NavBar';
import LoadingScreen from './components/common/LoadingScreen';

// Pages and Components
import HomePage from './pages/HomePage';
import DashboardPage from './pages/DashboardPage';
import ConnectWalletPage from './pages/ConnectWalletPage';
import PropertyListing from './components/dashboard/PropertyListing';
import TenantRentalRequests from './components/dashboard/TenantRentalRequests';
import AddProperty from './components/dashboard/AddProperty';
import UserSettings from './components/dashboard/UserSettings';
import MyRentals from './components/dashboard/MyRentals';
import MyProperties from './components/dashboard/MyProperties';
import RentalRequests from './components/dashboard/RentalRequests';

function App() {
  const { isInitializing, isConnected } = useContext(Web3Context);

  if (isInitializing) {
    return <LoadingScreen />;
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <NavBar />
      <main className="flex-grow container mx-auto px-4 py-8">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/connect" element={<ConnectWalletPage />} />
          <Route path="/properties" element={isConnected ? <PropertyListing /> : <Navigate to="/connect" />} />
          <Route path="/my-requests" element={isConnected ? <TenantRentalRequests /> : <Navigate to="/connect" />} />
          
          {/* Dashboard with nested routes using trailing slash on parent */}
          <Route path="/dashboard/" element={isConnected ? <DashboardPage /> : <Navigate to="/connect" />}>
            {/* Landlord routes */}
            <Route path="add-property" element={isConnected ? <AddProperty /> : <Navigate to="/connect" />} />
            <Route path="properties" element={isConnected ? <MyProperties /> : <Navigate to="/connect" />} />
            <Route path="requests" element={isConnected ? <RentalRequests /> : <Navigate to="/connect" />} />
            
            {/* Tenant routes */}
            <Route path="my-rentals" element={isConnected ? <MyRentals /> : <Navigate to="/connect" />} />
            
            {/* Common routes */}
            <Route path="settings" element={isConnected ? <UserSettings /> : <Navigate to="/connect" />} />
          </Route>
          
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;