import { ethers } from 'ethers';
import RentalContract from '../contracts/RentalContract';
import contractAddressData from '../contractAddress.json';

// Types
export interface Property {
  id: number;
  name: string;
  description: string;
  location: string;
  pricePerMonth: number;
  imageURL: string;
  landlord: string;
  isActive: boolean;
  bedrooms?: number;
  bathrooms?: number;
  area?: number;
}

export interface RentalRequest {
  id: number;
  propertyId: number;
  tenant: string;
  durationMonths: number;
  timestamp: number;
  isApproved: boolean;
}

class Web3Service {
  private provider: ethers.BrowserProvider | null = null;
  private signer: ethers.JsonRpcSigner | null = null;
  private contract: any = null;

  // Initialize Web3 connection
  async initialize() {
    try {
      if (window.ethereum) {
        this.provider = new ethers.BrowserProvider(window.ethereum);
        this.signer = await this.provider.getSigner();
        const contractAddress = contractAddressData.address;
        this.contract = RentalContract(contractAddress, this.signer);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Failed to initialize Web3Service:', error);
      return false;
    }
  }

  // Check if initialized
  private checkInitialized() {
    if (!this.contract) {
      throw new Error('Web3Service not initialized. Call initialize() first.');
    }
  }

  // User Registration
  async registerAsLandlord() {
    this.checkInitialized();
    const tx = await this.contract.registerAsLandlord();
    await tx.wait();
    return true;
  }

  async registerAsTenant() {
    this.checkInitialized();
    const tx = await this.contract.registerAsTenant();
    await tx.wait();
    return true;
  }

  async isUserLandlord(address: string) {
    this.checkInitialized();
    return await this.contract.isLandlord(address);
  }

  async isUserTenant(address: string) {
    this.checkInitialized();
    return await this.contract.isTenant(address);
  }
  
  async getUserDetails(address: string) {
    this.checkInitialized();
    try {
      // Check if user exists first
      const isLandlord = await this.contract.isLandlord(address);
      const isTenant = await this.contract.isTenant(address);
      
      if (!isLandlord && !isTenant) {
        return { exists: false };
      }
      
      // Try to get user name if the contract supports it
      // This is a best effort - if the contract doesn't support it, we'll use a default
      try {
        if (isLandlord && typeof this.contract.getLandlordName === 'function') {
          const name = await this.contract.getLandlordName(address);
          return { exists: true, name, isLandlord, isTenant };
        } else if (isTenant && typeof this.contract.getTenantName === 'function') {
          const name = await this.contract.getTenantName(address);
          return { exists: true, name, isLandlord, isTenant };
        }
      } catch (nameError) {
        console.log('Contract does not support name retrieval:', nameError);
      }
      
      return { 
        exists: true, 
        isLandlord, 
        isTenant,
        // Default name to shortened address
        name: `${address.substring(0, 6)}...${address.substring(address.length - 4)}`
      };
    } catch (error) {
      console.error('Error getting user details:', error);
      return { exists: false, error };
    }
  }

  // Property Management
  async addProperty(name: string, description: string, location: string, pricePerMonth: number, imageURL: string, bedrooms: number = 1, bathrooms: number = 1, area: number = 500) {
    this.checkInitialized();
    const tx = await this.contract.addProperty(
      name, 
      description, 
      location, 
      pricePerMonth, 
      imageURL,
      bedrooms,
      bathrooms,
      area
    );
    const receipt = await tx.wait();
    
    // Extract propertyId from event logs
    const propertyAddedEvent = receipt.logs
      .filter((log: any) => log.fragment && log.fragment.name === 'PropertyAdded')
      .map((log: any) => ({
        propertyId: Number(log.args[0]),
        landlord: log.args[1]
      }))[0];
    
    return propertyAddedEvent?.propertyId;
  }

  async getAllProperties(): Promise<Property[]> {
    this.checkInitialized();
    const propertyIds = await this.contract.getAllProperties();
    
    const properties: Property[] = [];
    for (const id of propertyIds) {
      const property = await this.getProperty(Number(id));
      properties.push(property);
    }
    
    return properties;
  }

  async getMyProperties(): Promise<Property[]> {
    this.checkInitialized();
    const propertyIds = await this.contract.getMyProperties();
    
    const properties: Property[] = [];
    for (const id of propertyIds) {
      const property = await this.getProperty(Number(id));
      properties.push(property);
    }
    
    return properties;
  }

  // Helper method to check if property exists
  async propertyExists(propertyId: number): Promise<boolean> {
    this.checkInitialized();
    try {
      // Try to get the property directly - if it throws an error, the property doesn't exist
      // Don't use propertyToLandlord since it might not exist in the contract
      const [,,,,,landlord,] = await this.contract.getProperty(propertyId);
      return landlord !== '0x0000000000000000000000000000000000000000';
    } catch (error) {
      console.log(`Property ${propertyId} likely doesn't exist:`, error);
      return false;
    }
  }

  // Format price to ETH with 4 decimal places
  formatPrice(price: number): string {
    if (!price && price !== 0) return '0.0000';
    // Convert from wei to ETH if very large number
    if (price > 1000000000) {
      return ethers.formatEther(price.toString()).slice(0, 6);
    }
    // Otherwise assume it's already in ETH
    return price.toFixed(4);
  }

  // Fix URLs that are from Cloudinary or missing http prefix
  fixCloudinaryURL(url: string): string {
    if (!url) return '/placeholder.png';
    
    // If it looks like an Ethereum address, use placeholder
    if (url.startsWith('0x') && url.length >= 40) {
      console.log('Found Ethereum address instead of image URL:', url);
      return '/placeholder.png';
    }
    
    // If it's a weird contract value (sometimes happens with older contracts)
    if (typeof url === 'object' || url.includes('undefined')) {
      console.log('Found object or invalid string as URL:', url);
      return '/placeholder.png';
    }
    
    // If it's a number or too short to be valid, use placeholder
    if (!isNaN(Number(url)) || url.length < 10) {
      console.log('Found invalid image URL:', url);
      return '/placeholder.png';
    }
    
    // If it's already a full URL, return it
    if (url.startsWith('http://') || url.startsWith('https://')) {
      return url;
    }
    
    // If it's a Cloudinary ID without protocol, add it
    if (url.includes('cloudinary') || url.includes('res.cloudinary.com')) {
      return url.startsWith('//') ? `https:${url}` : `https://${url}`;
    }
    
    return url || '/placeholder-property.jpg';
  }

  async getProperty(propertyId: number): Promise<Property> {
    this.checkInitialized();
    console.log(`Fetching property #${propertyId} details`);
    
    try {
      // First check if the property exists - skip this check if needed
      let exists = true;
      try {
        exists = await this.propertyExists(propertyId);
      } catch (error) {
        console.log('Property existence check failed, proceeding anyway:', error);
      }
      
      if (!exists) {
        console.warn(`Property #${propertyId} might not exist, but proceeding anyway`);
      }

      // Try multiple methods to get property details to ensure compatibility with all contract versions
      let property: Property | null = null;
      
      // Method 1: Try getPropertyMethod if available
      try {
        if (typeof this.contract.getPropertyMethod === 'function') {
          console.log('Using getPropertyMethod');
          const result = await this.contract.getPropertyMethod(propertyId);
          const [name, description, location, pricePerMonth, imageURL, landlord, isActive, bedrooms, bathrooms, area] = result;
          
          property = {
            id: propertyId,
            name,
            description,
            location,
            pricePerMonth: Number(pricePerMonth),
            imageURL: this.fixCloudinaryURL(imageURL),
            landlord,
            isActive,
            bedrooms: Number(bedrooms || 1),
            bathrooms: Number(bathrooms || 1),
            area: Number(area || 500)
          };
          console.log('Property fetched successfully using getPropertyMethod:', property);
          return property;
        }
      } catch (methodError) {
        console.log('getPropertyMethod failed:', methodError);
      }
      
      // Method 2: Try getPropertyDetails if available
      try {
        if (typeof this.contract.getPropertyDetails === 'function') {
          console.log('Using getPropertyDetails');
          const result = await this.contract.getPropertyDetails(propertyId);
          
          const [name, description, location, pricePerMonth, imageURL, landlord, isActive, bedrooms, bathrooms, area] = result;
          
          property = {
            id: propertyId,
            name,
            description,
            location,
            pricePerMonth: Number(pricePerMonth),
            imageURL: this.fixCloudinaryURL(imageURL),
            landlord,
            isActive,
            bedrooms: Number(bedrooms || 1),
            bathrooms: Number(bathrooms || 1),
            area: Number(area || 500)
          };
          console.log('Property fetched successfully using getPropertyDetails:', property);
          return property;
        }
      } catch (detailsError) {
        console.warn('getPropertyDetails failed:', detailsError);
      }
      
      // Method 3: Fallback to basic getProperty method
      console.log('Using basic getProperty method');
      try {
        const [name, description, location, pricePerMonth, imageURL, landlord, isActive] = 
          await this.contract.getProperty(propertyId);
        
        console.log('Raw imageURL from contract:', imageURL);
        
        // Validate imageURL - if it's an Ethereum address or invalid, use a default
        let validImageURL = imageURL;
        if (!validImageURL || 
            (typeof validImageURL === 'string' && validImageURL.startsWith('0x')) ||
            !validImageURL.includes('http')) {
          console.log('Invalid image URL detected, using default placeholder');
          validImageURL = '/placeholder.png';
        }
        
        // Add default property metadata
        property = {
          id: propertyId,
          name,
          description,
          location,
          pricePerMonth: Number(pricePerMonth),
          imageURL: this.fixCloudinaryURL(validImageURL),
          landlord,
          isActive,
          bedrooms: 2, // Default values
          bathrooms: 1,
          area: 800,
        };
      } catch (methodError) {
        console.error('Error in basic getProperty method:', methodError);
        throw methodError;
      }
      
      return property;
    } catch (error) {
      console.error('Failed to get property:', error);
      // Return a default property instead of throwing an error to avoid UI crashes
      return {
        id: propertyId,
        name: 'Property data unavailable',
        description: 'Could not retrieve property details',
        location: 'Unknown',
        pricePerMonth: 0,
        imageURL: '/placeholder.png',
        landlord: '0x0000000000000000000000000000000000000000',
        isActive: false,
        bedrooms: 0,
        bathrooms: 0,
        area: 0
      };
    }
  }

  // Property Update and Management
  async updateProperty(propertyId: number, name: string, description: string, location: string, pricePerMonth: number, imageURL: string, bedrooms: number = 1, bathrooms: number = 1, area: number = 500): Promise<boolean> {
    this.checkInitialized();
    try {
      // Try to use the extended update method if available
      try {
        const tx = await this.contract.updatePropertyDetails(
          propertyId,
          name,
          description,
          location,
          pricePerMonth,
          imageURL,
          bedrooms,
          bathrooms,
          area
        );
        await tx.wait();
        return true;
      } catch (detailsError) {
        console.warn('Extended property update not available, using basic method', detailsError);
      }
      
      // Fall back to basic update if extended not available
      const tx = await this.contract.updateProperty(
        propertyId,
        name,
        description,
        location,
        pricePerMonth,
        imageURL
      );
      await tx.wait();
      return true;
    } catch (error) {
      console.error('Failed to update property:', error);
      throw new Error(`Failed to update property #${propertyId}: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async togglePropertyStatus(propertyId: number): Promise<boolean> {
    this.checkInitialized();
    try {
      const tx = await this.contract.togglePropertyStatus(propertyId);
      await tx.wait();
      return true;
    } catch (error) {
      console.error('Failed to toggle property status:', error);
      throw new Error(`Failed to toggle property status for #${propertyId}: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async deleteProperty(propertyId: number): Promise<boolean> {
    this.checkInitialized();
    try {
      const tx = await this.contract.deleteProperty(propertyId);
      await tx.wait();
      return true;
    } catch (error) {
      console.error('Failed to delete property:', error);
      throw new Error(`Failed to delete property #${propertyId}: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Rental Request Management
  async createRentalRequest(propertyId: number, durationMonths: number) {
    this.checkInitialized();
    const tx = await this.contract.createRentalRequest(propertyId, durationMonths);
    const receipt = await tx.wait();
    
    // Extract requestId from event logs
    const requestCreatedEvent = receipt.logs
      .filter((log: any) => log.fragment && log.fragment.name === 'RentalRequestCreated')
      .map((log: any) => ({
        requestId: Number(log.args[0]),
        propertyId: Number(log.args[1]),
        tenant: log.args[2]
      }))[0];
    
    return requestCreatedEvent?.requestId;
  }

  async getMyRentalRequests(): Promise<RentalRequest[]> {
    this.checkInitialized();
    const requestIds = await this.contract.getMyRentalRequests();
    
    const requests: RentalRequest[] = [];
    for (const id of requestIds) {
      const request = await this.getRentalRequest(Number(id));
      requests.push(request);
    }
    
    return requests;
  }

  async getPropertyRequests(propertyId: number): Promise<RentalRequest[]> {
    this.checkInitialized();
    const requestIds = await this.contract.getPropertyRequests(propertyId);
    
    const requests: RentalRequest[] = [];
    for (const id of requestIds) {
      const request = await this.getRentalRequest(Number(id));
      requests.push(request);
    }
    
    return requests;
  }

  async getRentalRequest(requestId: number): Promise<RentalRequest> {
    this.checkInitialized();
    const [propertyId, tenant, durationMonths, timestamp, isApproved] = 
      await this.contract.getRentalRequest(requestId);
      
    return {
      id: requestId,
      propertyId: Number(propertyId),
      tenant,
      durationMonths: Number(durationMonths),
      timestamp: Number(timestamp),
      isApproved
    };
  }

  async approveRentalRequest(propertyId: number, requestId: number) {
    this.checkInitialized();
    const tx = await this.contract.approveRentalRequest(propertyId, requestId);
    await tx.wait();
    return true;
  }

  async rejectRentalRequest(propertyId: number, requestId: number) {
    this.checkInitialized();
    const tx = await this.contract.rejectRentalRequest(propertyId, requestId);
    await tx.wait();
    return true;
  }
  
  // Make a payment for rent - this is a custom method since the contract doesn't have
  // a specific payRent function. We'll implement it using a direct ETH transfer
  async makePayment(requestId: number, amount: ethers.BigNumberish) {
    this.checkInitialized();
    try {
      // Get the request to determine the landlord address from the property
      const request = await this.getRentalRequest(requestId);
      const property = await this.getProperty(request.propertyId);
      
      // Ensure landlord address is valid
      if (!property.landlord || property.landlord === '0x0000000000000000000000000000000000000000') {
        throw new Error('Invalid landlord address for this property');
      }
      
      // Create a transaction to send ETH to the landlord address
      if (!this.signer) throw new Error('Signer not initialized');
      
      // Try the contract method first if it exists
      try {
        console.log('Attempting to make payment using contract method for request ID:', requestId);
        const tx = await this.contract.makeRentalPayment(requestId, { value: amount });
        await tx.wait();
        return {
          success: true,
          transactionHash: tx.hash,
          method: 'contract'
        };
      } catch (contractError) {
        console.log('Contract method not available, falling back to direct transfer');
        
        // Fallback to direct transfer
        const tx = await this.signer.sendTransaction({
          to: property.landlord,
          value: amount
        });
        
        await tx.wait();
        return {
          success: true,
          transactionHash: tx.hash,
          method: 'direct'
        };
      }
    } catch (error) {
      console.error('Payment failed:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown payment error'
      };
    }
  }

  // This is a comment to explain the status toggle functionality.
  // The implementation is kept at line 271 and this duplicate is removed.
}

// Create singleton instance
export const web3Service = new Web3Service();

export default web3Service;
