import { uploadImage } from './api';
import web3Service from './web3Service';

// This is our frontend property model
export interface Property {
  id: number;
  name: string;
  description: string;
  location: string;
  price: number; // Maps to pricePerMonth in blockchain
  pricePerMonth?: number; // Used in some components that expected pricePerMonth
  title?: string; // Alias for name, used in some components
  landlord: string;
  isActive: boolean;
  imageURL?: string; // From blockchain
  // UI-specific fields
  bedrooms?: number;
  bathrooms?: number;
  area?: number;
  images: Array<{
    url: string;
    public_id?: string;
  }>;
  amenities?: string[];
}

export interface PropertyResponse {
  success: boolean;
  property: Property | null;
  error?: string;
}

export interface PropertiesResponse {
  success: boolean;
  properties: Property[];
}

const getAllProperties = async (filters?: { landlord?: string; isActive?: boolean }): Promise<PropertiesResponse> => {
  try {
    // Initialize web3Service
    await web3Service.initialize();
    
    // Get all properties from blockchain
    const blockchainProperties = await web3Service.getAllProperties();
    
    // Filter properties if needed
    let filteredProperties = blockchainProperties;
    
    if (filters) {
      filteredProperties = blockchainProperties.filter(property => {
        // Handle landlord filtering with proper type checking
        if (filters.landlord) {
          // Ensure both values are strings before calling toLowerCase
          const propertyLandlord = property.landlord ? String(property.landlord).toLowerCase() : "";
          const filterLandlord = String(filters.landlord).toLowerCase();
          
          if (propertyLandlord !== filterLandlord) {
            return false;
          }
        }
        if (filters.isActive !== undefined && property.isActive !== filters.isActive) {
          return false;
        }
        return true;
      });
    }
    
    // Map blockchain properties to our frontend property format
    const properties: Property[] = filteredProperties.map(prop => ({
      id: prop.id,
      name: prop.name,
      description: prop.description,
      location: prop.location,
      price: prop.pricePerMonth,
      landlord: prop.landlord,
      isActive: prop.isActive,
      imageURL: prop.imageURL,
      // Default values for fields not in blockchain
      bedrooms: 0,
      bathrooms: 0,
      area: 0,
      images: [
        // Use the blockchain-stored imageURL as the primary image
        { url: prop.imageURL || 'https://via.placeholder.com/300x200?text=No+Image' }
      ]
    }));
    
    return {
      success: true,
      properties
    };
  } catch (error) {
    console.error('Error fetching properties from blockchain:', error);
    return {
      success: false,
      properties: []
    };
  }
};

const getPropertyById = async (propertyId: string): Promise<PropertyResponse> => {
  try {
    // Initialize web3Service
    await web3Service.initialize();
    
    // Get property from blockchain by ID
    const blockchainProperty = await web3Service.getProperty(Number(propertyId));
    
    if (!blockchainProperty) {
      return {
        success: false,
        property: null as any
      };
    }
    
    // Map blockchain property to our frontend format
    const property: Property = {
      id: blockchainProperty.id,
      name: blockchainProperty.name,
      description: blockchainProperty.description,
      location: blockchainProperty.location,
      price: blockchainProperty.pricePerMonth,
      landlord: blockchainProperty.landlord,
      isActive: blockchainProperty.isActive,
      imageURL: blockchainProperty.imageURL,
      // Default values for fields not in blockchain
      bedrooms: 0,
      bathrooms: 0,
      area: 0,
      images: [
        // Use the blockchain-stored imageURL as the primary image
        { url: blockchainProperty.imageURL || 'https://via.placeholder.com/300x200?text=No+Image' }
      ]
    };
    
    return {
      success: true,
      property
    };
  } catch (error) {
    console.error(`Error fetching property ${propertyId} from blockchain:`, error);
    return {
      success: false,
      property: null as any
    };
  }
};

const createProperty = async (propertyData: Partial<Property> & { imageUrl?: string }) => {
  try {
    console.log('📤 Creating property with data:', propertyData);
    
    // Initialize web3Service
    await web3Service.initialize();
    
    // Add property to blockchain
    const propertyId = await web3Service.addProperty(
      propertyData.name || '',
      propertyData.description || '',
      propertyData.location || '',
      propertyData.price || 0,
      propertyData.imageUrl || ''
    );
    
    if (propertyId === undefined) {
      throw new Error('Failed to get property ID from blockchain');
    }
    
    console.log('✅ Property created successfully on blockchain with ID:', propertyId);
    
    // Return the new property data
    return {
      success: true,
      property: {
        id: propertyId,
        name: propertyData.name || '',
        description: propertyData.description || '',
        location: propertyData.location || '',
        price: propertyData.price || 0,
        landlord: '', // This will be set by the blockchain to msg.sender
        isActive: true,
        imageURL: propertyData.imageUrl || '',
        bedrooms: propertyData.bedrooms || 0,
        bathrooms: propertyData.bathrooms || 0,
        area: propertyData.area || 0,
        images: [{ url: propertyData.imageUrl || '' }]
      }
    };
  } catch (error) {
    console.error('❌ Error creating property on blockchain:', error);
    return {
      success: false,
      property: null as any,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

// Note: In a blockchain-only solution, property updates would need a new smart contract function
// This is just a placeholder that will always return an error since our contract doesn't support updates
const updateProperty = async (_propertyId: string, _updates: Partial<Property>): Promise<PropertyResponse> => {
  console.warn('Property updates are not supported in the blockchain-only model without contract modifications');
  return {
    success: false,
    property: null,
    error: 'Property updates not supported in blockchain-only model'
  };
};

// We'll still keep Cloudinary for image uploads, but we'll simplify the response
const uploadPropertyImage = async (imageFile: File) => {
  try {
    // We'll use a direct upload endpoint that only handles the image
    const response = await uploadImage(`/upload`, imageFile);
    return response;
  } catch (error) {
    console.error('Error uploading image:', error);
    throw error;
  }
};

// Note: In a blockchain-only solution, property deactivation would need a smart contract function
// This is just a placeholder that will always return an error since our contract doesn't support this
const deactivateProperty = async (_propertyId: string) => {
  console.warn('Property deactivation is not supported in the blockchain-only model without contract modifications');
  return {
    success: false,
    message: 'Property deactivation not supported in blockchain-only model'
  };
};

export const propertyService = {
  getAllProperties,
  getPropertyById,
  createProperty,
  updateProperty,
  uploadPropertyImage,
  deactivateProperty
};
