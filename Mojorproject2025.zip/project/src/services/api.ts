// Cloudinary configuration from environment variables
const CLOUDINARY_UPLOAD_PRESET = 'ml_default'; // Default preset for unsigned uploads
const CLOUDINARY_CLOUD_NAME = import.meta.env.VITE_CLOUDINARY_CLOUD_NAME || 'dee1avfem';
const CLOUDINARY_API_KEY = import.meta.env.VITE_CLOUDINARY_API_KEY || '775948437929738';
const CLOUDINARY_UPLOAD_URL = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`;

// We're removing all backend API calls since we're using blockchain only
// Only keeping the Cloudinary direct upload functionality

// Direct Cloudinary upload handler - no backend API needed
export const uploadImage = async (file: File) => {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);
  formData.append('api_key', CLOUDINARY_API_KEY);
  
  try {
    console.log('Uploading image directly to Cloudinary');
    const response = await fetch(CLOUDINARY_UPLOAD_URL, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      console.error(`Cloudinary upload error (${response.status})`);
      const errorText = await response.text();
      throw new Error(errorText || `Image upload failed with status ${response.status}`);
    }

    const result = await response.json();
    console.log('Image upload successful:', result);
    return {
      url: result.secure_url,
      public_id: result.public_id
    };
  } catch (error) {
    console.error('Image upload failed:', error);
    throw error;
  }
};
