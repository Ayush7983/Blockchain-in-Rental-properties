import web3Service from './web3Service';

export interface User {
  address: string;
  name: string;
  role: 'tenant' | 'landlord';
  // In a blockchain-only solution, we don't store personal info like email/phone
}

export interface UserResponse {
  success: boolean;
  user?: User;
  message?: string; // For success/error messages
  error?: string;   // For backward compatibility
}

export interface UsersResponse {
  success: boolean;
  users: User[];
  message?: string;
  error?: string;
}

const registerUser = async (userData: User): Promise<UserResponse> => {
  try {
    await web3Service.initialize();
    
    // Register user based on role
    if (userData.role === 'landlord') {
      await web3Service.registerAsLandlord();
    } else if (userData.role === 'tenant') {
      await web3Service.registerAsTenant();
    } else {
      throw new Error('Invalid user role');
    }
    
    // Return success response
    return {
      success: true,
      user: userData
    };
  } catch (error) {
    console.error('Error registering user on blockchain:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

const getUserByAddress = async (address: string): Promise<UserResponse> => {
  try {
    await web3Service.initialize();
    
    // Check if the address is registered as either tenant or landlord
    const isLandlord = await web3Service.isUserLandlord(address);
    const isTenant = await web3Service.isUserTenant(address);
    
    if (!isLandlord && !isTenant) {
      return {
        success: false,
        message: 'User not found on blockchain'
      };
    }
    
    // Create a user object with blockchain data
    // Note: In blockchain-only solution we don't have name stored on chain
    // We would only know the role and address
    const user: User = {
      address: address,
      name: `${address.substring(0, 6)}...${address.substring(address.length - 4)}`,
      role: isLandlord ? 'landlord' : 'tenant'
    };
    
    return {
      success: true,
      user
    };
  } catch (error) {
    console.error('Error getting user from blockchain:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

// Note: Getting all users isn't a common blockchain pattern as it wouldn't scale
// This is a placeholder implementation
const getAllUsers = async (_role?: 'tenant' | 'landlord'): Promise<UsersResponse> => {
  try {
    console.warn('Getting all users from blockchain is not efficient and may not be implemented in the contract');
    
    // This would require contract functions to get all addresses of landlords/tenants
    // which is typically not available in blockchain contracts due to gas costs
    
    return {
      success: false,
      users: [],
      message: 'Getting all users is not supported in the blockchain-only model'
    };
  } catch (error) {
    return {
      success: false,
      users: [],
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

// Note: Updating user info would require additional smart contract functions
const updateUser = async (_address: string, _updates: Partial<User>): Promise<UserResponse> => {
  console.warn('Updating user details is not supported in the blockchain-only model without contract modifications');
  return {
    success: false,
    message: 'Updating user details is not supported in the blockchain-only model'
  };
};

export const userService = {
  registerUser,
  getUserByAddress,
  getAllUsers,
  updateUser
};
