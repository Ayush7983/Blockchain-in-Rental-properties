import web3Service from './web3Service';
import { Property } from './propertyService';

// Import ethers for wallet interaction
import { ethers } from 'ethers';

// Frontend model of rental request, adapted from blockchain data
export interface RentalRequest {
  id: number; // From blockchain requestId
  requestId?: number; // Alias for id, used in some components
  propertyId: number;
  tenant: string;
  landlord?: string; // Optional as we may need to fetch it separately
  durationMonths: number;
  timestamp: number; // Unix timestamp
  isApproved: boolean;
  isRejected?: boolean; // This is a frontend-specific addition not in the blockchain
  
  // Frontend-specific fields 
  status: 'pending' | 'approved' | 'rejected';
  requestDate?: Date;
  monthlyRent?: number; // We'll get this from the associated property
  property?: Property;
  
  // Payment history for this rental request
  paymentHistory?: Array<{
    amount: string;
    timestamp: number;
    transactionHash: string;
  }>;
}

export interface RentalRequestResponse {
  success: boolean;
  rentalRequest: RentalRequest | null;
  error?: string;
}

export interface RentalRequestsResponse {
  success: boolean;
  rentalRequests: RentalRequest[];
  error?: string;
}

const getAllRentalRequests = async (filters?: { 
  tenant?: string; 
  landlord?: string; 
  propertyId?: number;
  status?: 'pending' | 'approved' | 'rejected';
}): Promise<RentalRequestsResponse> => {
  try {
    // Initialize web3Service
    await web3Service.initialize();
    
    // Determine which blockchain method to call based on filters
    // Import the interface from web3Service
    let blockchainRequests: import('./web3Service').RentalRequest[] = [];
    
    // For tenant, we'll use getMyRentalRequests if the current account is the tenant
    if (filters?.tenant && await web3Service.isUserTenant(filters.tenant)) {
      // If requesting tenant's own requests, use built-in method
      // We need to check if the current connected account is the tenant
      await web3Service.initialize(); // Make sure web3 is initialized
      try {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const signer = await provider.getSigner();
        const currentAccount = await signer.getAddress();
        if (currentAccount && filters.tenant && currentAccount.toLowerCase() === filters.tenant?.toLowerCase()) {
          blockchainRequests = await web3Service.getMyRentalRequests();
        } else {
          // Otherwise fetch all properties and filter manually
          // Note: This is inefficient and only for demo purposes
          blockchainRequests = [];
          const properties = await web3Service.getAllProperties();
          for (const property of properties) {
            const requests = await web3Service.getPropertyRequests(property.id);
            if (filters.tenant) {
              blockchainRequests.push(...requests.filter(req => 
                filters.tenant && req.tenant.toLowerCase() === filters.tenant.toLowerCase()));
            }
          }
        }
      } catch (error) {
        console.error('Error getting current account:', error);
        blockchainRequests = [];
      }
    } else if (filters?.propertyId !== undefined) {
      // Get requests by property
      blockchainRequests = await web3Service.getPropertyRequests(filters.propertyId);
    } else if (filters?.landlord) {
      console.log('Fetching rental requests for landlord:', filters.landlord);
      // For landlord, let's get ALL properties and then filter by landlord
      // This ensures we don't miss any property owned by this landlord
      blockchainRequests = [];
      try {
        // Get all properties on the blockchain
        const allProperties = await web3Service.getAllProperties();
        console.log('All properties count:', allProperties.length);
        
        // Filter to get only properties owned by this landlord
        const landlordProperties = allProperties.filter(property => {
          // Ensure landlord is a string before calling toLowerCase
          const propertyLandlord = typeof property.landlord === 'string' ? property.landlord.toLowerCase() : String(property.landlord).toLowerCase();
          const filterLandlord = typeof filters.landlord === 'string' ? filters.landlord.toLowerCase() : String(filters.landlord).toLowerCase();
          const isMatch = propertyLandlord === filterLandlord;
          if (isMatch) {
            console.log('Found landlord property:', property.id, property.name);
          }
          return isMatch;
        });
        
        console.log('Landlord properties count:', landlordProperties.length);
        
        // Get all requests for each property owned by the landlord
        for (const property of landlordProperties) {
          console.log('Fetching requests for property:', property.id);
          const propertyRequests = await web3Service.getPropertyRequests(property.id);
          console.log('Property', property.id, 'has', propertyRequests.length, 'requests');
          blockchainRequests.push(...propertyRequests);
        }
        
        console.log('Total landlord rental requests:', blockchainRequests.length);
      } catch (error) {
        console.error('Error fetching landlord rental requests:', error);
      }
    } else {
      // Get all requests (this might be very inefficient in a real blockchain app)
      // Since there's no getAllRentalRequests in the contract,
      // we need to get all properties and then get all requests for each property
      blockchainRequests = [];
      const properties = await web3Service.getAllProperties();
      for (const property of properties) {
        const requests = await web3Service.getPropertyRequests(property.id);
        blockchainRequests.push(...requests);
      }
    }
    
    // Further filter results based on other criteria
    let filteredRequests = [...blockchainRequests];
    
    // Filter by landlord if specified
    if (filters?.landlord) {
      // For landlord filtering, we need to get property details for each request
      const propertiesMap = new Map();
      
      // First get properties for all requests
      for (const request of filteredRequests) {
        if (!propertiesMap.has(request.propertyId)) {
          const property = await web3Service.getProperty(request.propertyId);
          if (property) {
            propertiesMap.set(request.propertyId, property);
          }
        }
      }
      
      // Then filter by landlord
      filteredRequests = filteredRequests.filter(request => {
        const property = propertiesMap.get(request.propertyId);
        if (!property || !property.landlord || !filters.landlord) return false;
        
        // Ensure both are strings and compare them properly
        const propertyLandlord = String(property.landlord).toLowerCase();
        const filterLandlord = String(filters.landlord).toLowerCase();
        return propertyLandlord === filterLandlord;
      });
    }
    
    // Filter by status if specified
    if (filters?.status) {
      filteredRequests = filteredRequests.filter(request => {
        if (filters.status === 'approved') return request.isApproved;
        if (filters.status === 'rejected') return false; // No reject in blockchain yet
        if (filters.status === 'pending') return !request.isApproved;
        return true;
      });
    }
    
    // Convert blockchain format to our frontend format
    const rentalRequests = await Promise.all(filteredRequests.map(async (request) => {
      // Get property details to include with the request
      const property = await web3Service.getProperty(request.propertyId);
      
      return {
        id: request.id,
        propertyId: request.propertyId,
        tenant: request.tenant,
        landlord: property?.landlord,
        durationMonths: request.durationMonths,
        timestamp: request.timestamp,
        isApproved: request.isApproved,
        isRejected: false, // Not in blockchain model, adding for frontend
        
        // Derive status from isApproved flag (blockchain only has approved state)
        status: request.isApproved ? 'approved' : 'pending' as 'pending' | 'approved' | 'rejected',
        requestDate: new Date(request.timestamp * 1000),
        monthlyRent: property?.pricePerMonth,
        property: property ? {
          id: property.id,
          name: property.name,
          description: property.description,
          location: property.location,
          price: property.pricePerMonth,
          landlord: property.landlord,
          isActive: property.isActive,
          imageURL: property.imageURL,
          images: [{ url: property.imageURL || '' }],
          bedrooms: 0, // Default values
          bathrooms: 0,
          area: 0
        } : undefined
      };
    }));
    
    return {
      success: true,
      rentalRequests
    };
  } catch (error) {
    console.error('Error fetching rental requests from blockchain:', error);
    return {
      success: false,
      rentalRequests: [],
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

const getRentalRequestById = async (requestId: string): Promise<RentalRequestResponse> => {
  try {
    // Initialize web3Service
    await web3Service.initialize();
    
    // Get rental request from blockchain
    const blockchainRequest = await web3Service.getRentalRequest(Number(requestId));
    
    if (!blockchainRequest) {
      return {
        success: false,
        rentalRequest: null,
        error: 'Rental request not found'
      };
    }
    
    // Get associated property
    const property = await web3Service.getProperty(blockchainRequest.propertyId);
    
    // Convert to our frontend format
    const rentalRequest: RentalRequest = {
      id: blockchainRequest.id,
      propertyId: blockchainRequest.propertyId,
      tenant: blockchainRequest.tenant,
      landlord: property?.landlord,
      durationMonths: blockchainRequest.durationMonths,
      timestamp: blockchainRequest.timestamp,
      isApproved: blockchainRequest.isApproved,
      isRejected: false, // The contract doesn't have an explicit rejected state
      
      // Derived fields
      status: blockchainRequest.isApproved ? 'approved' : 'pending',
      requestDate: new Date(blockchainRequest.timestamp * 1000),
      monthlyRent: property?.pricePerMonth,
      
      // Include property data
      property: property ? {
        id: property.id,
        name: property.name,
        description: property.description,
        location: property.location,
        price: property.pricePerMonth,
        landlord: property.landlord,
        isActive: property.isActive,
        imageURL: property.imageURL,
        images: [{ url: property.imageURL || '' }],
        bedrooms: 0,
        bathrooms: 0,
        area: 0
      } : undefined
    };
    
    return {
      success: true,
      rentalRequest
    };
  } catch (error) {
    console.error(`Error fetching rental request ${requestId} from blockchain:`, error);
    return {
      success: false,
      rentalRequest: null,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

const createRentalRequest = async (requestData: {
  propertyId: number;
  durationMonths: number;
}): Promise<RentalRequestResponse> => {
  try {
    // Initialize web3Service
    await web3Service.initialize();
    
    // Create rental request on blockchain
    const requestId = await web3Service.createRentalRequest(
      requestData.propertyId,
      requestData.durationMonths
    );
    
    if (requestId === undefined) {
      throw new Error('Failed to get request ID from blockchain');
    }
    
    // Get the created request to return complete data
    const blockchainRequest = await web3Service.getRentalRequest(requestId);
    const property = await web3Service.getProperty(requestData.propertyId);
    
    // Convert to our frontend format
    const rentalRequest: RentalRequest = {
      id: requestId,
      propertyId: requestData.propertyId,
      tenant: blockchainRequest?.tenant || '',
      landlord: property?.landlord,
      durationMonths: requestData.durationMonths,
      timestamp: Math.floor(Date.now() / 1000),
      isApproved: false,
      isRejected: false,
      
      // Derived fields
      status: 'pending',
      requestDate: new Date(),
      monthlyRent: property?.pricePerMonth,
      
      // Include property data if available
      property: property ? {
        id: property.id,
        name: property.name,
        description: property.description,
        location: property.location,
        price: property.pricePerMonth,
        landlord: property.landlord,
        isActive: property.isActive,
        imageURL: property.imageURL,
        images: [{ url: property.imageURL || '' }],
        bedrooms: 0,
        bathrooms: 0,
        area: 0
      } : undefined
    };
    
    return {
      success: true,
      rentalRequest
    };
  } catch (error) {
    console.error('Error creating rental request on blockchain:', error);
    return {
      success: false,
      rentalRequest: null,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

const updateRentalRequestStatus = async (requestId: number, status: 'approved' | 'rejected'): Promise<RentalRequestResponse> => {
  try {
    // Initialize web3Service
    await web3Service.initialize();
    
    // Need to get the rental request to access its propertyId
    const existingRequest = await getRentalRequestById(requestId.toString());
    
    if (!existingRequest.success || !existingRequest.rentalRequest) {
      return {
        success: false,
        rentalRequest: null,
        error: 'Rental request not found'
      };
    }
    
    const propertyId = existingRequest.rentalRequest.propertyId;
    
    if (status === 'approved') {
      // Approve request on blockchain
      await web3Service.approveRentalRequest(propertyId, requestId);
    } else if (status === 'rejected') {
      // Reject request on blockchain
      await web3Service.rejectRentalRequest(propertyId, requestId);
    } else {
      throw new Error(`Invalid status: ${status}`);
    }
    
    // Get the updated request
    const blockchainRequest = await web3Service.getRentalRequest(requestId);
    
    // Get associated property
    const property = await web3Service.getProperty(blockchainRequest.propertyId);
    
    // Convert to our frontend format
    const rentalRequest: RentalRequest = {
      id: blockchainRequest.id,
      propertyId: blockchainRequest.propertyId,
      tenant: blockchainRequest.tenant,
      landlord: property?.landlord,
      durationMonths: blockchainRequest.durationMonths,
      timestamp: blockchainRequest.timestamp,
      isApproved: status === 'approved',
      isRejected: status === 'rejected',
      
      // Update derived fields
      status: status,
      requestDate: new Date(blockchainRequest.timestamp * 1000),
      monthlyRent: property?.pricePerMonth,
      
      // Include property data if available
      property: property ? {
        id: property.id,
        name: property.name,
        description: property.description,
        location: property.location,
        price: property.pricePerMonth,
        landlord: property.landlord,
        isActive: property.isActive,
        imageURL: property.imageURL,
        images: [{ url: property.imageURL || '' }],
        bedrooms: 0,
        bathrooms: 0,
        area: 0
      } : undefined
    };
    
    return {
      success: true,
      rentalRequest
    };
  } catch (error) {
    console.error(`Error updating rental request ${requestId} status to ${status} on blockchain:`, error);
    return {
      success: false,
      rentalRequest: null,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

// Note: The current smart contract doesn't support recording payments
// This function would need to be implemented with a contract update
const recordRentPayment = async (_requestId: number, _paymentData: {
  amount: number;
  transactionHash: string;
}): Promise<RentalRequestResponse> => {
  console.warn('Payment recording is not supported in the current blockchain contract');
  return {
    success: false,
    rentalRequest: null,
    error: 'Payment recording not supported in the current blockchain contract'
  };
};

export const rentalRequestService = {
  getAllRentalRequests,
  getRentalRequestById,
  createRentalRequest,
  updateRentalRequestStatus,
  recordRentPayment
};
