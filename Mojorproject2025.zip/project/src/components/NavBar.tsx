import { useState, useContext } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Web3Context } from '../contexts/Web3Context';

const NavBar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { account, userName, isConnected, isLandlord, isTenant, disconnectWallet } = useContext(Web3Context);
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    disconnectWallet();
    navigate('/');
  };

  // Determine user role for display
  const userRole = isLandlord ? 'Landlord' : isTenant ? 'Tenant' : 'Guest';

  // Format account address for display
  const formatAddress = (address: string | null) => {
    if (!address) return '';
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
  };

  return (
    <nav className="bg-gray-900 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0">
              <span className="text-xl font-bold">DecentRental</span>
            </Link>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <Link
                  to="/dashboard"
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    location.pathname === '/dashboard'
                      ? 'bg-gray-800 text-white'
                      : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                  }`}
                >
                  Dashboard
                </Link>
                {isTenant && (
                  <>
                    <Link
                      to="/properties"
                      className={`px-3 py-2 rounded-md text-sm font-medium ${
                        location.pathname === '/properties'
                          ? 'bg-gray-800 text-white'
                          : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                      }`}
                    >
                      Browse Properties
                    </Link>
                    <Link
                      to="/my-requests"
                      className={`px-3 py-2 rounded-md text-sm font-medium ${
                        location.pathname === '/my-requests'
                          ? 'bg-gray-800 text-white'
                          : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                      }`}
                    >
                      My Requests
                    </Link>
                  </>
                )}
                {isLandlord && (
                  <>
                    <Link
                      to="/my-properties"
                      className={`px-3 py-2 rounded-md text-sm font-medium ${
                        location.pathname === '/my-properties'
                          ? 'bg-gray-800 text-white'
                          : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                      }`}
                    >
                      My Properties
                    </Link>
                    <Link
                      to="/rental-requests"
                      className={`px-3 py-2 rounded-md text-sm font-medium ${
                        location.pathname === '/rental-requests'
                          ? 'bg-gray-800 text-white'
                          : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                      }`}
                    >
                      Rental Requests
                    </Link>
                  </>
                )}
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <div className="ml-4 flex items-center md:ml-6">
              {isConnected ? (
                <div className="relative ml-3 flex items-center space-x-4">
                  <div className="text-sm">
                    <span className="text-gray-300 mr-1">{userRole}:</span>
                    <span className="text-white font-medium">
                      {userName || formatAddress(account)}
                    </span>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="px-3 py-1 bg-red-600 text-white rounded-md text-sm hover:bg-red-700"
                  >
                    Logout
                  </button>
                </div>
              ) : (
                <Link
                  to="/connect"
                  className="px-3 py-1 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700"
                >
                  Connect Wallet
                </Link>
              )}
            </div>
          </div>
          <div className="-mr-2 flex md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none"
              aria-expanded="false"
            >
              <span className="sr-only">Open main menu</span>
              <svg
                className={`${isMenuOpen ? 'hidden' : 'block'} h-6 w-6`}
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
              <svg
                className={`${isMenuOpen ? 'block' : 'hidden'} h-6 w-6`}
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`${isMenuOpen ? 'block' : 'hidden'} md:hidden`}>
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
          <Link
            to="/dashboard"
            className={`block px-3 py-2 rounded-md text-base font-medium ${
              location.pathname === '/dashboard'
                ? 'bg-gray-800 text-white'
                : 'text-gray-300 hover:bg-gray-700 hover:text-white'
            }`}
            onClick={() => setIsMenuOpen(false)}
          >
            Dashboard
          </Link>
          {isTenant && (
            <>
              <Link
                to="/properties"
                className={`block px-3 py-2 rounded-md text-base font-medium ${
                  location.pathname === '/properties'
                    ? 'bg-gray-800 text-white'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                Browse Properties
              </Link>
              <Link
                to="/my-requests"
                className={`block px-3 py-2 rounded-md text-base font-medium ${
                  location.pathname === '/my-requests'
                    ? 'bg-gray-800 text-white'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                My Requests
              </Link>
            </>
          )}
          {isLandlord && (
            <>
              <Link
                to="/my-properties"
                className={`block px-3 py-2 rounded-md text-base font-medium ${
                  location.pathname === '/my-properties'
                    ? 'bg-gray-800 text-white'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                My Properties
              </Link>
              <Link
                to="/rental-requests"
                className={`block px-3 py-2 rounded-md text-base font-medium ${
                  location.pathname === '/rental-requests'
                    ? 'bg-gray-800 text-white'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                Rental Requests
              </Link>
            </>
          )}
        </div>
        <div className="pt-4 pb-3 border-t border-gray-700">
          <div className="flex items-center px-5">
            <div className="flex-shrink-0">
              <div className="h-10 w-10 rounded-full bg-gray-800 flex items-center justify-center">
                <span className="text-lg font-medium text-white">
                  {userName ? userName.charAt(0) : account?.charAt(0) || 'G'}
                </span>
              </div>
            </div>
            <div className="ml-3">
              <div className="text-base font-medium leading-none text-white">
                {userName || formatAddress(account)}
              </div>
              <div className="text-sm font-medium leading-none text-gray-400 mt-1">{userRole}</div>
            </div>
          </div>
          <div className="mt-3 px-2 space-y-1">
            {isConnected ? (
              <button
                onClick={() => {
                  handleLogout();
                  setIsMenuOpen(false);
                }}
                className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-red-400 hover:text-white hover:bg-gray-700"
              >
                Logout
              </button>
            ) : (
              <Link
                to="/connect"
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-300 hover:text-white hover:bg-gray-700"
                onClick={() => setIsMenuOpen(false)}
              >
                Connect Wallet
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default NavBar;
