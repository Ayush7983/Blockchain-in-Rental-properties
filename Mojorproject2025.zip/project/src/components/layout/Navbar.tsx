import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useWeb3 } from '../../hooks/useWeb3';
import { Building2, Menu, X, Home, Search, UserCircle } from 'lucide-react';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { isConnected, account, connectWallet } = useWeb3();
  const location = useLocation();

  // Handle scroll event to change navbar appearance
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when changing routes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  // Format Ethereum address for display
  const formatAddress = (address: string) => {
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container-custom flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center space-x-2">
          <Building2 className="h-8 w-8 text-primary-600" />
          <span className="text-xl font-heading font-bold text-primary-600">DecentRental</span>
        </Link>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link to="/" className="text-gray-700 hover:text-primary-600 font-medium">Home</Link>
          <Link to="/properties" className="text-gray-700 hover:text-primary-600 font-medium">Properties</Link>
          <Link to="/dashboard" className="text-gray-700 hover:text-primary-600 font-medium">Dashboard</Link>
        </nav>
        
        {/* Connect Wallet Button / Account Info */}
        <div className="hidden md:block">
          {isConnected && account ? (
            <div className="flex items-center space-x-3">
              <Link to="/dashboard\" className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-gray-100 text-gray-800 hover:bg-gray-200 transition-colors">
                <UserCircle className="h-5 w-5" />
                <span>{formatAddress(account)}</span>
              </Link>
            </div>
          ) : (
            <button 
              onClick={connectWallet}
              className="btn-primary flex items-center space-x-2"
            >
              <span>Connect Wallet</span>
            </button>
          )}
        </div>
        
        {/* Mobile Menu Button */}
        <button 
          className="md:hidden p-2 rounded-lg text-gray-700 hover:bg-gray-100"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg animate-slide-down">
          <div className="container-custom py-4 flex flex-col">
            <Link to="/" className="flex items-center py-3 px-4 hover:bg-gray-50 rounded-lg">
              <Home className="h-5 w-5 mr-3 text-primary-600" />
              <span>Home</span>
            </Link>
            <Link to="/properties" className="flex items-center py-3 px-4 hover:bg-gray-50 rounded-lg">
              <Building2 className="h-5 w-5 mr-3 text-primary-600" />
              <span>Properties</span>
            </Link>
            <Link to="/dashboard" className="flex items-center py-3 px-4 hover:bg-gray-50 rounded-lg">
              <UserCircle className="h-5 w-5 mr-3 text-primary-600" />
              <span>Dashboard</span>
            </Link>
            
            {/* Mobile Connect Button */}
            {isConnected && account ? (
              <div className="mt-3 px-4 py-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-500">Connected as</p>
                <p className="font-medium">{formatAddress(account)}</p>
              </div>
            ) : (
              <button 
                onClick={connectWallet}
                className="mt-3 mx-4 btn-primary"
              >
                Connect Wallet
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;