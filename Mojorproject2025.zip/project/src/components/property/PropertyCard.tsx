import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, BedDouble, Bath, Square } from 'lucide-react';

interface PropertyCardProps {
  id: number;
  title: string;
  location: string;
  price: number;
  image: string;
  bedrooms?: number;
  bathrooms?: number;
  area?: number;
  isAvailable: boolean;
}

const PropertyCard: React.FC<PropertyCardProps> = ({
  id,
  title,
  location,
  price,
  image,
  bedrooms,
  bathrooms,
  area,
  isAvailable,
}) => {
  return (
    <Link to={`/properties/${id}`} className="group">
      <div className="card overflow-hidden transition-transform duration-300 group-hover:translate-y-[-8px]">
        <div className="relative">
          {/* Property Image */}
          <div className="relative h-56 overflow-hidden">
            <img 
              src={image} 
              alt={title} 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            {/* Status Badge */}
            <div className={`absolute top-3 left-3 ${
              isAvailable ? 'bg-success-500' : 'bg-gray-500'
            } text-white text-xs font-medium px-2 py-1 rounded-md`}>
              {isAvailable ? 'Available' : 'Unavailable'}
            </div>
            
            {/* Price Badge */}
            <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-sm text-primary-700 font-semibold px-3 py-1.5 rounded-lg shadow-sm">
              {price} ETH/month
            </div>
          </div>
          
          {/* Content */}
          <div className="p-5">
            <h3 className="text-lg font-semibold text-gray-800 mb-1 line-clamp-1">{title}</h3>
            
            <div className="flex items-center text-gray-500 mb-3">
              <MapPin className="h-4 w-4 mr-1" />
              <span className="text-sm line-clamp-1">{location}</span>
            </div>
            
            {/* Property Details */}
            {(bedrooms || bathrooms || area) && (
              <div className="flex items-center justify-between mt-4 border-t pt-4 border-gray-100">
                {bedrooms && (
                  <div className="flex items-center">
                    <BedDouble className="h-4 w-4 text-gray-400 mr-1" />
                    <span className="text-sm text-gray-600">{bedrooms} {bedrooms === 1 ? 'Bed' : 'Beds'}</span>
                  </div>
                )}
                
                {bathrooms && (
                  <div className="flex items-center">
                    <Bath className="h-4 w-4 text-gray-400 mr-1" />
                    <span className="text-sm text-gray-600">{bathrooms} {bathrooms === 1 ? 'Bath' : 'Baths'}</span>
                  </div>
                )}
                
                {area && (
                  <div className="flex items-center">
                    <Square className="h-4 w-4 text-gray-400 mr-1" />
                    <span className="text-sm text-gray-600">{area} m²</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
};

export default PropertyCard;