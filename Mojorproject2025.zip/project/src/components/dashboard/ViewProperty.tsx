import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ethers } from 'ethers';
import { ArrowLeft, Edit, Map, Home, Users, Bath, AspectRatio, Calendar } from 'lucide-react';
import Button from '../common/Button';
import web3Service from '../../services/web3Service';
import { rentalRequestService } from '../../services/rentalRequestService';

const ViewProperty = () => {
  const { id } = useParams<{ id: string }>();
  const propertyId = id ? parseInt(id) : 0;
  
  const [isLoading, setIsLoading] = useState(true);
  const [property, setProperty] = useState<any>(null);
  const [rentalRequests, setRentalRequests] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  // Fetch property details and rental requests for this property
  useEffect(() => {
    const fetchPropertyData = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // Initialize web3Service
        await web3Service.initialize();
        
        // Get property details
        const propertyData = await web3Service.getProperty(propertyId);
        
        // Format amenities from description
        let amenities: string[] = [];
        const descriptionParts = propertyData.description.split('Features:');
        if (descriptionParts.length > 1) {
          const featuresList = descriptionParts[1].trim().split('\n');
          amenities = featuresList
            .map(feature => feature.replace('- ', '').trim())
            .filter(feature => 
              !feature.includes('bedroom') && 
              !feature.includes('bathroom') && 
              !feature.includes('sq m')
            );
        }
        
        // Get rental requests for this property
        const requestsResponse = await rentalRequestService.getPropertyRentalRequests(propertyId);
        const propertyRequests = requestsResponse.success ? requestsResponse.rentalRequests : [];
        
        // Get current tenant if property is rented
        const approvedRequest = propertyRequests.find(req => req.status === 'approved');
        
        // Set property data with additional calculated fields
        setProperty({
          ...propertyData,
          formattedPrice: ethers.formatEther(propertyData.pricePerMonth.toString()),
          rentalStatus: approvedRequest ? 'Rented' : propertyData.isActive ? 'Available' : 'Inactive',
          tenant: approvedRequest ? approvedRequest.tenant : null,
          amenities
        });
        
        // Set rental requests
        setRentalRequests(propertyRequests);
        
      } catch (err) {
        console.error('Error fetching property details:', err);
        setError('Failed to load property details. Please try again.');
      } finally {
        setIsLoading(false);
      }
    };
    
    if (propertyId) {
      fetchPropertyData();
    }
  }, [propertyId]);
  
  if (isLoading) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-6 flex justify-center items-center min-h-[400px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-gray-200 border-t-primary-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading property details...</p>
        </div>
      </div>
    );
  }
  
  if (error || !property) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="text-center py-8">
          <div className="text-red-500 text-lg mb-2">
            {error || 'Property not found'}
          </div>
          <Link to="/dashboard/properties">
            <Button variant="outline">
              Back to My Properties
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  // Calculate lease status and display information
  const getRentalStatusBadge = (status: string) => {
    switch (status) {
      case 'Rented':
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">Rented</span>;
      case 'Available':
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Available</span>;
      case 'Inactive':
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">Inactive</span>;
      default:
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">{status}</span>;
    }
  };

  return (
    <div>
      {/* Header with back button and edit button */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Link to="/dashboard/properties" className="text-gray-500 hover:text-gray-700 mr-4">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-800">{property.name}</h1>
        </div>
        <Link to={`/dashboard/edit-property/${propertyId}`}>
          <Button 
            variant="outline"
            size="sm"
            icon={<Edit className="h-4 w-4 mr-1" />}
          >
            Edit Property
          </Button>
        </Link>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        {/* Property image */}
        <div className="w-full h-64 bg-gray-200 relative">
          {property.imageURL ? (
            <img 
              src={property.imageURL} 
              alt={property.name} 
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="flex items-center justify-center h-full bg-gray-100">
              <Home className="h-16 w-16 text-gray-400" />
              <p className="text-gray-500 mt-2">No image available</p>
            </div>
          )}
          
          {/* Status badge */}
          <div className="absolute top-4 right-4">
            {getRentalStatusBadge(property.rentalStatus)}
          </div>
        </div>
        
        {/* Property details */}
        <div className="p-6">
          <div className="flex flex-wrap justify-between mb-6">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-bold mb-1">{property.name}</h2>
              <div className="flex items-center text-gray-600">
                <Map className="h-4 w-4 mr-1" />
                <span>{property.location}</span>
              </div>
            </div>
            <div>
              <div className="text-xl font-bold text-primary-600">{property.formattedPrice} ETH/month</div>
              <div className="text-sm text-gray-500">Monthly rental price</div>
            </div>
          </div>
          
          {/* Features */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="flex items-center">
              <Users className="h-5 w-5 text-gray-500 mr-2" />
              <div>
                <div className="text-lg font-semibold">{property.bedrooms || 1}</div>
                <div className="text-xs text-gray-500">Bedrooms</div>
              </div>
            </div>
            <div className="flex items-center">
              <Bath className="h-5 w-5 text-gray-500 mr-2" />
              <div>
                <div className="text-lg font-semibold">{property.bathrooms || 1}</div>
                <div className="text-xs text-gray-500">Bathrooms</div>
              </div>
            </div>
            <div className="flex items-center">
              <AspectRatio className="h-5 w-5 text-gray-500 mr-2" />
              <div>
                <div className="text-lg font-semibold">{property.area || 0} m²</div>
                <div className="text-xs text-gray-500">Area</div>
              </div>
            </div>
          </div>
          
          {/* Description */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Description</h3>
            <p className="text-gray-600 whitespace-pre-wrap">
              {property.description?.split('Features:')[0] || property.description}
            </p>
          </div>
          
          {/* Amenities */}
          {property.amenities && property.amenities.length > 0 && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Amenities</h3>
              <ul className="grid grid-cols-2 gap-x-4 gap-y-2">
                {property.amenities.map((amenity: string, index: number) => (
                  <li key={index} className="flex items-center text-gray-600">
                    <span className="w-1 h-1 bg-primary-600 rounded-full mr-2"></span>
                    {amenity}
                  </li>
                ))}
              </ul>
            </div>
          )}
          
          {/* Rental Status */}
          <div>
            <h3 className="text-lg font-semibold mb-2">Rental Status</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center mb-2">
                <Calendar className="h-5 w-5 text-gray-500 mr-2" />
                <span className="font-medium">Current Status:</span>
                <span className="ml-2">{getRentalStatusBadge(property.rentalStatus)}</span>
              </div>
              
              {property.tenant && (
                <div className="text-sm text-gray-600">
                  <span className="font-medium">Current Tenant:</span>{' '}
                  <span className="font-mono">{property.tenant}</span>
                </div>
              )}
              
              {rentalRequests.length > 0 ? (
                <div className="mt-2 text-sm">
                  <div className="font-medium text-gray-600">
                    {rentalRequests.filter(req => req.status === 'pending').length} pending rental request(s)
                  </div>
                  <Link to="/dashboard/rental-requests" className="text-primary-600 hover:text-primary-700 text-sm">
                    View all requests
                  </Link>
                </div>
              ) : (
                <div className="mt-2 text-sm text-gray-600">No rental requests received yet</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewProperty;
