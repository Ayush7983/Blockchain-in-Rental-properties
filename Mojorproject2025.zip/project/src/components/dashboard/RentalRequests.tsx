import { useState, useEffect, useContext } from 'react';
import { Clock, Check, X, RefreshCw } from 'lucide-react';
import { Web3Context } from '../../contexts';
import { rentalRequestService } from '../../services/rentalRequestService';
import web3Service from '../../services/web3Service';
import Button from '../common/Button';

// Import types from services
import { RentalRequest } from '../../services/rentalRequestService';

const RentalRequests = () => {
  // Context for wallet and contract interaction
  const { account, contract, isLandlord } = useContext(Web3Context);
  
  // State management
  const [requests, setRequests] = useState<RentalRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingIds, setProcessingIds] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Load properties and requests from blockchain
  const loadRequests = async () => {
    if (!account || !contract || !isLandlord) {
      setError('Please connect your wallet as a landlord');
      setLoading(false);
      return;
    }
    
    try {
      setLoading(true);
      setError(null);
      setSuccessMessage(null);
      
      console.log('Requesting rental requests for landlord account:', account);
      
      // Direct approach - fetch requests for each property directly
      try {
        // Get all properties first
        const landlordPropertiesResponse = await contract.getMyProperties();
        console.log('Landlord properties from contract:', landlordPropertiesResponse);
        
        let allRequests: RentalRequest[] = [];
        
        // For each property ID, get its requests
        for (const propertyId of landlordPropertiesResponse) {
          try {
            console.log('Fetching requests for property ID:', propertyId.toString());
            const propertyRequestIds = await contract.getPropertyRequests(Number(propertyId));
            console.log('Request IDs for property', propertyId.toString(), ':', propertyRequestIds);
            
            // For each request ID, get details
            for (const requestId of propertyRequestIds) {
              try {
                console.log('Getting details for request ID:', requestId.toString());
                const [propId, tenant, duration, timestamp, isApproved] = 
                  await contract.getRentalRequest(Number(requestId));
                
                allRequests.push({
                  id: Number(requestId),
                  propertyId: Number(propId),
                  tenant,
                  durationMonths: Number(duration),
                  timestamp: Number(timestamp),
                  isApproved,
                  status: isApproved ? 'approved' : 'pending'
                });
              } catch (requestError) {
                console.error('Error getting request details:', requestError);
              }
            }
          } catch (propertyError) {
            console.error('Error getting property requests:', propertyError);
          }
        }
        
        console.log('All landlord rental requests found:', allRequests);
        setRequests(allRequests);
        
        if (allRequests.length === 0) {
          setError('No rental requests found for your properties');
        }
      } catch (directError) {
        console.error('Error using direct contract approach:', directError);
        
        // Fallback to using the service
        console.log('Falling back to rental request service...');
        const response = await rentalRequestService.getAllRentalRequests({
          landlord: account
        });
        
        if (response.success) {
          const requests = response.rentalRequests;
          setRequests(requests);
          console.log('Rental requests loaded via service:', requests);
        } else {
          throw new Error('Failed to fetch rental requests from blockchain');
        }
      }
    } catch (error: any) {
      console.error('Error loading rental requests from blockchain:', error);
      setError(error.message || 'Failed to load rental requests from blockchain');
    } finally {
      setLoading(false);
    }
  };
  
  // Load data on component mount
  useEffect(() => {
    if (account && isLandlord) {
      loadRequests();
    }
  }, [account, isLandlord]);
  
  // Smart contract and blockchain interaction
  const handleApprove = async (requestId: number, propertyId: number) => {
    if (!account || !contract) {
      setError('Wallet connection required');
      return;
    }

    // Add to processing IDs to show loading state
    setProcessingIds(prev => [...prev, requestId.toString()]);
    setError(null);
    setSuccessMessage(null);

    try {
      console.log(`Approving request ${requestId} for property ${propertyId}`);
      
      // Use web3Service to handle the transaction
      await web3Service.approveRentalRequest(propertyId, requestId);
      
      // Update local state
      setRequests(prev => prev.map(req => 
        req.id === requestId
          ? { ...req, status: 'approved', isApproved: true }
          : req
      ));

      // Show success message
      setSuccessMessage('Rental request approved successfully!');
      
      // Refresh all requests to ensure data consistency
      setTimeout(loadRequests, 2000);
    } catch (error: any) {
      console.error('Error approving rental request:', error);
      setError('Failed to approve rental request. Please try again.');
    } finally {
      // Remove from processing
      setProcessingIds(prev => prev.filter(id => id !== requestId.toString()));
    }
  };

  const handleReject = async (requestId: number, propertyId: number) => {
    if (!account || !contract) {
      setError('Wallet connection required');
      return;
    }

    // Add to processing IDs to show loading state
    setProcessingIds(prev => [...prev, requestId.toString()]);
    setError(null);
    setSuccessMessage(null);

    try {
      console.log(`Rejecting request ${requestId} for property ${propertyId}`);
      
      // Use web3Service to handle the transaction
      await web3Service.rejectRentalRequest(propertyId, requestId);
      
      // Update local state
      setRequests(prev => prev.map(req => 
        req.id === requestId
          ? { ...req, status: 'rejected', isRejected: true }
          : req
      ));

      // Show success message
      setSuccessMessage('Rental request rejected successfully!');
      
      // Refresh all requests to ensure data consistency
      setTimeout(loadRequests, 2000);
    } catch (error: any) {
      console.error('Error rejecting rental request:', error);
      setError('Failed to reject rental request. Please try again.');
    } finally {
      // Remove from processing
      setProcessingIds(prev => prev.filter(id => id !== requestId.toString()));
    }
  };

  return (
    <>
      <div className="mb-6 flex justify-between items-center">
        <h2 className="text-2xl font-bold">Rental Requests</h2>
        <Button variant="secondary" size="sm" onClick={loadRequests}>
          <RefreshCw className="mr-2 h-4 w-4" /> Refresh
        </Button>
      </div>
      
      {/* Success message */}
      {successMessage && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          <p>{successMessage}</p>
        </div>
      )}
      
      {/* Error message */}
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          <p>{error}</p>
        </div>
      )}
      
      {/* Loading indicator */}
      {loading ? (
        <div className="flex justify-center items-center py-20">
          <RefreshCw className="animate-spin h-8 w-8 text-gray-500" />
        </div>
      ) : requests.length === 0 ? (
        <div className="text-center py-20 text-gray-500">
          <p>No rental requests found.</p>
        </div>
      ) : (
        <div className="overflow-x-auto w-full">
          <table className="min-w-full bg-white rounded-lg overflow-hidden shadow-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-1/4">Property</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-1/6">Monthly Rent</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-1/6">Tenant</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-1/6">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-1/12">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-1/6">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {requests.map((request) => (
                <tr key={request.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      {request.property?.imageURL ? (
                        <img
                          src={web3Service.fixCloudinaryURL(request.property.imageURL)}
                          alt={request.property.name}
                          className="h-10 w-10 rounded-md object-cover mr-3"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = '/placeholder-property.jpg';
                          }}
                        />
                      ) : (
                        <div className="h-10 w-10 rounded-md bg-gray-200 mr-3" />
                      )}
                      <div className="truncate">
                        <div className="font-medium text-gray-900 truncate">{request.property?.name || 'Unknown Property'}</div>
                        <div className="text-gray-500 text-sm truncate">{request.property?.location || 'Unknown'}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">Tenant {request.tenant.substring(0, 6)}...</div>
                    <div className="text-gray-500 text-xs">{request.tenant}</div>
                  </td>
                  <td className="px-4 py-4">
                    <div className="text-sm text-gray-900">{new Date(request.timestamp * 1000).toLocaleDateString()}</div>
                  </td>
                  <td className="px-4 py-4">
                    <div className="text-sm text-gray-900">{request.durationMonths} months</div>
                  </td>
                  <td className="px-4 py-4">
                    <div className="text-sm text-gray-900">{request.property?.pricePerMonth ? `${web3Service.formatPrice(request.property.pricePerMonth)} ETH/month` : 'N/A'}</div>
                  </td>
                  <td className="px-6 py-4">
                    {request.status === 'pending' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                        <Clock className="mr-1 h-3 w-3" /> Pending
                      </span>
                    )}
                    {request.status === 'approved' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        <Check className="mr-1 h-3 w-3" /> Approved
                      </span>
                    )}
                    {request.status === 'rejected' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                        <X className="mr-1 h-3 w-3" /> Rejected
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-4">
                    {request.status === 'pending' && (
                      <div className="flex space-x-2">
                        <Button
                          onClick={() => handleApprove(request.id, request.propertyId)}
                          disabled={processingIds.includes(request.id.toString())}
                          variant="primary"
                          size="sm"
                        >
                          {processingIds.includes(request.id.toString()) ? (
                            <RefreshCw className="mr-2 h-3 w-3 animate-spin" />
                          ) : (
                            <Check className="mr-2 h-3 w-3" />
                          )}
                          Approve
                        </Button>
                        <Button
                          onClick={() => handleReject(request.id, request.propertyId)}
                          disabled={processingIds.includes(request.id.toString())}
                          variant="secondary"
                          size="sm"
                        >
                          {processingIds.includes(request.id.toString()) ? (
                            <RefreshCw className="mr-2 h-3 w-3 animate-spin" />
                          ) : (
                            <X className="mr-2 h-3 w-3" />
                          )}
                          Reject
                        </Button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
};

export default RentalRequests;
