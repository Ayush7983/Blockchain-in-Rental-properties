import { useState } from 'react';
import { User, Mail, Shield } from 'lucide-react';
import Button from '../common/Button';
import { useWeb3 } from '../../hooks/useWeb3';

const ProfileSettings = () => {
  const { account } = useWeb3();
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // In a real app, update profile info on blockchain or database
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert('Profile updated successfully!');
    } catch (error) {
      console.error('Error updating profile:', error);
      alert('Failed to update profile. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Profile Settings</h1>
      
      <div className="bg-white rounded-xl shadow-sm p-6">
        {/* Wallet Info */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Wallet Information</h2>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center">
              <Shield className="h-5 w-5 text-primary-600 mr-3" />
              <div>
                <p className="text-sm text-gray-500">Connected Wallet</p>
                <p className="font-medium">{account}</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Profile Form */}
        <form onSubmit={handleSubmit}>
          <h2 className="text-lg font-semibold mb-4">Profile Information</h2>
          
          <div className="space-y-6">
            <div>
              <label htmlFor="displayName" className="block text-sm font-medium text-gray-700 mb-1">
                Display Name
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  id="displayName"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="pl-10 w-full border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="Enter your display name"
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 w-full border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="Enter your email address"
                />
              </div>
              <p className="mt-2 text-sm text-gray-500">
                Your email will be used for notifications only and won't be shared.
              </p>
            </div>
          </div>
          
          <div className="mt-8">
            <Button
              type="submit"
              variant="primary"
              isLoading={isSubmitting}
            >
              Save Changes
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProfileSettings;