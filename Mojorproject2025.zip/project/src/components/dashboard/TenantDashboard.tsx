import { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom';
import { Home, CircleDollarSign, Clock, Calendar, ArrowUpRight, Eye } from 'lucide-react';
import Button from '../common/Button';
import { Web3Context } from '../../contexts/Web3Context';
import type { Web3ContextType } from '../../contexts/Web3Context';
import { rentalRequestService } from '../../services/rentalRequestService';
import { format } from 'date-fns';
import web3Service from '../../services/web3Service';

interface ActivityItem {
  id: string;
  type: 'request' | 'payment';
  title: string;
  description: string;
  timestamp: Date;
  transactionHash?: string;
  link?: string;
}

interface CurrentRental {
  id: number;
  propertyId: number;
  name: string;
  location: string;
  imageURL: string;
  monthlyRent: number;
  durationMonths: number;
  startDate: Date;
  landlordAddress: string;
}

const TenantDashboard = () => {
  const { account, isConnected, isTenant } = useContext<Web3ContextType>(Web3Context);
  const [stats, setStats] = useState({
    activeRentals: 0,
    pendingRequests: 0,
    totalSpent: 0,
  });
  const [loading, setLoading] = useState(true);
  const [recentActivity, setRecentActivity] = useState<ActivityItem[]>([]);
  const [currentRental, setCurrentRental] = useState<CurrentRental | null>(null);
  const [nextPaymentDate, setNextPaymentDate] = useState<Date | null>(null);

  useEffect(() => {
    const fetchDashboardData = async () => {
      if (!account || !isConnected || !isTenant) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        
        // Initialize web3Service if needed
        await web3Service.initialize();
        
        // Fetch rental requests for the tenant
        const requestsResponse = await rentalRequestService.getAllRentalRequests({
          tenant: account
        });
        
        // Calculate stats from real data
        const allRequests = requestsResponse.success ? requestsResponse.rentalRequests : [];
        
        // Get active and pending rental requests
        const activeRequests = allRequests.filter((req: any) => req.status === 'approved');
        const pendingRequests = allRequests.filter((req: any) => req.status === 'pending');
        
        // Calculate total spent (from payment history)
        let totalSpent = 0;
        activeRequests.forEach((request: any) => {
          if (request.paymentHistory && Array.isArray(request.paymentHistory)) {
            request.paymentHistory.forEach((payment: any) => {
              totalSpent += Number(payment.amount || 0);
            });
          }
        });
        
        // Convert to ETH for display
        const totalSpentInEth = Number(totalSpent.toFixed(4));
        
        setStats({
          activeRentals: activeRequests.length,
          pendingRequests: pendingRequests.length,
          totalSpent: totalSpentInEth
        });
        
        // Generate recent activity items
        const activityItems: ActivityItem[] = [];

        // Create activity items from rental requests
        for (const request of allRequests) {
          // Add request activity
          activityItems.push({
            id: `request-${request.requestId || request.id}-${Date.now()}`,
            type: 'request',
            title: request.property?.title || request.property?.name || 'Unknown property',
            description: `Rental request ${request.isApproved ? 'approved' : request.isRejected ? 'rejected' : 'pending'}`,
            timestamp: request.requestDate || new Date(request.timestamp * 1000),
            link: `/dashboard/tenant/requests`
          });

          // Add payment activities
          if (request.paymentHistory && request.paymentHistory.length > 0) {
            request.paymentHistory.forEach((payment: { amount: string, timestamp: number, transactionHash: string }) => {
              activityItems.push({
                id: `payment-${request.requestId || request.id}-${payment.transactionHash?.substring(0, 10) || Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
                type: 'payment',
                title: request.property?.title || request.property?.name || 'Unknown property',
                description: `Paid ${web3Service.formatPrice(payment.amount)} ETH rent`,
                timestamp: new Date(payment.timestamp * 1000),
                transactionHash: payment.transactionHash,
                link: `/dashboard/tenant/payments`
              });
            });
          }
        }  
        
        // Sort and set recent activity
        setRecentActivity(activityItems.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()).slice(0, 3));
          
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, [account, isConnected, isTenant]);

  return (
    <>

        <div className="flex flex-wrap items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Tenant Dashboard</h1>
        <Link to="/properties">
          <Button variant="primary" size="sm">
            Browse Properties
          </Button>
        </Link>
      </div>
      
        {/* Main Content */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 w-full mb-8">

        {/* Active Rentals */}
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="bg-primary-100 p-3 rounded-lg">
              <Home className="h-6 w-6 text-primary-600" />
            </div>
            <ArrowUpRight className="h-5 w-5 text-success-500" />
          </div>
          <h3 className="text-gray-500 mb-1">Active Rentals</h3>
          <div className="text-3xl font-bold text-gray-800">{stats.activeRentals}</div>
          <Link to="/dashboard/my-rentals" className="mt-4 text-sm text-primary-600 hover:text-primary-700 inline-flex items-center">
            View all
            <Eye className="ml-1 h-4 w-4" />
          </Link>
        </div>
        
        {/* Pending Requests */}
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="bg-warning-100 p-3 rounded-lg">
              <Clock className="h-6 w-6 text-warning-600" />
            </div>
            <ArrowUpRight className="h-5 w-5 text-success-500" />
          </div>
          <h3 className="text-gray-500 mb-1">Pending Requests</h3>
          <div className="text-3xl font-bold text-gray-800">{stats.pendingRequests}</div>
          <Link to="/dashboard/rentals" className="mt-4 text-sm text-primary-600 hover:text-primary-700 inline-flex items-center">
            View details
            <Eye className="ml-1 h-4 w-4" />
          </Link>
        </div>
        
        {/* Total Spent */}
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="bg-accent-100 p-3 rounded-lg">
              <CircleDollarSign className="h-6 w-6 text-accent-600" />
            </div>
            <ArrowUpRight className="h-5 w-5 text-success-500" />
          </div>
          <h3 className="text-gray-500 mb-1">Total Spent</h3>
          <div className="text-3xl font-bold text-gray-800">{stats.totalSpent} ETH</div>
          <span className="mt-4 text-sm text-gray-500 inline-flex items-center">
            Last updated: Today
          </span>
        </div>
      </div>
      
      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Link to="/properties" className="bg-primary-50 hover:bg-primary-100 p-4 rounded-lg transition-colors">
            <Home className="h-6 w-6 text-primary-600 mb-2" />
            <h3 className="font-medium">Browse Properties</h3>
            <p className="text-sm text-gray-600">Find a new place to rent</p>
          </Link>
          
          <Link to="/dashboard/my-rentals" className="bg-primary-50 hover:bg-primary-100 p-4 rounded-lg transition-colors">
            <Calendar className="h-6 w-6 text-primary-600 mb-2" />
            <h3 className="font-medium">My Rentals</h3>
            <p className="text-sm text-gray-600">View your active rentals</p>
          </Link>
          
          <Link to="/dashboard/settings" className="bg-primary-50 hover:bg-primary-100 p-4 rounded-lg transition-colors">
            <CircleDollarSign className="h-6 w-6 text-primary-600 mb-2" />
            <h3 className="font-medium">Settings</h3>
            <p className="text-sm text-gray-600">Update your profile</p>
          </Link>
        </div>
      </div>
      
      {/* Current Rental */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Current Rental</h2>
        
        {stats.activeRentals > 0 && currentRental ? (
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/3">
                <img 
                  src={web3Service.fixCloudinaryURL(currentRental.imageURL)} 
                  alt={currentRental.name} 
                  className="h-full w-full object-cover"
                  onError={(e) => {
                    // Fallback image if the property image doesn't load
                    const target = e.target as HTMLImageElement;
                    console.log('Image load error in TenantDashboard:', currentRental.imageURL);
                    target.src = '/placeholder-property.jpg';
                  }}
                />
              </div>
              <div className="p-6 md:p-8 md:w-2/3">
                <h3 className="text-lg font-semibold mb-2">{currentRental.name}</h3>
                <p className="text-gray-600 mb-4">{currentRental.location}</p>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div>
                    <p className="text-sm text-gray-500">Monthly Rent</p>
                    <p className="font-medium">{currentRental.monthlyRent} ETH</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Lease Ends</p>
                    <p className="font-medium">
                      {new Date(
                        currentRental.startDate.getTime() + 
                        (currentRental.durationMonths * 30 * 24 * 60 * 60 * 1000)
                      ).toLocaleDateString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Lease Started</p>
                    <p className="font-medium">{currentRental.startDate.toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Landlord</p>
                    <p className="font-medium" title={currentRental.landlordAddress}>
                      {`${currentRental.landlordAddress.substring(0, 6)}...${currentRental.landlordAddress.substring(38)}`}
                    </p>
                  </div>
                </div>
                
                <div className="flex space-x-3">
                  <Button variant="primary" size="sm">
                    View Details
                  </Button>
                  <Button variant="outline" size="sm">
                    Contact Landlord
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-8 bg-gray-50 rounded-lg">
            <Home className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-700 mb-2">No Active Rentals</h3>
            <p className="text-gray-500 mb-6">
              You don't have any active rentals at the moment.
            </p>
            <Link to="/properties">
              <Button variant="primary">
                Browse Properties
              </Button>
            </Link>
          </div>
        )}
      </div>
      
      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow-sm p-6 md:p-8 mb-8">
        <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
        
        {loading ? (
          <div className="p-4 text-center text-gray-500">Loading activity...</div>
        ) : recentActivity.length === 0 ? (
          <div className="p-4 text-center text-gray-500">No recent activity</div>
        ) : (
          <div className="space-y-4">
            {recentActivity.map(activity => (
              <div 
                key={`activity-${activity.id}`}
                className="flex items-center space-x-4 p-4 hover:bg-gray-50 rounded-lg"
              >
                <div className={`p-3 rounded-full ${activity.type === 'request' ? 'bg-blue-100' : 'bg-green-100'}`}>
                  {activity.type === 'request' ? (
                    <Home className="h-5 w-5 text-blue-600" />
                  ) : (
                    <CircleDollarSign className="h-5 w-5 text-green-600" />
                  )}
                </div>
                
                <div className="flex-1">
                  <p className="font-medium">{activity.title}</p>
                  <p className="text-sm text-gray-600">{activity.description}</p>
                </div>
                
                <div className="text-right">
                  <p className="text-sm text-gray-600">{format(activity.timestamp, 'MMM d, yyyy')}</p>
                  {activity.transactionHash && (
                    <a 
                      href={`https://sepolia.etherscan.io/tx/${activity.transactionHash}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-primary-600 hover:underline"
                    >
                      View transaction
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Upcoming Payments */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-xl font-semibold mb-4">Upcoming Payments</h2>
        
        {stats.activeRentals > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Property</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Due Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">Modern Apartment</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">Oct 1, 2023</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">0.5 ETH</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                      Upcoming
                    </span>
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">Modern Apartment</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">Nov 1, 2023</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">0.5 ETH</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                      Scheduled
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-6 bg-gray-50 rounded-lg">
            <Calendar className="h-10 w-10 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-500">
              No upcoming payments scheduled.
            </p>
          </div>
        )}
      </div>
    </>
  );
};

export default TenantDashboard;