import { useState, useEffect, useContext } from 'react';
import { Home, RefreshCw } from 'lucide-react';
import Button from '../common/Button';
import { Web3Context } from '../../contexts/Web3Context';
import { rentalRequestService } from '../../services/rentalRequestService';
import { ethers } from 'ethers';

// Define our own Rental interface based on what we expect from the API
interface Rental {
  _id: string;
  requestId: string;
  property: {
    _id: string;
    title: string;
    location: string;
    images?: { url: string }[];
  };
  startDate?: string;
  endDate?: string;
  monthlyRent: number;
  status: 'pending' | 'approved' | 'rejected';
  nextPaymentDue?: Date;
  duration: number;
  lastPaymentDate?: Date;
  // Additional properties for UI rendering
  isActive?: boolean;
}

const MyRentals = () => {
  // Get context data first
  const { account, contract, isConnected, isTenant } = useContext(Web3Context);
  
  // State declarations
  const [rentals, setRentals] = useState<Rental[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedRental, setSelectedRental] = useState<Rental | null>(null);
  const [processingPayment, setProcessingPayment] = useState<boolean>(false);
  const [paymentSuccess, setPaymentSuccess] = useState<boolean>(false);
  const [refreshing, setRefreshing] = useState<boolean>(false);

  const fetchRentals = async () => {
    if (!account || !isTenant) return;
    
    try {
      setLoading(true);
      setError(null);
      
      const response = await rentalRequestService.getAllRentalRequests({
        tenant: account,
        status: 'approved' // Only get approved requests as rentals
      });
      
      if (response.success) {
        // Map the response data to match the Rental interface exactly
        const mappedRentals = response.rentalRequests.map((req: any): Rental => ({
          _id: req._id || '',
          requestId: req.requestId || '',
          property: {
            _id: req.property?._id || '',
            title: req.property?.title || '',
            location: req.property?.location || '',
            images: req.property?.images || []
          },
          monthlyRent: req.monthlyRent || 0,
          duration: req.duration || 0,
          status: (req.status as 'pending' | 'approved' | 'rejected') || 'pending',
          isActive: req.status === 'approved' // Add isActive flag based on status
        }));
        setRentals(mappedRentals);
      } else {
        setRentals([]);
      }
    } catch (err) {
      console.error('Error fetching rentals:', err);
      setError('Failed to load your rentals. Please try again.');
      setRentals([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (isConnected && isTenant) {
      fetchRentals();
    } else {
      setLoading(false);
    }
  }, [isConnected, isTenant, account]);

  // Render loading state
  if (loading && isConnected) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="text-lg">Loading your rentals...</div>
      </div>
    );
  }
  
  // Render error state
  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-600">
        {error}
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">My Rentals</h1>
      
      <div className="space-y-6">
        {rentals.map((rental) => (
          <div key={rental._id} className="bg-white rounded-xl shadow-sm overflow-hidden">
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/3">
                <img 
                  src={rental.property.images && rental.property.images.length > 0 
                    ? rental.property.images[0].url 
                    : 'https://images.pexels.com/photos/1918291/pexels-photo-1918291.jpeg'} 
                  alt={rental.property.title} 
                  className="h-48 md:h-full w-full object-cover"
                />
              </div>
              
              <div className="p-6 md:w-2/3">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold mb-1">{rental.property.title}</h3>
                    <p className="text-gray-600">{rental.property.location}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    rental.status === 'approved' 
                      ? 'bg-success-100 text-success-800'
                      : 'bg-warning-100 text-warning-800'
                  }`}>
                    {rental.status === 'approved' ? 'Active' : 'Pending'}
                  </span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {rental.status === 'approved' && (
                    <>
                      <div>
                        <p className="text-sm text-gray-500">Lease Period</p>
                        <p className="font-medium">
                          {rental.startDate} - {rental.endDate}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Next Payment</p>
                        <p className="font-medium">{rental.nextPaymentDue ? formatDate(rental.nextPaymentDue) : 'Not scheduled'}</p>
                      </div>
                    </>
                  )}
                  <div>
                    <p className="text-sm text-gray-500">Monthly Rent</p>
                    <p className="font-medium">{rental.monthlyRent} ETH</p>
                  </div>
                </div>
                
                <div className="flex space-x-3">
                  {rental.status === 'approved' ? (
                    <>
                      <Button 
                        variant="primary"
                        onClick={() => handlePayRent(rental)}
                      >
                        Pay Rent
                      </Button>
                      <Button variant="outline">
                        View Details
                      </Button>
                    </>
                  ) : (
                    <Button variant="outline" disabled>
                      Awaiting Approval
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
        
        {rentals.length === 0 && (
          <div className="text-center py-12 bg-white rounded-xl shadow-sm">
            <Home className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Rentals Found</h3>
            <p className="text-gray-500 mb-4">
              You haven't rented any properties yet or your rental requests are still pending approval.
            </p>
            <Button 
              variant="outline" 
              onClick={() => {
                setRefreshing(true);
                fetchRentals();
              }}
              disabled={refreshing}
            >
              {refreshing ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Refreshing...
                </>
              ) : (
                <>Refresh</>  
              )}
            </Button>
          </div>
        )}
      </div>
      
      {/* Payment Modal */}
      {selectedRental && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            {paymentSuccess ? (
              <div className="text-center">
                <h3 className="text-xl font-medium mb-2">Payment Successful!</h3>
                <p className="mb-4">Your rent payment has been processed. Thank you!</p>
                <Button
                  variant="primary"
                  onClick={() => {
                    setSelectedRental(null);
                    setPaymentSuccess(false);
                    fetchRentals(); // Refresh the rental list
                  }}
                >
                  Close
                </Button>
              </div>
            ) : (
              <>
                <h3 className="text-xl font-medium mb-4">Make Rent Payment</h3>
                
                <div className="mb-4">
                  <p>
                    <span className="font-medium">Property:</span> 
                    {selectedRental.property.title}
                  </p>
                  <p>
                    <span className="font-medium">Monthly Rent:</span> 
                    {selectedRental.monthlyRent} ETH
                  </p>
                  {selectedRental.nextPaymentDue && (
                    <p>
                      <span className="font-medium">Next Payment Due:</span> 
                      {formatDate(selectedRental.nextPaymentDue)}
                    </p>
                  )}
                </div>
                
                <div className="p-3 mb-4 bg-yellow-50 text-yellow-700 rounded-md text-sm">
                  <p>You are about to submit a payment of {selectedRental.monthlyRent} ETH.</p>
                  <p>This transaction will be recorded on the blockchain.</p>
                </div>
                
                <div className="flex flex-col space-y-2 sm:flex-row sm:space-y-0 sm:space-x-2 justify-end">
                  <Button
                    variant="outline"
                    onClick={() => setSelectedRental(null)}
                    disabled={processingPayment}
                  >
                    Cancel
                  </Button>
                  <Button
                    variant="primary"
                    onClick={makePayment}
                    disabled={processingPayment}
                    isLoading={processingPayment}
                  >
                    Pay Now
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
  
  // Helper functions
  function formatDate(date: Date | string) {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }
  
  function handlePayRent(rental: Rental) {
    setSelectedRental(rental);
    setPaymentSuccess(false);
  }
  
  async function makePayment() {
    if (!selectedRental || !contract || !account) return;

    try {
      setProcessingPayment(true);
      setError(null);
      
      // Calculate payment amount (monthly rent in wei)
      const amountToSend = ethers.parseEther(selectedRental.monthlyRent.toString());
      
      // Call smart contract function to make payment
      const tx = await contract.payRent(selectedRental.requestId, {
        value: amountToSend
      });
      
      const receipt = await tx.wait();
      
      // Record payment transaction in blockchain-only implementation
      // Note: The current contract doesn't support payment history tracking
      // This is handled by the recordRentPayment stub in rentalRequestService
      await rentalRequestService.recordRentPayment(Number(selectedRental.requestId), {
        amount: selectedRental.monthlyRent,
        transactionHash: receipt.hash
      });
      
      setPaymentSuccess(true);
    } catch (err) {
      console.error('Error making rent payment:', err);
      setError('Failed to process payment. Please try again.');
    } finally {
      setProcessingPayment(false);
    }
  }
};

export default MyRentals;