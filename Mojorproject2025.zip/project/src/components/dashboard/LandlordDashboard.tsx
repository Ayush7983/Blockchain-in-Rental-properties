import { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom';
import { Building2, CircleDollarSign, AlertCircle, Users, ArrowUpRight, Eye } from 'lucide-react';
import Button from '../common/Button';
import { Web3Context, Web3ContextType } from '../../contexts/Web3Context';
import { propertyService } from '../../services/propertyService';
import { rentalRequestService } from '../../services/rentalRequestService';

interface ActivityItem {
  id: string;
  type: 'request' | 'payment';
  title: string;
  description: string;
  timestamp: Date;
  transactionHash?: string;
  link?: string;
}

const LandlordDashboard = () => {
  const { account, isConnected, isLandlord } = useContext<Web3ContextType>(Web3Context);
  const [stats, setStats] = useState({
    properties: 0,
    activeRentals: 0,
    pendingRequests: 0,
    totalEarnings: 0,
  });
  const [loading, setLoading] = useState(true);
  const [recentActivity, setRecentActivity] = useState<ActivityItem[]>([]);

  useEffect(() => {
    const fetchDashboardData = async () => {
      if (!account || !isConnected || !isLandlord) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        
        // Fetch properties owned by the landlord from blockchain
        const propertiesResponse = await propertyService.getAllProperties({ 
          landlord: account 
        });
        
        // Fetch rental requests for the landlord from blockchain
        const requestsResponse = await rentalRequestService.getAllRentalRequests({
          landlord: account
        });
        
        // Calculate stats from blockchain data
        const properties = propertiesResponse.success ? propertiesResponse.properties.length : 0;
        
        // Get active rentals (approved requests)
        const allRequests = requestsResponse.success ? requestsResponse.rentalRequests : [];
        const activeRentals = allRequests.filter(req => req.status === 'approved').length;
        const pendingRequests = allRequests.filter(req => req.status === 'pending').length;
        
        // Note: Payment history is not currently tracked in the blockchain
        // This would require contract extension to support payment recording
        // For now, we'll set totalEarnings to 0
        const totalEarningsInEth = 0;
        
        setStats({
          properties,
          activeRentals,
          pendingRequests,
          totalEarnings: totalEarningsInEth
        });
        
        // Generate recent activity items from blockchain events
        const activityItems: ActivityItem[] = [];
        
        // Add recent requests from blockchain data
        if (allRequests.length > 0) {
          const recentRequests = [...allRequests]
            .sort((a, b) => {
              // Safe timestamp comparison
              const timestampA = a.timestamp ? a.timestamp * 1000 : 0;
              const timestampB = b.timestamp ? b.timestamp * 1000 : 0;
              return timestampB - timestampA;
            })
            .slice(0, 3);
            
          recentRequests.forEach(request => {
            const propertyName = request.property ? request.property.name : 'Unknown Property';
            activityItems.push({
              id: request.id ? request.id.toString() : `req-${Date.now()}`,
              type: 'request',
              title: request.status === 'approved' ? 'Approved Request' : 'New Rental Request',
              description: `${request.tenant.substring(0, 6)}...${request.tenant.substring(38)} has requested to rent your ${propertyName}.`,
              timestamp: new Date(request.timestamp ? request.timestamp * 1000 : Date.now()), // Convert blockchain timestamp (seconds) to JS Date (milliseconds)
              link: '/dashboard/requests'
            });
          });
        }
        
        setRecentActivity(activityItems);
          
      } catch (err) {
        console.error('Error fetching blockchain dashboard data:', err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, [account, isConnected, isLandlord]);

  return (
    <>

        <div className="flex flex-wrap items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Landlord Dashboard</h1>
        <Link to="/dashboard/add-property">
          <Button variant="primary" size="sm">
            Add New Property
          </Button>
        </Link>
      </div>
      
        {/* Main Content */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 w-full">
        {/* Properties */}
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="bg-primary-100 p-3 rounded-lg">
              <Building2 className="h-6 w-6 text-primary-600" />
            </div>
            <ArrowUpRight className="h-5 w-5 text-success-500" />
          </div>
          <h3 className="text-gray-500 mb-1">Total Properties</h3>
          <div className="text-3xl font-bold text-gray-800">{stats.properties}</div>
          <Link to="/dashboard/properties" className="mt-4 text-sm text-primary-600 hover:text-primary-700 inline-flex items-center">
            View all
            <Eye className="ml-1 h-4 w-4" />
          </Link>
        </div>
        
        {/* Active Rentals */}
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="bg-success-100 p-3 rounded-lg">
              <Users className="h-6 w-6 text-success-600" />
            </div>
            <ArrowUpRight className="h-5 w-5 text-success-500" />
          </div>
          <h3 className="text-gray-500 mb-1">Active Rentals</h3>
          <div className="text-3xl font-bold text-gray-800">{stats.activeRentals}</div>
          <Link to="/dashboard/properties" className="mt-4 text-sm text-primary-600 hover:text-primary-700 inline-flex items-center">
            View details
            <Eye className="ml-1 h-4 w-4" />
          </Link>
        </div>
        
        {/* Pending Requests */}
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="bg-warning-100 p-3 rounded-lg">
              <AlertCircle className="h-6 w-6 text-warning-600" />
            </div>
            <ArrowUpRight className="h-5 w-5 text-success-500" />
          </div>
          <h3 className="text-gray-500 mb-1">Pending Requests</h3>
          <div className="text-3xl font-bold text-gray-800">{stats.pendingRequests}</div>
          <Link to="/dashboard/requests" className="mt-4 text-sm text-primary-600 hover:text-primary-700 inline-flex items-center">
            View requests
            <Eye className="ml-1 h-4 w-4" />
          </Link>
        </div>
        
        {/* Total Earnings */}
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="bg-accent-100 p-3 rounded-lg">
              <CircleDollarSign className="h-6 w-6 text-accent-600" />
            </div>
            <ArrowUpRight className="h-5 w-5 text-success-500" />
          </div>
          <h3 className="text-gray-500 mb-1">Total Earnings</h3>
          <div className="text-3xl font-bold text-gray-800">{stats.totalEarnings} ETH</div>
          <span className="mt-4 text-sm text-gray-500 inline-flex items-center">
            Last updated: Today
          </span>
        </div>
      </div>
      
      {/* Recent Activity */}
      <div className="bg-white rounded-xl p-6 md:p-8 shadow-sm mb-8">
        <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
        
        {loading ? (
          <div className="p-4 text-center text-gray-500">Loading activity...</div>
        ) : recentActivity.length === 0 ? (
          <div className="p-4 text-center text-gray-500">No recent activity</div>
        ) : (
          <div className="space-y-4">
            {recentActivity.map(activity => (
              <div 
                key={activity.id}
                className={`flex items-start p-4 border-l-4 ${activity.type === 'request' ? 'border-primary-500 bg-primary-50' : 'border-success-500 bg-success-50'} rounded-r-lg`}
              >
                <div className="bg-white p-2 rounded-full mr-4 shadow-sm">
                  {activity.type === 'request' ? (
                    <Users className="h-6 w-6 text-primary-600" />
                  ) : (
                    <CircleDollarSign className="h-6 w-6 text-success-600" />
                  )}
                </div>
                <div>
                  <h3 className="font-medium">{activity.title}</h3>
                  <p className="text-sm text-gray-600">{activity.description}</p>
                  <div className="mt-2">
                    {activity.link && (
                      <Link to={activity.link} className="text-sm text-primary-600 hover:text-primary-700">
                        View Details
                      </Link>
                    )}
                    {activity.transactionHash && (
                      <div className="text-sm text-gray-500">
                        Transaction ID: {activity.transactionHash.substring(0, 6)}...{activity.transactionHash.substring(activity.transactionHash.length - 4)}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Link to="/dashboard/add-property">
            <div className="p-4 border border-gray-200 rounded-lg hover:border-primary-500 hover:shadow-sm transition-all">
              <Building2 className="h-6 w-6 text-primary-600 mb-2" />
              <h3 className="font-medium">Add Property</h3>
              <p className="text-sm text-gray-500">List a new property</p>
            </div>
          </Link>
          
          <Link to="/dashboard/requests">
            <div className="p-4 border border-gray-200 rounded-lg hover:border-primary-500 hover:shadow-sm transition-all">
              <AlertCircle className="h-6 w-6 text-primary-600 mb-2" />
              <h3 className="font-medium">View Requests</h3>
              <p className="text-sm text-gray-500">Manage rental requests</p>
            </div>
          </Link>
          
          <Link to="/dashboard/properties">
            <div className="p-4 border border-gray-200 rounded-lg hover:border-primary-500 hover:shadow-sm transition-all">
              <Eye className="h-6 w-6 text-primary-600 mb-2" />
              <h3 className="font-medium">View Properties</h3>
              <p className="text-sm text-gray-500">Manage your properties</p>
            </div>
          </Link>
        </div>
      </div>
    </>
  );
};

export default LandlordDashboard;