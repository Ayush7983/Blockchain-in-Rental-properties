import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { PlusCircle, Pencil, Trash2, Eye } from 'lucide-react';
import Button from '../common/Button';
import { ethers } from 'ethers';

import { Property } from '../../services/propertyService';
import { rentalRequestService } from '../../services/rentalRequestService';
import web3Service from '../../services/web3Service';

// Define extended property type with UI-specific fields
interface ExtendedProperty extends Property {
  pricePerMonth?: number;
  price: number;
  rentalStatus?: string;
  tenantName?: string | null;
  images: Array<{ url: string; public_id?: string; }>;
}

const MyProperties = () => {
  const [properties, setProperties] = useState<ExtendedProperty[]>([]);
  // We no longer need to track rental requests at this level
  // as we're getting property status directly from the blockchain
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [processingId, setProcessingId] = useState<number | null>(null);
  
  // Handle updating property active status
  const handleUpdateActiveStatus = async (propertyId: number, isActive: boolean) => {
    try {
      setProcessingId(propertyId);
      setError(null);
      
      // Initialize web3Service if not already initialized
      await web3Service.initialize();
      
      // Call smart contract method to update active status
      console.log(`Toggling property ${propertyId} status to ${!isActive}`);
      await web3Service.togglePropertyStatus(propertyId);
      
      // Show success message
      setSuccessMessage(`Property listing ${!isActive ? 'activated' : 'deactivated'} successfully!`);
      
      // Update fetched property data to reflect the change from blockchain
      // Refresh properties from blockchain
      await fetchProperties();
      
      // Update local state regardless
      setProperties(prevProps => 
        prevProps.map(prop => 
          prop.id === propertyId 
            ? { ...prop, isActive } 
            : prop
        )
      );
      
      // Show success message
      setSuccessMessage(`Property listing ${isActive ? 'activated' : 'deactivated'} successfully!`);
      
      // Clear success message after 3 seconds
      setTimeout(() => setSuccessMessage(null), 3000);
      
    } catch (err) {
      console.error('Error updating property status:', err);
      setError('Failed to update property status. Please try again.');
      
      // Clear error message after 3 seconds
      setTimeout(() => setError(null), 3000);
    } finally {
      setProcessingId(null);
    }
  };

  // Function to fetch properties - defined outside useEffect so we can reuse it
  const fetchProperties = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Initialize web3Service
      await web3Service.initialize();
      
      // Get landlord's properties from blockchain
      const myProperties = await web3Service.getMyProperties();
      
      // Get all rental requests
      const requestsResponse = await rentalRequestService.getAllRentalRequests();
      const allRequests = requestsResponse.success ? requestsResponse.rentalRequests : [];
      // We'll use allRequests directly instead of storing in state
      
      // Transform properties to match UI format
      const formattedProperties = myProperties.map(prop => {
        // Convert price from Wei to ETH for display
        const priceInEth = prop.pricePerMonth ? parseFloat(ethers.formatEther(prop.pricePerMonth.toString())) : 0;
        
        return {
          ...prop,
          price: priceInEth,
          images: prop.imageURL ? [{ url: prop.imageURL }] : [],
          // Calculate rental status based on requests
          rentalStatus: calculateRentalStatus(prop.id, allRequests),
          // Get tenant name if rented
          tenantName: getTenantName(prop.id, allRequests)
        };
      });
      
      setProperties(formattedProperties);
    } catch (err) {
      console.error('Error fetching properties:', err);
      setError('Failed to load properties. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    // Fetch properties when component mounts
    fetchProperties();
  }, []);
  
  // Helper functions
  const calculateRentalStatus = (propertyId: number, requests: any[]) => {
    const propertyRequests = requests.filter(req => req.propertyId === propertyId);
    
    if (propertyRequests.some(req => req.status === 'approved')) {
      return 'Rented';
    } else if (propertyRequests.some(req => req.status === 'pending')) {
      return 'Pending Request';
    } else {
      return 'Available';
    }
  };
  
  const getTenantName = (propertyId: number, requests: any[]) => {
    const approvedRequest = requests.find(
      req => req.propertyId === propertyId && req.status === 'approved'
    );
    
    if (approvedRequest) {
      // Format tenant address to show as a shortened version
      const address = approvedRequest.tenant;
      return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
    }
    
    return null;
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-6 flex justify-center items-center min-h-[200px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-gray-200 border-t-primary-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your properties...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Success and Error messages */}
      {successMessage && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          <p>{successMessage}</p>
        </div>
      )}
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          <p>{error}</p>
        </div>
      )}
      
      <div className="flex justify-between items-center mb-6 w-full">
        <h1 className="text-2xl font-semibold">My Properties</h1>
        <Link to="/dashboard/add-property">
          <Button variant="primary" size="sm" className="flex items-center gap-2">
            <PlusCircle className="h-4 w-4" />
            Add Property
          </Button>
        </Link>
      </div>
      
      {properties.length > 0 ? (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Property
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Location
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Price
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Tenant
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {properties.map((property) => (
                  <tr key={property.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-10 w-10 flex-shrink-0">
                          <img className="h-10 w-10 rounded-md object-cover" src={property.images && property.images.length > 0 ? property.images[0].url : '/placeholder-property.jpg'} alt={property.name} />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{property.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{property.location}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{property.price} ETH/month</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={
                        property.rentalStatus === 'Available'
                          ? 'px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800'
                          : property.rentalStatus === 'Rented'
                            ? 'px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800'
                            : 'px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800'
                      }>
                        {property.rentalStatus}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {property.tenantName || '-'}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <Link to={`/dashboard/edit-property/${property.id}`} className="text-primary-600 hover:text-primary-900 mr-4 inline-block">
                        <Pencil className="h-5 w-5" />
                      </Link>
                      <button 
                        onClick={() => handleUpdateActiveStatus(property.id, !property.isActive)}
                        className="text-red-600 hover:text-red-900 mr-4"
                        disabled={processingId === property.id}
                        title={property.isActive ? 'Deactivate listing' : 'Reactivate listing'}
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                      <Link to={`/dashboard/properties/${property.id}`} className="text-gray-600 hover:text-gray-900">
                        <Eye className="h-5 w-5" />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm p-8 text-center">
          <div className="mb-4">
            <PlusCircle className="h-12 w-12 text-gray-400 mx-auto" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No properties listed yet</h3>
          <p className="text-gray-500 mb-6">Get started by adding your first property listing.</p>
          <Link to="/dashboard/add-property">
            <Button variant="primary">Add Your First Property</Button>
          </Link>
        </div>
      )}
    </>
  );
};

export default MyProperties;