import { useState, useEffect, useContext } from 'react';
import { Clock, Check, X, RefreshCw } from 'lucide-react';
import { Web3Context } from '../../contexts/Web3Context';
import { rentalRequestService } from '../../services/rentalRequestService';
import { propertyService } from '../../services/propertyService';
import Button from '../common/Button';

interface RequestProperty {
  _id: string;
  propertyId: string;
  title: string;
  images: string[];
  location: string;
  price: number;
}

interface RequestTenant {
  _id: string;
  address: string;
  name: string;
}

interface Request {
  _id: string;
  requestId: string;
  property: RequestProperty;
  tenant: RequestTenant;
  requestDate: string;
  duration: number;
  monthlyRent: number;
  status: 'pending' | 'approved' | 'rejected';
}

interface RentalRequestsResponse {
  success: boolean;
  rentalRequests: any[];
  error?: string;
}

const RentalRequests = () => {
  // Context for wallet and contract interaction
  const { account, contract, isLandlord } = useContext(Web3Context);
  
  // State management
  const [requests, setRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingIds, setProcessingIds] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Load properties and requests
  const loadRequests = async () => {
    if (!account || !isLandlord) {
      setError('Please connect your wallet as a landlord');
      setLoading(false);
      return;
    }
    
    try {
      setLoading(true);
      setError(null);
      setSuccessMessage(null);
      
      // Get landlord rental requests from the backend
      const response = await rentalRequestService.getAllRentalRequests({
        landlord: account
      }) as RentalRequestsResponse;
      
      if (!response.success) {
        throw new Error(response.error || 'Failed to fetch rental requests');
      }
      
      // Transform the data into our component format
      const transformedRequests = await Promise.all(response.rentalRequests.map(async (req: any) => {
        // Fetch property details if not fully populated
        let property = req.property;
        let propertyData: RequestProperty;
        
        if (!property || typeof property === 'string') {
          const propertyResponse = await propertyService.getPropertyById(req.propertyId || '');
          if (propertyResponse.success) {
            const p = propertyResponse.property;
            propertyData = {
              _id: p._id || '',
              propertyId: p.propertyId || '',
              title: p.title || 'Unknown Property',
              images: p.images?.map((img: any) => img.url) || [],
              location: p.location || 'Unknown',
              price: p.price || 0
            };
          } else {
            propertyData = {
              _id: req.propertyId || '',
              propertyId: '',
              title: 'Unknown Property',
              images: [],
              location: 'Unknown',
              price: 0
            };
          }
        } else if (typeof property === 'object') {
          // If it's already an object, transform it to our expected format
          const p = property as any;
          propertyData = {
            _id: p._id || '',
            propertyId: p.propertyId || '',
            title: p.title || 'Unknown Property',
            images: Array.isArray(p.images) ? 
              (p.images[0]?.url ? p.images.map((img: any) => img.url) : p.images) : 
              [],
            location: p.location || 'Unknown',
            price: p.price || 0
          };
        } else {
          // Fallback
          propertyData = {
            _id: req.propertyId || '',
            propertyId: '',
            title: 'Unknown Property',
            images: [],
            location: 'Unknown',
            price: 0
          };
        }
        
        // Fetch tenant details if not fully populated
        let tenant = req.tenant;
        let tenantData: RequestTenant;
        
        if (!tenant || typeof tenant === 'string') {
          const tenantAddress = typeof tenant === 'string' ? tenant : (req.tenant as string);
          tenantData = {
            _id: '',
            address: tenantAddress,
            name: `Tenant ${tenantAddress.substring(0, 6)}...`
          };
        } else {
          // If it's already an object
          const t = tenant as any;
          tenantData = {
            _id: t._id || '',
            address: t.address || '',
            name: t.name || `Tenant ${t.address?.substring(0, 6) || ''}...`
          };
        }
        
        return {
          _id: req._id || '',
          requestId: req.requestId,
          property: propertyData,
          tenant: tenantData,
          requestDate: new Date(req.requestDate).toISOString().split('T')[0],
          duration: req.duration,
          monthlyRent: req.monthlyRent,
          status: req.status
        };
      }));
      
      setRequests(transformedRequests);
    } catch (error: any) {
      console.error('Error loading rental requests:', error);
      setError(error.message || 'Failed to load rental requests');
    } finally {
      setLoading(false);
    }
  };
  
  // Load data on component mount
  useEffect(() => {
    if (account && isLandlord) {
      loadRequests();
    }
  }, [account, isLandlord]);
  
  // Smart contract and blockchain interaction
  const handleApprove = async (requestId: string, propertyId: string) => {
    if (!account || !contract) {
      setError('Wallet connection required');
      return;
    }

    // Add to processing IDs to show loading state
    setProcessingIds(prev => [...prev, requestId]);
    setError(null);
    setSuccessMessage(null);

    try {
      // First, update on blockchain
      const tx = await contract.approveRentalRequest(requestId, propertyId);
      await tx.wait();
      
      // Then update in backend
      await rentalRequestService.updateRentalRequestStatus(requestId, 'approved');
      
      // Update local state
      setRequests(prev => prev.map(req => 
        req.requestId === requestId
          ? { ...req, status: 'approved' }
          : req
      ));

      // Show success message
      setSuccessMessage('Rental request approved successfully!');
    } catch (error: any) {
      console.error('Error approving rental request:', error);
      setError('Failed to approve rental request. Please try again.');
    } finally {
      // Remove from processing
      setProcessingIds(prev => prev.filter(id => id !== requestId));
    }
  };

  // Smart contract and blockchain interaction
  const handleReject = async (requestId: string, propertyId: string) => {
    if (!account || !contract) {
      setError('Wallet connection required');
      return;
    }

    // Add to processing IDs
    setProcessingIds(prev => [...prev, requestId]);
    setError(null);
    setSuccessMessage(null);

    try {
      // First, update on blockchain
      const tx = await contract.rejectRentalRequest(requestId, propertyId);
      await tx.wait();
      
      // Then update in backend
      await rentalRequestService.updateRentalRequestStatus(requestId, 'rejected');
      
      // Update local state
      setRequests(prev => prev.map(req => 
        req.requestId === requestId
          ? { ...req, status: 'rejected' }
          : req
      ));

      // Show success message
      setSuccessMessage('Rental request rejected successfully!');
    } catch (error: any) {
      console.error('Error rejecting rental request:', error);
      setError('Failed to reject rental request. Please try again.');
    } finally {
      // Remove from processing
      setProcessingIds(prev => prev.filter(id => id !== requestId));
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Rental Requests</h2>
        <Button onClick={loadRequests} variant="outline" size="sm">
          <RefreshCw className="mr-2 h-4 w-4" />
          Refresh
        </Button>
      </div>
      
      {/* Success message */}
      {successMessage && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          <p>{successMessage}</p>
        </div>
      )}
      
      {/* Error message */}
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          <p>{error}</p>
        </div>
      )}
      
      {/* Loading indicator */}
      {loading ? (
        <div className="flex justify-center items-center py-20">
          <RefreshCw className="animate-spin h-8 w-8 text-gray-500" />
        </div>
      ) : requests.length === 0 ? (
        <div className="text-center py-20 text-gray-500">
          <p>No rental requests found.</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200 rounded-lg">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Property</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tenant</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Duration</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Monthly Rent</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {requests.map((request) => (
                <tr key={request._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      {request.property.images && request.property.images[0] ? (
                        <img
                          src={request.property.images[0]}
                          alt={request.property.title}
                          className="h-10 w-10 rounded-md object-cover mr-3"
                        />
                      ) : (
                        <div className="h-10 w-10 rounded-md bg-gray-200 mr-3" />
                      )}
                      <div>
                        <div className="font-medium text-gray-900">{request.property.title}</div>
                        <div className="text-gray-500 text-sm">{request.property.location}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">{request.tenant.name}</div>
                    <div className="text-gray-500 text-xs">{request.tenant.address}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">{request.requestDate}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">{request.duration} months</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">${request.monthlyRent}/month</div>
                  </td>
                  <td className="px-6 py-4">
                    {request.status === 'pending' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                        <Clock className="mr-1 h-3 w-3" /> Pending
                      </span>
                    )}
                    {request.status === 'approved' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        <Check className="mr-1 h-3 w-3" /> Approved
                      </span>
                    )}
                    {request.status === 'rejected' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                        <X className="mr-1 h-3 w-3" /> Rejected
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    {request.status === 'pending' && (
                      <div className="flex space-x-2">
                        <Button
                          onClick={() => handleApprove(request.requestId, request.property.propertyId)}
                          disabled={processingIds.includes(request.requestId)}
                          variant="primary"
                          size="sm"
                        >
                          {processingIds.includes(request.requestId) ? (
                            <RefreshCw className="mr-2 h-3 w-3 animate-spin" />
                          ) : (
                            <Check className="mr-2 h-3 w-3" />
                          )}
                          Approve
                        </Button>
                        <Button
                          onClick={() => handleReject(request.requestId, request.property.propertyId)}
                          disabled={processingIds.includes(request.requestId)}
                          variant="secondary"
                          size="sm"
                        >
                          {processingIds.includes(request.requestId) ? (
                            <RefreshCw className="mr-2 h-3 w-3 animate-spin" />
                          ) : (
                            <X className="mr-2 h-3 w-3" />
                          )}
                          Reject
                        </Button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default RentalRequests;
