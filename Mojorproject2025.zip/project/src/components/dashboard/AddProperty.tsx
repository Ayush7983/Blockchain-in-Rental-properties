import React, { useState, useCallback } from 'react';
import { ethers } from 'ethers';
import { Web3Context } from '../../contexts';
import { Building2, MapPin, DollarSign, FileImage, Plus, Minus, X } from 'lucide-react';
import { uploadImage } from '../../services/api';
import Button from '../common/Button';
// No need to import propertyService as we're only using blockchain

const AddProperty = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    location: '',
    pricePerMonth: 0.1,
    bedrooms: 1,
    bathrooms: 1,
    area: 50,
    imageUrl: '',
    amenities: [''] 
  });
  
  // State for drag-and-drop image upload
  const [isDragging, setIsDragging] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [imagePreview, setImagePreview] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');

  // Handle form field changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle image file selection
  const handleImageSelect = (file: File) => {
    if (!file.type.includes('image/')) {
      setUploadError('Please select a valid image file');
      return;
    }
    
    setImageFile(file);
    setUploadError('');
    
    // Create preview
    const reader = new FileReader();
    reader.onload = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
    
    // Upload to Cloudinary
    handleImageUpload(file);
  };
  
  // Handle image upload to Cloudinary
  const handleImageUpload = async (file: File) => {
    setUploading(true);
    setUploadProgress(10); // Start progress indication
    
    try {
      // Simulate progress (actual upload doesn't provide progress)
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) clearInterval(progressInterval);
          return Math.min(prev + 10, 90);
        });
      }, 300);
      
      // Upload to Cloudinary using our API service
      const result = await uploadImage(file);
      clearInterval(progressInterval);
      
      // Set the URL to our form data
      setFormData(prev => ({
        ...prev,
        imageUrl: result.url
      }));
      
      // Complete progress bar
      setUploadProgress(100);
      setTimeout(() => setUploading(false), 500);
      
    } catch (error) {
      console.error('Image upload failed:', error);
      setUploadError('Failed to upload image. Please try again.');
      setUploading(false);
    }
  };
  
  // Handle removing the uploaded image
  const handleRemoveImage = () => {
    setImagePreview('');
    setImageFile(null);
    setFormData(prev => ({
      ...prev,
      imageUrl: ''
    }));
  };

  const handleAmenityChange = (index: number, value: string) => {
    const updatedAmenities = [...formData.amenities];
    updatedAmenities[index] = value;
    setFormData(prev => ({
      ...prev,
      amenities: updatedAmenities
    }));
  };

  const addAmenity = () => {
    setFormData(prev => ({
      ...prev,
      amenities: [...prev.amenities, '']
    }));
  };

  const removeAmenity = (index: number) => {
    const updatedAmenities = formData.amenities.filter((_, i) => i !== index);
    setFormData(prev => ({
      ...prev,
      amenities: updatedAmenities
    }));
  };

  // Import Web3Context
  const { account, contract } = React.useContext(Web3Context);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    if (!contract || !account) {
      alert('Wallet not connected or contract not initialized. Please connect your wallet.');
      setIsSubmitting(false);
      return;
    }
    
    try {
      // Create property metadata combining the basic data with amenities/features
      const propertyDescription = `${formData.description}\n\nFeatures:\n- ${formData.bedrooms} bedrooms\n- ${formData.bathrooms} bathrooms\n- ${formData.area} sq m\n${formData.amenities.filter(a => a.trim()).map(a => `- ${a}`).join('\n')}`;
      
      // Convert ETH price to Wei (smallest unit in Ethereum)
      const priceInWei = ethers.parseEther(formData.pricePerMonth.toString());
      
      console.log('Adding property to blockchain...');
      const tx = await contract.addProperty(
        formData.title,
        propertyDescription,
        formData.location,
        priceInWei,
        formData.imageUrl || 'https://images.pexels.com/photos/1918291/pexels-photo-1918291.jpeg' // Default image if none provided
      );
      
      console.log('Transaction sent:', tx.hash);
      console.log('Waiting for confirmation...');
      
      // Wait for transaction confirmation
      await tx.wait();
      console.log('Transaction confirmed');
      
      // Property successfully added to blockchain
      alert('Property added successfully to blockchain!');
      
      // Log the successful addition for tracking
      console.log('Property added to blockchain with transaction hash:', tx.hash);
      
      // Reset form
      setFormData({
        title: '',
        description: '',
        location: '',
        pricePerMonth: 0.1,
        bedrooms: 1,
        bathrooms: 1,
        area: 50,
        imageUrl: '',
        amenities: ['']
      });
    } catch (error: any) {
      console.error('Error adding property:', error);
      alert(`Failed to add property: ${error.message || 'Unknown error'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Add New Property</h1>
        <p className="text-gray-600">List your property on the blockchain for tenants to discover</p>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm p-6">
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 gap-6">
            {/* Basic Information */}
            <div>
              <h2 className="text-lg font-semibold mb-4">Basic Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                    Property Title
                  </label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                    <input
                      type="text"
                      id="title"
                      name="title"
                      value={formData.title}
                      onChange={handleChange}
                      className="pl-10 w-full border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      placeholder="e.g. Modern Apartment in Downtown"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                    Location
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                    <input
                      type="text"
                      id="location"
                      name="location"
                      value={formData.location}
                      onChange={handleChange}
                      className="pl-10 w-full border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      placeholder="e.g. New York, NY"
                      required
                    />
                  </div>
                </div>
              </div>
              
              <div className="mt-4">
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  rows={4}
                  className="w-full border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="Describe your property..."
                  required
                />
              </div>
            </div>
            
            {/* Property Details */}
            <div>
              <h2 className="text-lg font-semibold mb-4">Property Details</h2>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div>
                  <label htmlFor="pricePerMonth" className="block text-sm font-medium text-gray-700 mb-1">
                    Price per Month (ETH)
                  </label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                    <input
                      type="number"
                      id="pricePerMonth"
                      name="pricePerMonth"
                      value={formData.pricePerMonth}
                      onChange={handleChange}
                      min="0.01"
                      step="0.01"
                      className="pl-10 w-full border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="bedrooms" className="block text-sm font-medium text-gray-700 mb-1">
                    Bedrooms
                  </label>
                  <select
                    id="bedrooms"
                    name="bedrooms"
                    value={formData.bedrooms}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  >
                    {[1, 2, 3, 4, 5].map(num => (
                      <option key={num} value={num}>{num}</option>
                    ))}
                    <option value="6">6+</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="bathrooms" className="block text-sm font-medium text-gray-700 mb-1">
                    Bathrooms
                  </label>
                  <select
                    id="bathrooms"
                    name="bathrooms"
                    value={formData.bathrooms}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  >
                    {[1, 2, 3, 4].map(num => (
                      <option key={num} value={num}>{num}</option>
                    ))}
                    <option value="5">5+</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="area" className="block text-sm font-medium text-gray-700 mb-1">
                    Area (m²)
                  </label>
                  <input
                    type="number"
                    id="area"
                    name="area"
                    value={formData.area}
                    onChange={handleChange}
                    min="1"
                    className="w-full border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    required
                  />
                </div>
              </div>
            </div>
            
            {/* Image Upload with Drag and Drop */}
            <div>
              <h2 className="text-lg font-semibold mb-4">Property Image</h2>
              
              {/* Drag and drop area */}
              <div
                className={`border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center transition-colors ${
                  isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
                } ${
                  uploadError ? 'border-red-500 bg-red-50' : ''
                }`}
                onDragOver={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setIsDragging(true);
                }}
                onDragEnter={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setIsDragging(true);
                }}
                onDragLeave={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setIsDragging(false);
                }}
                onDrop={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setIsDragging(false);
                  
                  if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                    handleImageSelect(e.dataTransfer.files[0]);
                  }
                }}
              >
                {!imagePreview && !uploading && (
                  <>
                    <FileImage className="h-12 w-12 text-gray-400 mb-3" />
                    <p className="text-gray-500 text-center mb-2">
                      Drag and drop your property image here or
                    </p>
                    <label htmlFor="file-upload" className="bg-blue-600 text-white px-4 py-2 rounded-md cursor-pointer hover:bg-blue-700 transition-colors">
                      Browse files
                    </label>
                    <input
                      id="file-upload"
                      name="file-upload"
                      type="file"
                      className="sr-only"
                      accept="image/*"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          handleImageSelect(e.target.files[0]);
                        }
                      }}
                    />
                  </>
                )}
                
                {uploading && (
                  <div className="w-full">
                    <p className="text-center mb-2">Uploading...</p>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div
                        className="bg-blue-600 h-2.5 rounded-full"
                        style={{ width: `${uploadProgress}%` }}
                      ></div>
                    </div>
                  </div>
                )}
                
                {imagePreview && !uploading && (
                  <div className="relative w-full">
                    <img
                      src={imagePreview}
                      alt="Property preview"
                      className="w-full h-48 object-cover rounded-md"
                    />
                    <button
                      type="button"
                      onClick={handleRemoveImage}
                      className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                )}
                
                {uploadError && (
                  <p className="mt-2 text-red-500 text-sm">{uploadError}</p>
                )}
              </div>
              
              {/* Manual URL input as fallback */}
              <div className="mt-4">
                <label htmlFor="imageUrl" className="block text-sm font-medium text-gray-700 mb-1">
                  or Enter Image URL
                </label>
                <div className="relative">
                  <FileImage className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="url"
                    id="imageUrl"
                    name="imageUrl"
                    value={formData.imageUrl}
                    onChange={handleChange}
                    className="pl-10 w-full border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="https://example.com/image.jpg"
                  />
                </div>
              </div>
            </div>
            
            {/* Amenities */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold">Amenities</h2>
                <button
                  type="button"
                  onClick={addAmenity}
                  className="flex items-center text-primary-600 hover:text-primary-700"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  <span>Add Amenity</span>
                </button>
              </div>
              
              <div className="space-y-3">
                {formData.amenities.map((amenity, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={amenity}
                      onChange={(e) => handleAmenityChange(index, e.target.value)}
                      className="flex-1 border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      placeholder="e.g. Air Conditioning, Wi-Fi, etc."
                    />
                    {formData.amenities.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeAmenity(index)}
                        className="p-2 text-red-500 hover:text-red-700"
                      >
                        <Minus className="h-5 w-5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            {/* Submit Button */}
            <div className="border-t pt-6 flex justify-end">
              <Button
                type="submit"
                variant="primary"
                size="lg"
                isLoading={isSubmitting}
              >
                {isSubmitting ? 'Adding Property...' : 'Add Property'}
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddProperty;