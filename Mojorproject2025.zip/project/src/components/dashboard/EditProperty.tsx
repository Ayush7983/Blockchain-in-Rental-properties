import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ethers } from 'ethers';
import { Building2, MapPin, DollarSign, FileImage, Plus, Minus, X } from 'lucide-react';
import Button from '../common/Button';
import { uploadImage } from '../../services/api';
import web3Service from '../../services/web3Service';

interface FormData {
  title: string;
  description: string;
  location: string;
  pricePerMonth: number;
  bedrooms: number;
  bathrooms: number;
  area: number;
  imageUrl: string;
  amenities: string[];
}

const EditProperty = () => {
  const { id } = useParams<{ id: string }>();
  const propertyId = id ? parseInt(id) : 0;
  const navigate = useNavigate();
  
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    title: '',
    description: '',
    location: '',
    pricePerMonth: 0.1,
    bedrooms: 1,
    bathrooms: 1,
    area: 50,
    imageUrl: '',
    amenities: ['']
  });
  
  // State for drag-and-drop image upload
  const [isDragging, setIsDragging] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [imagePreview, setImagePreview] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [error, setError] = useState<string | null>(null);
  
  // Fetch existing property data when component mounts
  useEffect(() => {
    const fetchPropertyDetails = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // Initialize web3Service
        await web3Service.initialize();
        
        // Fetch property details
        const property = await web3Service.getProperty(propertyId);
        
        // Extract amenities from description if they exist
        const amenities: string[] = [''];
        const descriptionParts = property.description.split('Features:');
        let cleanDescription = property.description;
        
        if (descriptionParts.length > 1) {
          cleanDescription = descriptionParts[0].trim();
          const featuresList = descriptionParts[1].trim().split('\n');
          
          // Filter out bedroom, bathroom, and area features as we'll handle those separately
          const filteredAmenities = featuresList
            .map(feature => feature.replace('- ', '').trim())
            .filter(feature => 
              !feature.includes('bedroom') && 
              !feature.includes('bathroom') && 
              !feature.includes('sq m')
            );
          
          if (filteredAmenities.length > 0) {
            amenities.splice(0, 1, ...filteredAmenities);
          }
        }
        
        // Set form data with existing property details
        setFormData({
          title: property.name,
          description: cleanDescription,
          location: property.location,
          pricePerMonth: Number(ethers.formatEther(property.pricePerMonth.toString())),
          bedrooms: property.bedrooms || 1,
          bathrooms: property.bathrooms || 1,
          area: property.area || 50,
          imageUrl: property.imageURL || '',
          amenities
        });
        
        // Set image preview if available
        if (property.imageURL) {
          setImagePreview(property.imageURL);
        }
        
      } catch (err) {
        console.error('Error fetching property details:', err);
        setError('Failed to load property details. Please try again.');
      } finally {
        setIsLoading(false);
      }
    };
    
    if (propertyId) {
      fetchPropertyDetails();
    }
  }, [propertyId]);

  // Handle form field changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle number input changes with validation
  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const numVal = parseFloat(value);
    
    // Validate number inputs
    if (!isNaN(numVal)) {
      setFormData(prev => ({
        ...prev,
        [name]: numVal
      }));
    }
  };

  // Handle image file drop
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleImageSelect(e.dataTransfer.files[0]);
    }
  };

  // Handle image file selection
  const handleImageSelect = (file: File) => {
    if (!file.type.includes('image/')) {
      setUploadError('Please select a valid image file');
      return;
    }
    
    setImageFile(file);
    setUploadError('');
    
    // Create preview
    const reader = new FileReader();
    reader.onload = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
    
    // Upload to Cloudinary
    handleImageUpload(file);
  };
  
  // Handle file input change
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleImageSelect(e.target.files[0]);
    }
  };
  
  // Handle image upload to Cloudinary
  const handleImageUpload = async (file: File) => {
    setUploading(true);
    setUploadProgress(10); // Start progress indication
    
    try {
      // Simulate progress (actual upload doesn't provide progress)
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) clearInterval(progressInterval);
          return Math.min(prev + 10, 90);
        });
      }, 300);
      
      // Upload to Cloudinary using our API service
      const result = await uploadImage(file);
      clearInterval(progressInterval);
      
      // Set the URL to our form data
      setFormData(prev => ({
        ...prev,
        imageUrl: result.url
      }));
      
      // Complete progress bar
      setUploadProgress(100);
      setTimeout(() => setUploading(false), 500);
      
    } catch (error) {
      console.error('Image upload failed:', error);
      setUploadError('Failed to upload image. Please try again.');
      setUploading(false);
    }
  };
  
  // Handle removing the uploaded image
  const handleRemoveImage = () => {
    setImagePreview('');
    setImageFile(null);
    setFormData(prev => ({
      ...prev,
      imageUrl: ''
    }));
  };

  // Amenity management
  const handleAmenityChange = (index: number, value: string) => {
    const updatedAmenities = [...formData.amenities];
    updatedAmenities[index] = value;
    setFormData(prev => ({
      ...prev,
      amenities: updatedAmenities
    }));
  };

  const addAmenity = () => {
    setFormData(prev => ({
      ...prev,
      amenities: [...prev.amenities, '']
    }));
  };

  const removeAmenity = (index: number) => {
    const updatedAmenities = formData.amenities.filter((_, i) => i !== index);
    setFormData(prev => ({
      ...prev,
      amenities: updatedAmenities
    }));
  };

  // Form submission handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);
    
    try {
      // Initialize web3Service if not already initialized
      await web3Service.initialize();
      
      // Create property metadata combining the basic data with amenities/features
      const propertyDescription = `${formData.description}\n\nFeatures:\n- ${formData.bedrooms} bedrooms\n- ${formData.bathrooms} bathrooms\n- ${formData.area} sq m\n${formData.amenities.filter(a => a.trim()).map(a => `- ${a}`).join('\n')}`;
      
      // Convert ETH price to Wei (smallest unit in Ethereum)
      const priceInWei = ethers.parseEther(formData.pricePerMonth.toString());
      const priceInWeiNumber = Number(priceInWei);
      
      console.log('Updating property on blockchain...');
      await web3Service.updateProperty(
        propertyId,
        formData.title,
        propertyDescription,
        formData.location,
        priceInWeiNumber,
        formData.imageUrl || 'https://images.pexels.com/photos/1918291/pexels-photo-1918291.jpeg', // Default image if none provided
        formData.bedrooms,
        formData.bathrooms,
        formData.area
      );
      
      console.log('Property updated successfully');
      
      // Redirect back to properties list with success message
      navigate('/dashboard/properties', { state: { successMessage: 'Property updated successfully!' } });
      
    } catch (error: any) {
      console.error('Error updating property:', error);
      setError(`Failed to update property: ${error.message || 'Unknown error'}`);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (isLoading) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-6 flex justify-center items-center min-h-[400px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-gray-200 border-t-primary-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading property details...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Edit Property</h1>
        <p className="text-gray-600">Update your property details on the blockchain</p>
      </div>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          <p>{error}</p>
        </div>
      )}
      
      <div className="bg-white rounded-xl shadow-sm p-6">
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 gap-6">
            {/* Property Title */}
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                Property Title
              </label>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Building2 className="h-5 w-5 text-gray-400" aria-hidden="true" />
                </div>
                <input
                  type="text"
                  name="title"
                  id="title"
                  value={formData.title}
                  onChange={handleChange}
                  className="focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                  placeholder="Luxury Apartment"
                  required
                />
              </div>
            </div>
            
            {/* Location */}
            <div>
              <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                Location
              </label>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <MapPin className="h-5 w-5 text-gray-400" aria-hidden="true" />
                </div>
                <input
                  type="text"
                  name="location"
                  id="location"
                  value={formData.location}
                  onChange={handleChange}
                  className="focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                  placeholder="123 Main St, City, State"
                  required
                />
              </div>
            </div>
            
            {/* Price */}
            <div>
              <label htmlFor="pricePerMonth" className="block text-sm font-medium text-gray-700 mb-1">
                Monthly Rent (ETH)
              </label>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <DollarSign className="h-5 w-5 text-gray-400" aria-hidden="true" />
                </div>
                <input
                  type="number"
                  name="pricePerMonth"
                  id="pricePerMonth"
                  value={formData.pricePerMonth}
                  onChange={handleNumberChange}
                  min="0.001"
                  step="0.001"
                  className="focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                  placeholder="0.1"
                  required
                />
              </div>
              <p className="mt-1 text-sm text-gray-500">Price in ETH per month</p>
            </div>
            
            {/* Property Features */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Bedrooms */}
              <div>
                <label htmlFor="bedrooms" className="block text-sm font-medium text-gray-700 mb-1">
                  Bedrooms
                </label>
                <input
                  type="number"
                  name="bedrooms"
                  id="bedrooms"
                  value={formData.bedrooms}
                  onChange={handleNumberChange}
                  min="0"
                  max="20"
                  className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  required
                />
              </div>
              
              {/* Bathrooms */}
              <div>
                <label htmlFor="bathrooms" className="block text-sm font-medium text-gray-700 mb-1">
                  Bathrooms
                </label>
                <input
                  type="number"
                  name="bathrooms"
                  id="bathrooms"
                  value={formData.bathrooms}
                  onChange={handleNumberChange}
                  min="0"
                  max="10"
                  step="0.5"
                  className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  required
                />
              </div>
              
              {/* Area */}
              <div>
                <label htmlFor="area" className="block text-sm font-medium text-gray-700 mb-1">
                  Area (sq m)
                </label>
                <input
                  type="number"
                  name="area"
                  id="area"
                  value={formData.area}
                  onChange={handleNumberChange}
                  min="0"
                  className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  required
                />
              </div>
            </div>
            
            {/* Description */}
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                id="description"
                name="description"
                rows={4}
                value={formData.description}
                onChange={handleChange}
                className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                placeholder="Describe your property..."
                required
              ></textarea>
            </div>
            
            {/* Image Upload */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Property Image</label>
              
              {!imagePreview ? (
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className={`mt-1 border-2 border-dashed rounded-md px-6 pt-5 pb-6 flex justify-center items-center ${isDragging ? 'border-primary-500 bg-primary-50' : 'border-gray-300'}`}
                >
                  <div className="space-y-1 text-center">
                    <FileImage className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600">
                      <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-primary-600 hover:text-primary-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary-500">
                        <span>Upload a file</span>
                        <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/*" />
                      </label>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
                  </div>
                </div>
              ) : (
                <div className="mt-1 relative rounded-md">
                  <div className="relative">
                    <img src={imagePreview} alt="Property preview" className="h-48 w-full object-cover rounded-md" />
                    
                    {uploading ? (
                      <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-md">
                        <div className="text-white text-center">
                          <div className="mb-2">Uploading... {uploadProgress}%</div>
                          <div className="w-48 h-2 bg-gray-300 rounded-full overflow-hidden">
                            <div className="h-full bg-primary-500 rounded-full" style={{ width: `${uploadProgress}%` }}></div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={handleRemoveImage}
                        className="absolute top-2 right-2 bg-red-600 text-white rounded-full p-1 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>
              )}
              
              {uploadError && (
                <p className="mt-1 text-sm text-red-600">{uploadError}</p>
              )}
            </div>
            
            {/* Amenities */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-sm font-medium text-gray-700">Amenities</label>
                <button 
                  type="button" 
                  onClick={addAmenity}
                  className="inline-flex items-center text-sm text-primary-600 hover:text-primary-700"
                >
                  <Plus className="h-4 w-4 mr-1" /> Add amenity
                </button>
              </div>
              
              {formData.amenities.map((amenity, index) => (
                <div key={index} className="flex items-center mt-2">
                  <input
                    type="text"
                    value={amenity}
                    onChange={(e) => handleAmenityChange(index, e.target.value)}
                    placeholder="e.g., Swimming pool, Gym, etc."
                    className="flex-1 focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  />
                  {formData.amenities.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeAmenity(index)}
                      className="ml-2 text-red-500 hover:text-red-700"
                    >
                      <Minus className="h-5 w-5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
            
            {/* Submit Button */}
            <div className="pt-4">
              <Button 
                type="submit" 
                variant="primary" 
                fullWidth 
                disabled={isSubmitting || uploading}
              >
                {isSubmitting ? 'Updating Property...' : 'Update Property'}
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
