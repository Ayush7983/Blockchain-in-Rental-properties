import { useState, useEffect, useContext } from 'react';
import { Web3Context } from '../../contexts';
import { RentalRequest, rentalRequestService } from '../../services/rentalRequestService';
import web3Service from '../../services/web3Service';
import { ethers } from 'ethers';

const TenantRentalRequests = () => {
  const [rentalRequests, setRentalRequests] = useState<RentalRequest[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedRequest, setSelectedRequest] = useState<RentalRequest | null>(null);
  const [processingPayment, setProcessingPayment] = useState<boolean>(false);
  const [paymentSuccess, setPaymentSuccess] = useState<boolean>(false);

  const { account, contract, isConnected, isTenant } = useContext(Web3Context);

  useEffect(() => {
    const fetchRentalRequests = async () => {
      try {
        setLoading(true);
        if (!account) return;
        
        try {
          const response = await rentalRequestService.getAllRentalRequests({
            tenant: account
          });
          
          if (response.success) {
            setRentalRequests(response.rentalRequests);
          } else {
            // If API returns an error but it's just that no requests exist yet
            console.log('No rental requests found or other API error');
            setRentalRequests([]);
          }
        } catch (apiErr) {
          console.warn('API error when fetching rental requests:', apiErr);
          // Gracefully handle API errors by showing empty state
          setRentalRequests([]);
        }
      } catch (err) {
        console.error('Error in rental requests effect:', err);
        // Don't show error to user for empty data
        setRentalRequests([]);
      } finally {
        setLoading(false);
      }
    };

    if (isConnected && isTenant) {
      fetchRentalRequests();
    } else {
      setLoading(false); // Make sure we're not stuck in loading state
    }
  }, [isConnected, isTenant, account]);

  const openPaymentModal = (request: RentalRequest) => {
    setSelectedRequest(request);
    setPaymentSuccess(false);
  };

  const closePaymentModal = () => {
    setSelectedRequest(null);
    setProcessingPayment(false);
    setPaymentSuccess(false);
  };

  const makePayment = async () => {
    if (!selectedRequest || !contract || !account) return;

    try {
      setProcessingPayment(true);
      
      // Get property details to find the monthly rent
      const property = await web3Service.getProperty(selectedRequest.propertyId);
      
      // Calculate payment amount (monthly rent in wei)
      const amountToSend = ethers.parseEther(property.pricePerMonth.toString());
      
      // Call our payment function in web3Service
      const paymentResult = await web3Service.makePayment(Number(selectedRequest.id), amountToSend);
      
      // Check if payment was successful
      if (!paymentResult.success) {
        throw new Error(paymentResult.error || 'Payment failed');
      }
      
      // Record payment transaction details (blockchain-only implementation)
      // Note: The current contract doesn't support payment history
      // This is handled by the recordRentPayment stub in rentalRequestService
      await rentalRequestService.recordRentPayment(Number(selectedRequest.id), {
        amount: property.pricePerMonth,
        transactionHash: paymentResult.transactionHash || 'transaction-completed'
      });
      
      console.log('Payment successful using method:', paymentResult.method);
      
      // Refresh rental requests
      const response = await rentalRequestService.getAllRentalRequests({
        tenant: account
      });
      
      if (response.success) {
        setRentalRequests(response.rentalRequests);
      }
      
      setPaymentSuccess(true);
    } catch (err) {
      console.error('Error making rent payment:', err);
      setError('Failed to process payment. Please try again.');
    } finally {
      setProcessingPayment(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-md text-xs font-medium">Pending</span>;
      case 'approved':
        return <span className="px-2 py-1 bg-green-100 text-green-800 rounded-md text-xs font-medium">Approved</span>;
      case 'rejected':
        return <span className="px-2 py-1 bg-red-100 text-red-800 rounded-md text-xs font-medium">Rejected</span>;
      default:
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-md text-xs font-medium">{status}</span>;
    }
  };
  
  // Format timestamp (blockchain timestamps are in seconds since epoch)
  const formatDate = (timestamp: number) => {
    if (!timestamp) return 'Not specified';
    const date = new Date(timestamp * 1000);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="text-lg">Loading your rental requests...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-600">
        {error}
      </div>
    );
  }

  if (!isTenant) {
    return (
      <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-md text-yellow-700">
        You need to register as a tenant to view your rental requests.
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-6">My Rental Requests</h2>
      
      {rentalRequests.length === 0 ? (
        <div className="p-4 bg-gray-50 rounded-md">You haven't submitted any rental requests yet.</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Property
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Rent
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Duration
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {rentalRequests.map((request) => (
                <tr key={request.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="alert alert-info">
                      <h6>Property #{request.propertyId}</h6>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    ${request.monthlyRent}/month
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <p className="card-text">Duration: {request.durationMonths} {request.durationMonths === 1 ? 'month' : 'months'}</p>
                    
                    {/* Show timestamp if available */}
                    {request.timestamp && (
                      <p className="card-text">Requested on: {new Date(request.timestamp * 1000).toLocaleDateString()}</p>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {request.isApproved ? 
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Approved</span> :
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">Pending</span>
                    }
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {request.status === 'approved' && (
                      <button
                        onClick={() => openPaymentModal(request)}
                        className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700"
                      >
                        Pay Rent
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      
      {/* Payment Modal */}
      {selectedRequest && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            {paymentSuccess ? (
              <div className="text-center">
                <h3 className="text-xl font-medium mb-2">Payment Successful!</h3>
                <p className="mb-4">Your rent payment has been processed. Thank you!</p>
                <button
                  onClick={closePaymentModal}
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                >
                  Close
                </button>
              </div>
            ) : (
              <>
                <h3 className="text-xl font-medium mb-4">Make Rent Payment</h3>
                
                <div key={selectedRequest.id} className="card mb-4 shadow-sm">
                  <div className="card-body">
                    <h5 className="card-title">Property #{selectedRequest.propertyId}</h5>
                    <p className="card-text">Status: {selectedRequest.isApproved ? 'Approved' : 'Pending'}</p>
                    <p className="card-text">Duration: {selectedRequest.durationMonths} months</p>
                    {/* Since the blockchain contract doesn't track payment due dates, we'll show a placeholder */}
                    <p>Next payment due: Based on agreement with landlord</p>
                  </div>
                </div>
                
                <div className="p-3 mb-4 bg-yellow-50 text-yellow-700 rounded-md text-sm">
                  <p>You are about to submit a payment of ${selectedRequest.monthlyRent} ETH.</p>
                  <p>This transaction will be recorded on the blockchain.</p>
                </div>
                
                <div className="flex flex-col space-y-2 sm:flex-row sm:space-y-0 sm:space-x-2 justify-end">
                  <button
                    onClick={closePaymentModal}
                    className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
                    disabled={processingPayment}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={makePayment}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-blue-300"
                    disabled={processingPayment}
                  >
                    {processingPayment ? 'Processing...' : 'Pay Now'}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default TenantRentalRequests;
