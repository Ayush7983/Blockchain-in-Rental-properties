import { useState, useEffect, useContext } from 'react';
// Import from the central index file
import { Web3Context, Web3ContextType } from '../../contexts';
import { Property } from '../../services/propertyService';
import { rentalRequestService } from '../../services/rentalRequestService';
import web3Service from '../../services/web3Service';

const PropertyListing = () => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [rentDuration, setRentDuration] = useState<number>(1); // In months
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [requestSuccess, setRequestSuccess] = useState<boolean>(false);

  // Properly type the Web3Context to fix TypeScript errors
  const { account, contract, isConnected } = useContext<Web3ContextType>(Web3Context);

  useEffect(() => {
    const fetchProperties = async () => {
      try {
        setLoading(true);
        console.log('Starting to fetch properties for tenant view...');
        
        // Initialize web3Service
        await web3Service.initialize();
        
        // SIMPLIFIED APPROACH: Get all raw properties directly 
        // Avoid any filtering that might be causing issues
        const rawProperties = await web3Service.getAllProperties();
        console.log('Raw properties from blockchain:', rawProperties);
        
        if (rawProperties && rawProperties.length > 0) {
          console.log('Property active statuses:', rawProperties.map(p => ({ id: p.id, isActive: p.isActive })));
          
          // Convert blockchain properties to frontend format - show ALL properties for now
          const formattedProperties = rawProperties
            // Temporarily show ALL properties, active or not until we debug the issue
            // .filter(prop => prop.isActive)
            .map(prop => ({
              id: prop.id,
              name: prop.name,
              description: prop.description,
              location: prop.location,
              landlord: prop.landlord,
              isActive: prop.isActive,
              imageURL: prop.imageURL,
              // Frontend-specific properties
              // Convert Wei to ETH (divide by 10^18)
              price: Number(prop.pricePerMonth) / 1000000000000000000,
              pricePerMonth: Number(prop.pricePerMonth) / 1000000000000000000,
              // Fix image loading by ensuring URL is properly formatted
              images: [{ 
                url: prop.imageURL && prop.imageURL.startsWith('http') 
                  ? prop.imageURL 
                  : 'https://via.placeholder.com/300x200?text=No+Image' 
              }],
              bedrooms: prop.bedrooms || 2,
              bathrooms: prop.bathrooms || 1,
              area: prop.area || 500
            }));
            
          console.log('Properties formatted for frontend:', formattedProperties);
          setProperties(formattedProperties);
          
          if (formattedProperties.length === 0) {
            console.log('No active properties found to display');
          }
        } else {
          console.log('No properties returned from blockchain');
          setError('No properties available');
        }
      } catch (err) {
        setError('Error fetching property data');
        console.error('Error fetching property data:', err);
      } finally {
        setLoading(false);
      }
    };

    // Always fetch properties when component mounts
    if (isConnected) {
      fetchProperties();
    }
  }, [isConnected]);

  const openRentalModal = (property: Property) => {
    setSelectedProperty(property);
  };

  const closeRentalModal = () => {
    setSelectedProperty(null);
    setRentDuration(1);
    setRequestSuccess(false);
  };

  const submitRentalRequest = async () => {
    if (!selectedProperty || !account || !contract) {
      console.error('Missing required data:', { 
        selectedProperty: !!selectedProperty, 
        account: !!account, 
        contract: !!contract 
      });
      setError('Missing required connection data. Please ensure your wallet is connected.');
      return;
    }

    try {
      setSubmitting(true);
      setError(null);
      
      // First create request on blockchain
      const requestId = `REQ-${Date.now()}-${account.slice(-5)}`;
      const landlordAddress = selectedProperty.landlord;
      const monthlyRent = selectedProperty.price || 0;
      
      console.log('Creating rental request with params:', {
        requestId,
        propertyId: selectedProperty.id,
        landlordAddress,
        rentDuration,
        monthlyRent
      });
      
      // Call smart contract function to create the request
      try {
        // Ensure propertyId is a number
        const propertyId = selectedProperty.id;

        console.log('Calling contract with params:', {
          propertyId,
          rentDuration
        });

        // Contract only needs propertyId and duration (matches Solidity function signature)
        const tx = await contract.createRentalRequest(
          propertyId,
          rentDuration
        );
        
        console.log('Transaction submitted:', tx);
        await tx.wait();
        console.log('Transaction confirmed on blockchain');
      } catch (contractError) {
        console.error('Blockchain transaction failed:', contractError);
        setError(`Blockchain transaction failed: ${contractError instanceof Error ? contractError.message : 'Unknown error'}`);
        return;
      }
      
      // Create rental request using blockchain-only implementation
      try {
        // The createRentalRequest service uses the blockchain request ID
        // and doesn't need to store any data in MongoDB
        const response = await rentalRequestService.createRentalRequest({
          propertyId: Number(selectedProperty.id),
          durationMonths: rentDuration
        });
        console.log('Backend request created:', response);
      } catch (backendError) {
        console.error('Backend request creation failed:', backendError);
        setError('Request recorded on blockchain but failed to update database. Please contact support.');
        return;
      }
      
      setRequestSuccess(true);
    } catch (err) {
      console.error('Error submitting rental request:', err);
      setError(`Failed to submit rental request: ${err instanceof Error ? err.message : 'Unknown error'}`);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="text-lg">Loading properties...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-600">
        {error}
      </div>
    );
  }

  // Commenting out tenant check to allow anyone to browse properties
  // if (!isTenant) {
  //   return (
  //     <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-md text-yellow-700">
  //       You need to register as a tenant to view available properties.
  //     </div>
  //   );
  // }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-6">Available Properties</h2>
      
      {properties.length === 0 ? (
        <div className="p-4 bg-gray-50 rounded-md">No properties available at this time.</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {properties.map((property) => (
            <div key={property.id} className="border rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <div className="h-48 bg-gray-200 relative">
                <img
                  src={property.imageURL && !property.imageURL.startsWith('0x') ? property.imageURL : '/placeholder.png'}
                  alt={property.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = '/placeholder.png';
                    console.log('Image load error, using placeholder for:', property.name);
                  }}
                />
                
                {/* Property status indicator */}
                <div className="absolute top-2 right-2">
                  {property.isActive ? (
                    <span className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">Active</span>
                  ) : (
                    <span className="px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded-full">Inactive</span>
                  )}
                </div>
              </div>
              
              <div className="p-4">
                <div className="text-lg font-medium">{property.name}</div>
                <p className="text-gray-500 mt-1">{property.location}</p>
                
                <div className="flex justify-between mt-3 text-sm">
                  <span>{property.bedrooms} Beds</span>
                  <span>{property.bathrooms} Baths</span>
                  <span>{property.area} sqft</span>
                </div>
                
                <div className="mt-4">
                  <span className="font-semibold text-lg">
                    {typeof property.price === 'number' ? property.price.toFixed(2) : '0.00'} ETH/month
                  </span>
                </div>
                
                {/* Temporarily allow renting all properties regardless of isActive status */}
                <button 
                  onClick={() => openRentalModal(property)}
                  className="mt-4 w-full py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                  Request to Rent
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Rental Request Modal */}
      {selectedProperty && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            {requestSuccess ? (
              <div className="text-center">
                <h3 className="text-xl font-medium mb-2">Success!</h3>
                <p className="mb-4">Your rental request has been submitted to the landlord for approval.</p>
                <button
                  onClick={closeRentalModal}
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                >
                  Close
                </button>
              </div>
            ) : (
              <>
                <h3 className="text-xl font-medium mb-4">Submit Rental Request</h3>
                <div className="mb-4">
                  <p><span className="font-bold">{selectedProperty.name}</span></p>
                  <p><span className="font-medium">Location:</span> {selectedProperty.location}</p>
                  <p><span className="font-medium">Monthly Rent:</span> ${selectedProperty.price}</p>
                </div>
                
                <div className="mb-5">
                  <label className="block mb-2">Rental Duration (months)</label>
                  <input
                    type="number"
                    min="1"
                    max="24"
                    value={rentDuration}
                    onChange={(e) => setRentDuration(parseInt(e.target.value))}
                    className="w-full p-2 border rounded-md"
                  />
                </div>
                
                <div className="flex flex-col space-y-2 sm:flex-row sm:space-y-0 sm:space-x-2 justify-end">
                  <button
                    onClick={closeRentalModal}
                    className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
                    disabled={submitting}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={submitRentalRequest}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-blue-300"
                    disabled={submitting}
                  >
                    {submitting ? 'Submitting...' : 'Submit Request'}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default PropertyListing;
