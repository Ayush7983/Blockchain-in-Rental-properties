import { useState, useEffect, useContext } from 'react';
import { Web3Context } from '../../contexts';
import Button from '../common/Button';

const UserSettings = () => {
  const { account, userName, isConnected, isLandlord, isTenant, disconnectWallet } = useContext(Web3Context);
  const [name, setName] = useState(userName);
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Update name when userName in context changes
    setName(userName);
  }, [userName]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isConnected || !account) {
      setError('Please connect your wallet first');
      return;
    }
    
    try {
      setSaving(true);
      setError(null);
      setSuccess(false);
      
      // Example API call to update user profile
      // const response = await userService.updateProfile(account, { name, email, phone });
      
      // For now, just simulate a successful update
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setSuccess(true);
    } catch (error: any) {
      console.error('Error saving profile:', error);
      setError(error.message || 'Failed to save profile');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6">User Settings</h2>
      
      {/* Account Info */}
      <div className="mb-6 p-4 bg-gray-50 rounded-md">
        <h3 className="text-lg font-medium mb-2">Account Information</h3>
        <div className="grid grid-cols-2 gap-2">
          <div className="text-gray-600">Wallet Address:</div>
          <div className="font-mono">{account ? `${account.substring(0, 6)}...${account.substring(account.length - 4)}` : 'Not connected'}</div>
          
          <div className="text-gray-600">Account Type:</div>
          <div>{isLandlord ? 'Landlord' : (isTenant ? 'Tenant' : 'Not registered')}</div>
        </div>
      </div>
      
      {/* Profile Form */}
      <form onSubmit={handleSaveProfile}>
        <div className="mb-4">
          <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
            Display Name
          </label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
            placeholder="Your name"
          />
        </div>
        
        <div className="mb-4">
          <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
            Email Address
          </label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
            placeholder="Your email (optional)"
          />
        </div>
        
        <div className="mb-6">
          <label htmlFor="phone" className="block text-gray-700 font-medium mb-2">
            Phone Number
          </label>
          <input
            type="tel"
            id="phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
            placeholder="Your phone (optional)"
          />
        </div>
        
        {/* Success message */}
        {success && (
          <div className="mb-4 p-3 bg-green-100 text-green-700 rounded-md">
            Profile updated successfully!
          </div>
        )}
        
        {/* Error message */}
        {error && (
          <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md">
            {error}
          </div>
        )}
        
        <div className="flex space-x-4">
          <Button
            type="submit"
            variant="primary"
            disabled={saving}
            isLoading={saving}
          >
            Save Changes
          </Button>
          
          <Button
            type="button"
            variant="outline"
            onClick={disconnectWallet}
          >
            Disconnect Wallet
          </Button>
        </div>
      </form>
    </div>
  );
};

export default UserSettings;
