import { Building2 } from 'lucide-react';

const LoadingScreen = () => {
  return (
    <div className="fixed inset-0 bg-white flex flex-col items-center justify-center z-50">
      <div className="animate-pulse-slow">
        <Building2 className="h-16 w-16 text-primary-600" />
      </div>
      <h3 className="mt-6 font-heading text-2xl text-gray-800">Loading DecentRental</h3>
      <p className="mt-2 text-gray-500">Connecting to blockchain...</p>
      <div className="mt-8 w-48 h-1 bg-gray-200 rounded-full overflow-hidden">
        <div className="h-full bg-primary-600 rounded-full animate-pulse w-1/2"></div>
      </div>
    </div>
  );
};

export default LoadingScreen;