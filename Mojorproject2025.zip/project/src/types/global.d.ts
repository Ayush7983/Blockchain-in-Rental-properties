interface Window {
  ethereum?: any;
}