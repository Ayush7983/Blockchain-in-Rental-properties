// This file provides TypeScript declarations for your context modules
import { ReactNode } from 'react';
import { ethers } from 'ethers';

// Declare the Web3Context module
declare module '../../contexts/Web3Context' {
  export interface Web3ContextType {
    account: string | null;
    userName: string;
    isConnected: boolean;
    isLandlord: boolean;
    isTenant: boolean;
    isInitializing: boolean;
    provider: ethers.BrowserProvider | null;
    signer: ethers.JsonRpcSigner | null;
    contract: any;
    connectWallet: () => Promise<void>;
    disconnectWallet: () => void;
    registerAsLandlord: (name: string) => Promise<void>;
    registerAsTenant: (name: string) => Promise<void>;
    checkUserType: () => Promise<void>;
    logout: () => void;
  }

  export const Web3Context: React.Context<Web3ContextType>;
  
  export interface Web3ProviderProps {
    children: ReactNode;
  }
  
  export const Web3Provider: React.FC<Web3ProviderProps>;
}
