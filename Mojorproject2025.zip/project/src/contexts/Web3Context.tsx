import React, { createContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { ethers } from 'ethers';
import RentalContract from '../contracts/RentalContract';
import contractAddressData from '../contractAddress.json';
import web3Service from '../services/web3Service';

// Define the context type
export interface Web3ContextType {
  account: string | null;
  userName: string;
  isConnected: boolean;
  isLandlord: boolean;
  isTenant: boolean;
  isInitializing: boolean;
  provider: ethers.BrowserProvider | null;
  signer: ethers.JsonRpcSigner | null;
  contract: any;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  registerAsLandlord: (name: string) => Promise<boolean>;
  registerAsTenant: (name: string) => Promise<boolean>;
  checkUserType: () => Promise<void>;
  logout: () => void;
}

// Create the context with default values
export const Web3Context = createContext<Web3ContextType>({
  account: null,
  userName: '',
  isConnected: false,
  isLandlord: false,
  isTenant: false,
  isInitializing: true,
  provider: null,
  signer: null,
  contract: null,
  connectWallet: async () => {},
  disconnectWallet: () => {},
  registerAsLandlord: async () => false,
  registerAsTenant: async () => false,
  checkUserType: async () => {},
  logout: () => {},
});

interface Web3ProviderProps {
  children: ReactNode;
}

export const Web3Provider: React.FC<Web3ProviderProps> = ({ children }) => {
  const [account, setAccount] = useState<string | null>(null);
  const [userName, setUserName] = useState<string>('');
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [isLandlord, setIsLandlord] = useState<boolean>(false);
  const [isTenant, setIsTenant] = useState<boolean>(false);
  const [isInitializing, setIsInitializing] = useState<boolean>(true);
  const [provider, setProvider] = useState<ethers.BrowserProvider | null>(null);
  const [signer, setSigner] = useState<ethers.JsonRpcSigner | null>(null);
  const [contract, setContract] = useState<any>(null);

  // Initialize from localStorage if available
  useEffect(() => {
    const storedAccount = localStorage.getItem('walletAccount');
    const storedIsLandlord = localStorage.getItem('isLandlord') === 'true';
    const storedIsTenant = localStorage.getItem('isTenant') === 'true';
    const storedUserName = localStorage.getItem('userName') || '';

    if (storedAccount) {
      setAccount(storedAccount);
      setIsConnected(true);
      setIsLandlord(storedIsLandlord);
      setIsTenant(storedIsTenant);
      setUserName(storedUserName);
      
      // Connect to contract too
      initializeProvider();
    }
    
    setIsInitializing(false);
  }, []);

  // Initialize the provider, signer and contract
  const initializeProvider = async () => {
    try {
      if (window.ethereum) {
        const ethersProvider = new ethers.BrowserProvider(window.ethereum);
        setProvider(ethersProvider);
        
        const ethersSigner = await ethersProvider.getSigner();
        setSigner(ethersSigner);
        
        // Initialize the contract with signer
        const contractAddress = contractAddressData.address;
        const contractInstance = RentalContract(contractAddress, ethersSigner);
        setContract(contractInstance);
        
        // Also initialize web3Service
        await web3Service.initialize();
      }
    } catch (error) {
      console.error("Failed to initialize provider:", error);
    }
  };

  // Connect wallet
  const connectWallet = useCallback(async () => {
    try {
      setIsInitializing(true);
      
      if (!window.ethereum) {
        throw new Error("No crypto wallet found. Please install MetaMask.");
      }
      
      // Request account access
      const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
      
      if (accounts.length === 0) {
        throw new Error("No accounts found.");
      }
      
      const connectedAccount = accounts[0];
      setAccount(connectedAccount);
      
      // Initialize provider, signer and contract immediately
      await initializeProvider();
      
      // Save to localStorage
      localStorage.setItem('walletAccount', connectedAccount);
      localStorage.setItem('isWalletConnected', 'true');
      
      console.log('🔄 Checking existing user status on blockchain before setting connected state');
      // IMPORTANT: Check if the user is already registered BEFORE setting isConnected
      // This ensures the UI won't show registration forms for already registered users
      await web3Service.initialize();
      const userDetails = await web3Service.getUserDetails(connectedAccount);
      
      if (userDetails.exists) {
        console.log('✅ Found existing user on blockchain:', userDetails);
        setIsLandlord(userDetails.isLandlord);
        setIsTenant(userDetails.isTenant);
        
        if (userDetails.name) {
          setUserName(userDetails.name);
          localStorage.setItem('userName', userDetails.name);
        } else {
          // Use stored name or default to address
          const storedName = localStorage.getItem('userName');
          if (storedName) {
            setUserName(storedName);
          } else {
            const shortAddress = `${connectedAccount.substring(0, 6)}...${connectedAccount.substring(connectedAccount.length - 4)}`;
            setUserName(shortAddress);
            localStorage.setItem('userName', shortAddress);
          }
        }
        
        localStorage.setItem('isLandlord', userDetails.isLandlord.toString());
        localStorage.setItem('isTenant', userDetails.isTenant.toString());
      } else {
        console.log('ℹ️ No existing user found on blockchain');
        setIsLandlord(false);
        setIsTenant(false);
      }
      
      // Finally set connected state AFTER all checks are done
      setIsConnected(true);
      
    } catch (error: any) {
      console.error("Error connecting wallet:", error);
      throw error;
    } finally {
      setIsInitializing(false);
    }
  }, []);

  // Disconnect wallet
  const disconnectWallet = useCallback(() => {
    setAccount(null);
    setIsConnected(false);
    setIsLandlord(false);
    setIsTenant(false);
    setUserName('');
    setProvider(null);
    setSigner(null);
    setContract(null);
    
    // Clear localStorage
    localStorage.removeItem('walletAccount');
    localStorage.removeItem('isLandlord');
    localStorage.removeItem('isTenant');
    localStorage.removeItem('userName');
    localStorage.removeItem('isWalletConnected');
    
    // Reload the page to prevent issues with MetaMask auto-reconnect
    window.location.reload();
  }, []);

  // Check user type on blockchain
  const checkUserType = useCallback(async () => {
    if (!account || !contract) {
      return;
    }
    
    try {
      console.log('🔍 Checking user type for address:', account);
      
      // Initialize web3Service if needed
      await web3Service.initialize();
      
      // Get complete user details from blockchain
      const userDetails = await web3Service.getUserDetails(account);
      console.log('🔗 User details from blockchain:', userDetails);
      
      if (userDetails.exists) {
        // User is already registered - set all their details
        setIsLandlord(userDetails.isLandlord);
        setIsTenant(userDetails.isTenant);
        
        // Save role to localStorage
        localStorage.setItem('isLandlord', userDetails.isLandlord.toString());
        localStorage.setItem('isTenant', userDetails.isTenant.toString());
        
        // Use name from blockchain if available, otherwise use localStorage or default
        if (userDetails.name) {
          setUserName(userDetails.name);
          localStorage.setItem('userName', userDetails.name);
          console.log('👤 Using name from blockchain:', userDetails.name);
        } else {
          // Fall back to stored name or generate shortened address
          const storedName = localStorage.getItem('userName');
          if (storedName) {
            setUserName(storedName);
          } else {
            const shortAddress = `${account.substring(0, 6)}...${account.substring(account.length - 4)}`;
            setUserName(shortAddress);
            localStorage.setItem('userName', shortAddress);
          }
        }
      } else {
        // User is not registered yet - keep default state
        console.log('ℹ️ User is not registered on blockchain yet');
        setIsLandlord(false);
        setIsTenant(false);
      }
    } catch (error) {
      console.error("❌ Error checking user type:", error);
    }
  }, [account, contract]);

  // Register as landlord
  const registerAsLandlord = useCallback(async (name: string) => {
    if (!account) {
      console.error('❌ Cannot register: No account connected');
      throw new Error("Wallet not connected");
    }
    
    console.log('🚀 Starting landlord registration for:', { address: account, name });
    
    try {
      // Initialize web3Service if needed
      await web3Service.initialize();
      
      // Check if user is already registered as a landlord
      const isUserAlreadyLandlord = await web3Service.isUserLandlord(account);
      
      if (isUserAlreadyLandlord) {
        console.log('ℹ️ User already registered as landlord');
        // Skip blockchain registration but update local state
      } else {
        // Register on blockchain
        console.log('🔗 Registering on blockchain...');
        await web3Service.registerAsLandlord();
        console.log('✅ Blockchain registration successful');
      }
      
      // Update local state
      setIsLandlord(true);
      setIsTenant(false);
      setUserName(name);
      
      // Store in localStorage
      localStorage.setItem('isLandlord', 'true');
      localStorage.setItem('isTenant', 'false');
      localStorage.setItem('userName', name);
      
      return true;
    } catch (error: any) {
      // Handle the "already registered" error gracefully
      if (error.message && error.message.includes('already registered')) {
        console.log('ℹ️ User already registered on blockchain (caught from error)');
        
        // Still update local state
        setIsLandlord(true);
        setIsTenant(false);
        setUserName(name);
        
        // Store in localStorage
        localStorage.setItem('isLandlord', 'true');
        localStorage.setItem('isTenant', 'false');
        localStorage.setItem('userName', name);
        
        return true;
      }
      
      console.error('❌ Error registering as landlord:', error);
      throw error;
    }
  }, [account]);

  // Register as tenant
  const registerAsTenant = useCallback(async (name: string) => {
    if (!account) {
      console.error("❌ Cannot register: No account connected");
      throw new Error("Wallet not connected");
    }
    
    console.log('🚀 Starting tenant registration for:', { address: account, name });
    
    try {
      // Initialize web3Service if needed
      await web3Service.initialize();
      
      // Check if user is already registered as a tenant
      const isUserAlreadyTenant = await web3Service.isUserTenant(account);
      
      if (isUserAlreadyTenant) {
        console.log('ℹ️ User already registered as tenant');
        // Skip blockchain registration but update local state
      } else {
        // Register on blockchain
        console.log('🔗 Registering on blockchain...');
        await web3Service.registerAsTenant();
        console.log('✅ Blockchain registration successful');
      }
      
      // Update local state
      setIsLandlord(false);
      setIsTenant(true);
      setUserName(name);
      
      // Store in localStorage
      localStorage.setItem('isLandlord', 'false');
      localStorage.setItem('isTenant', 'true');
      localStorage.setItem('userName', name);
      
      return true;
    } catch (error: any) {
      // Handle the "already registered" error gracefully
      if (error.message && error.message.includes('already registered')) {
        console.log('ℹ️ User already registered on blockchain (caught from error)');
        
        // Still update local state
        setIsLandlord(false);
        setIsTenant(true);
        setUserName(name);
        
        // Store in localStorage
        localStorage.setItem('isLandlord', 'false');
        localStorage.setItem('isTenant', 'true');
        localStorage.setItem('userName', name);
        
        return true;
      }
      
      console.error('❌ Error registering as tenant:', error);
      throw error;
    }
  }, [account]);
  
  // Logout function
  const logout = useCallback(() => {
    disconnectWallet();
  }, [disconnectWallet]);

  // Context value
  const contextValue: Web3ContextType = {
    account,
    userName,
    isConnected,
    isLandlord,
    isTenant,
    isInitializing,
    provider,
    signer,
    contract,
    connectWallet,
    disconnectWallet,
    registerAsLandlord,
    registerAsTenant,
    checkUserType,
    logout,
  };

  // Provider component
  return (
    <Web3Context.Provider value={contextValue}>
      {children}
    </Web3Context.Provider>
  );
};

export default Web3Context;
