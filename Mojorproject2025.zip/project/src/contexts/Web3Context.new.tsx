import React, { createContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { ethers } from 'ethers';
import RentalContract from '../contracts/RentalContract';
import contractAddressData from '../contractAddress.json';
import web3Service from '../services/web3Service';

// Define the context type
export interface Web3ContextType {
  account: string | null;
  userName: string;
  isConnected: boolean;
  isLandlord: boolean;
  isTenant: boolean;
  isInitializing: boolean;
  provider: ethers.BrowserProvider | null;
  signer: ethers.JsonRpcSigner | null;
  contract: any;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  registerAsLandlord: (name: string) => Promise<boolean>;
  registerAsTenant: (name: string) => Promise<boolean>;
  checkUserType: () => Promise<void>;
  logout: () => void;
}

// Create the context with default values
export const Web3Context = createContext<Web3ContextType>({
  account: null,
  userName: '',
  isConnected: false,
  isLandlord: false,
  isTenant: false,
  isInitializing: true,
  provider: null,
  signer: null,
  contract: null,
  connectWallet: async () => {},
  disconnectWallet: () => {},
  registerAsLandlord: async () => false,
  registerAsTenant: async () => false,
  checkUserType: async () => {},
  logout: () => {},
});

interface Web3ProviderProps {
  children: ReactNode;
}

export const Web3Provider: React.FC<Web3ProviderProps> = ({ children }) => {
  const [account, setAccount] = useState<string | null>(null);
  const [userName, setUserName] = useState<string>('');
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [isLandlord, setIsLandlord] = useState<boolean>(false);
  const [isTenant, setIsTenant] = useState<boolean>(false);
  const [isInitializing, setIsInitializing] = useState<boolean>(true);
  const [provider, setProvider] = useState<ethers.BrowserProvider | null>(null);
  const [signer, setSigner] = useState<ethers.JsonRpcSigner | null>(null);
  const [contract, setContract] = useState<any>(null);

  // Initialize from localStorage if available
  useEffect(() => {
    const storedAccount = localStorage.getItem('walletAccount');
    const storedIsLandlord = localStorage.getItem('isLandlord') === 'true';
    const storedIsTenant = localStorage.getItem('isTenant') === 'true';
    const storedUserName = localStorage.getItem('userName') || '';

    if (storedAccount) {
      setAccount(storedAccount);
      setIsConnected(true);
      setIsLandlord(storedIsLandlord);
      setIsTenant(storedIsTenant);
      setUserName(storedUserName);
      
      // Connect to contract too
      initializeProvider();
    }
    
    setIsInitializing(false);
  }, []);

  // Initialize the provider, signer and contract
  const initializeProvider = async () => {
    try {
      if (window.ethereum) {
        const ethersProvider = new ethers.BrowserProvider(window.ethereum);
        setProvider(ethersProvider);
        
        const ethersSigner = await ethersProvider.getSigner();
        setSigner(ethersSigner);
        
        // Initialize the contract with signer
        const contractAddress = contractAddressData.address;
        const contractInstance = RentalContract(contractAddress, ethersSigner);
        setContract(contractInstance);
        
        // Also initialize web3Service
        await web3Service.initialize();
      }
    } catch (error) {
      console.error("Failed to initialize provider:", error);
    }
  };

  // Connect wallet
  const connectWallet = useCallback(async () => {
    try {
      setIsInitializing(true);
      
      if (!window.ethereum) {
        throw new Error("No crypto wallet found. Please install MetaMask.");
      }
      
      // Request account access
      const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
      
      if (accounts.length === 0) {
        throw new Error("No accounts found.");
      }
      
      const connectedAccount = accounts[0];
      setAccount(connectedAccount);
      setIsConnected(true);
      
      // Initialize provider, signer and contract
      await initializeProvider();
      
      // Save to localStorage
      localStorage.setItem('walletAccount', connectedAccount);
      localStorage.setItem('isWalletConnected', 'true');
      
      // Check if the user is already registered
      await checkUserType();
      
    } catch (error: any) {
      console.error("Error connecting wallet:", error);
      throw error;
    } finally {
      setIsInitializing(false);
    }
  }, []);

  // Disconnect wallet
  const disconnectWallet = useCallback(() => {
    setAccount(null);
    setIsConnected(false);
    setIsLandlord(false);
    setIsTenant(false);
    setUserName('');
    setProvider(null);
    setSigner(null);
    setContract(null);
    
    // Clear localStorage
    localStorage.removeItem('walletAccount');
    localStorage.removeItem('isLandlord');
    localStorage.removeItem('isTenant');
    localStorage.removeItem('userName');
    localStorage.removeItem('isWalletConnected');
    
    // Reload the page to prevent issues with MetaMask auto-reconnect
    window.location.reload();
  }, []);

  // Check user type on blockchain
  const checkUserType = useCallback(async () => {
    if (!account || !contract) {
      return;
    }
    
    try {
      console.log('🔍 Checking user type for address:', account);
      
      // Initialize web3Service if needed
      await web3Service.initialize();
      
      // Check on blockchain if user is landlord or tenant
      const isUserLandlord = await web3Service.isUserLandlord(account);
      const isUserTenant = await web3Service.isUserTenant(account);
      
      console.log('🔗 Blockchain user status:', { isLandlord: isUserLandlord, isTenant: isUserTenant });
      
      // Update state based on blockchain data
      setIsLandlord(isUserLandlord);
      setIsTenant(isUserTenant);
      
      // Save to localStorage
      localStorage.setItem('isLandlord', isUserLandlord.toString());
      localStorage.setItem('isTenant', isUserTenant.toString());
      
      // Note: Without MongoDB, we don't have the user's name
      // We'll just use a placeholder or the address if no name is stored
      const storedName = localStorage.getItem('userName');
      if (!storedName) {
        // Use shortened address as name if not set
        const shortAddress = `${account.substring(0, 6)}...${account.substring(account.length - 4)}`;
        setUserName(shortAddress);
        localStorage.setItem('userName', shortAddress);
      }
    } catch (error) {
      console.error("❌ Error checking user type:", error);
    }
  }, [account, contract]);

  // Register as landlord
  const registerAsLandlord = useCallback(async (name: string) => {
    if (!account) {
      console.error('❌ Cannot register: No account connected');
      throw new Error("Wallet not connected");
    }
    
    console.log('🚀 Starting landlord registration for:', { address: account, name });
    
    try {
      // Initialize web3Service if needed
      await web3Service.initialize();
      
      // Register on blockchain
      console.log('🔗 Registering on blockchain...');
      await web3Service.registerAsLandlord();
      console.log('✅ Blockchain registration successful');
      
      // Update local state
      setIsLandlord(true);
      setIsTenant(false);
      setUserName(name);
      
      // Store in localStorage
      localStorage.setItem('isLandlord', 'true');
      localStorage.setItem('isTenant', 'false');
      localStorage.setItem('userName', name);
      
      return true;
    } catch (error: any) {
      if (error.message && error.message.includes('already registered')) {
        // This is fine, the user is already a landlord on the blockchain
        console.log('ℹ️ User already registered on blockchain');
        
        // Still update local state
        setIsLandlord(true);
        setIsTenant(false);
        setUserName(name);
        
        // Store in localStorage
        localStorage.setItem('isLandlord', 'true');
        localStorage.setItem('isTenant', 'false');
        localStorage.setItem('userName', name);
        
        return true;
      }
      
      console.error('❌ Error registering as landlord:', error);
      return false;
    }
  }, [account]);

  // Register as tenant
  const registerAsTenant = useCallback(async (name: string) => {
    if (!account) {
      console.error('❌ Cannot register: No account connected');
      throw new Error("Wallet not connected");
    }
    
    console.log('🚀 Starting tenant registration for:', { address: account, name });
    
    try {
      // Initialize web3Service if needed
      await web3Service.initialize();
      
      // Register on blockchain
      console.log('🔗 Registering on blockchain...');
      await web3Service.registerAsTenant();
      console.log('✅ Blockchain registration successful');
      
      // Update local state
      setIsLandlord(false);
      setIsTenant(true);
      setUserName(name);
      
      // Store in localStorage
      localStorage.setItem('isLandlord', 'false');
      localStorage.setItem('isTenant', 'true');
      localStorage.setItem('userName', name);
      
      return true;
    } catch (error: any) {
      if (error.message && error.message.includes('already registered')) {
        // This is fine, the user is already a tenant on the blockchain
        console.log('ℹ️ User already registered on blockchain');
        
        // Still update local state
        setIsLandlord(false);
        setIsTenant(true);
        setUserName(name);
        
        // Store in localStorage
        localStorage.setItem('isLandlord', 'false');
        localStorage.setItem('isTenant', 'true');
        localStorage.setItem('userName', name);
        
        return true;
      }
      
      console.error('❌ Error registering as tenant:', error);
      return false;
    }
  }, [account]);
  
  // Logout function
  const logout = useCallback(() => {
    disconnectWallet();
  }, [disconnectWallet]);

  // Context value
  const contextValue: Web3ContextType = {
    account,
    userName,
    isConnected,
    isLandlord,
    isTenant,
    isInitializing,
    provider,
    signer,
    contract,
    connectWallet,
    disconnectWallet,
    registerAsLandlord,
    registerAsTenant,
    checkUserType,
    logout,
  };

  // Provider component
  return (
    <Web3Context.Provider value={contextValue}>
      {children}
    </Web3Context.Provider>
  );
};

export default Web3Context;
