const mongoose = require('mongoose');
require('dotenv').config({ path: '.env.local' });

// Connection URI from environment or default
const mongoUri = process.env.MONGODB_URI || 'mongodb+srv://Admin:OEAXBipykcaJBFhr@cluster0.e8rysnf.mongodb.net/test?retryWrites=true&w=majority';

// Log the connection attempt (with hidden credentials)
const loggableUri = mongoUri.replace(/\/\/([^:]+):([^@]+)@/, '//$1:****@');
console.log(`🔌 Attempting to connect to MongoDB: ${loggableUri}`);

// Sample data
const sampleUser = {
  address: '0x1234567890123456789012345678901234567890',
  name: 'Test User',
  email: 'test@example.com',
  phone: '+1234567890',
  role: 'tenant',
  createdAt: new Date(),
  updatedAt: new Date()
};

async function testConnection() {
  try {
    // Connect to MongoDB
    await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 5000,
    });
    
    console.log('✅ Connected to MongoDB');
    
    // Get the database name
    const dbName = mongoose.connection.db.databaseName;
    console.log(`📊 Using database: ${dbName}`);
    
    // List collections
    const collections = await mongoose.connection.db.listCollections().toArray();
    console.log(`📂 Collections (${collections.length}):`);
    collections.forEach(coll => console.log(`- ${coll.name}`));
    
    // Try to insert a test user
    const usersCollection = mongoose.connection.db.collection('users');
    const result = await usersCollection.insertOne(sampleUser);
    console.log('✅ Inserted test user:', result.insertedId);
    
    // Count users
    const count = await usersCollection.countDocuments();
    console.log(`👥 Total users: ${count}`);
    
    // Find the test user
    const user = await usersCollection.findOne({ email: 'test@example.com' });
    console.log('🔍 Found user:', user ? user.name : 'Not found');
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  } finally {
    // Close the connection
    await mongoose.connection.close();
    console.log('\n🔌 Disconnected from MongoDB');
  }
}

// Run the test
testConnection();
