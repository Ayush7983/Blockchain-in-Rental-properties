// We import the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
import pkg from 'hardhat';
const { ethers } = pkg;
import fs from "fs";

async function main() {
  console.log("Deploying RentalContract...");

  // Deploy the contract
  const RentalContract = await ethers.getContractFactory("RentalContract");
  const rentalContract = await RentalContract.deploy();

  await rentalContract.waitForDeployment();

  const address = await rentalContract.getAddress();
  console.log(`RentalContract deployed to: ${address}`);

  // Store the contract address in a file for the frontend to use
  const contractAddressPath = "./src/contractAddress.json";
  
  fs.writeFileSync(
    contractAddressPath,
    JSON.stringify({ address }, null, 2)
  );
  
  console.log("Contract address saved to", contractAddressPath);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
