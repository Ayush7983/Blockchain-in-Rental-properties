/**
 * Restart script for DecentRental DApp
 * This script handles the synchronization between blockchain and MongoDB
 * and restarts the application servers.
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

console.log('🔄 DecentRental DApp Restart and Synchronization');
console.log('================================================');

// 1. Check if MongoDB and Blockchain are connected
try {
  console.log('✅ Checking MongoDB connection...');
  // Make sure we're starting with a fresh server instance
  try {
    execSync('taskkill /F /IM node.exe', { stdio: 'ignore' });
  } catch (e) {
    // It's okay if no processes were killed
  }

  // 2. Migrate blockchain users to MongoDB
  console.log('✅ Migrating blockchain users to MongoDB...');
  try {
    execSync('node server/migrateUsers.js', { stdio: 'inherit' });
  } catch (e) {
    console.error('❌ Error migrating users:', e.message);
    process.exit(1);
  }

  // 3. Start the backend server
  console.log('✅ Starting backend server...');
  execSync('start cmd /k node server/server.js', { stdio: 'inherit' });
  
  // Wait a moment for the server to start
  console.log('⏳ Waiting for server to initialize...');
  setTimeout(() => {
    // 4. Start the frontend dev server
    console.log('✅ Starting frontend development server...');
    execSync('start cmd /k npm run dev', { stdio: 'inherit' });
    
    console.log('\n🚀 DecentRental DApp is now running!');
    console.log('📱 Frontend: http://localhost:5173 or http://localhost:5174');
    console.log('🖥️ Backend API: http://localhost:5000/api');
    console.log('📝 Blockchain node should be running at: http://127.0.0.1:8545/');
    console.log('\n💡 Make sure your MetaMask is connected to localhost:8545');
  }, 3000);
} catch (error) {
  console.error('❌ Error during restart:', error);
  process.exit(1);
}
