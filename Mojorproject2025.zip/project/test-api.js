// Simple script to test the API connection
const fetch = require('node-fetch');

async function testConnection() {
  try {
    // Test GET /api/properties
    console.log('Testing GET /api/properties...');
    const propertiesRes = await fetch('http://localhost:5000/api/properties');
    const propertiesData = await propertiesRes.json();
    console.log('Properties:', propertiesData);
    
    // Test GET /api/users
    console.log('\nTesting GET /api/users...');
    const usersRes = await fetch('http://localhost:5000/api/users');
    const usersData = await usersRes.json();
    console.log('Users:', usersData);
    
  } catch (error) {
    console.error('Error:', error);
  }
}

testConnection();
